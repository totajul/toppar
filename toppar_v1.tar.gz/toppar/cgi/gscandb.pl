#!/usr/bin/perl

use strict;
use DBI;

my %config=();
my $logfile="";

sub getURL{
  my $name=shift;
  &read_config if (keys (%config)<1);  
  my $url=$config{json_url};
  if($url !~ /\/$/){$url.="/";  }  
  return $url.$name;
}

sub getOutfile{
  my $name=shift;
  &read_config if (keys (%config)<1);  
  my $dir=$config{json_dir};
  if($dir !~ /\/$/){$dir.="/";}
  return $dir.$name;
}

sub getOutDir{
   &read_config if (keys (%config)<1);  
  my $dir=$config{json_dir};
  if($dir !~ /\/$/){$dir.="/";}
 return $dir;
}

sub gscandb_connect{
    &read_config if (keys (%config)<1);
    my $database=$config{database}; 
    my $dsn=$config{dsn};
    my $user=$config{user}; 
    my $passwd=$config{password}; 
    return DBI->connect($dsn."=".$database, $user, $passwd);
}

sub get_logfile(){
    if(($logfile =~ //)  || (!(-e $logfile))){
        &mk_toppar_log();
    }
    return $logfile;
}
sub mk_toppar_log{
    &read_config();
    $logfile=$config{tmp};
    open(OUT, ">$logfile") or die "Couldnt open $logfile \n";
    print OUT localtime()."\n";
}
 
sub get_database(){
    if(!($config{database})){
        &read_config();
    }
    return $config{database};
}

sub read_config{
    open(IN, "../etc/config.txt") or die "Cannot open ../etc/config.txt\n";
    while(<IN>){
	chomp();
	if($_ =~ /(\S+)=(\S+)/){$config{$1}=$2;}
    }close(IN);
}

1;
