#!/usr/bin/perl

use strict;
use DBI;
use FindBin '$Bin';

my %config=();
my $logfile="";

sub getURL{
  my $name=shift;
  &read_config if (keys (%config)<1);  
  my $url=$config{json_url};
  if($url !~ /\/$/){$url.="/";  }  
  return $url.$name;
}

sub getOutfile{
  my $name=shift;
  &read_config if (keys (%config)<1);  
  my $dir=$config{json_dir};
  if($dir !~ /\/$/){$dir.="/";}
  return $dir.$name;
}

sub getOutDir{
   &read_config if (keys (%config)<1);  
   my $dir=$config{json_dir};
   if($dir !~ /\/$/){$dir.="/";}
   return $dir;
}

sub getGtDir{
    &read_config if (keys (%config)<1);
    my $dir=$config{genotypes};
    if($dir !~ /\/$/){$dir.="/";}
    return $dir;
}
sub getPlink{
    &read_config if (keys (%config)<1);
    return $config{plink};
}

sub gscandb_connect{
    &read_config if (keys (%config)<1);
    my $database=$config{database}; 
    my $dsn=$config{dsn};
    my $user=$config{user}; 
    my $passwd=$config{password}; 
    return DBI->connect($dsn."=".$database, $user, $passwd);
}

sub get_logfile(){
    if(($logfile =~ //)  || (!(-e $logfile))){
        &mk_toppar_log();
    }
    return $logfile;
}
sub mk_toppar_log{
    &read_config();
    $logfile=$config{tmp};
    open(OUT, ">$logfile") or die "Couldnt open $logfile \n";
    print OUT localtime()."\n";
}
 
sub get_database(){
    if(!($config{database})){
        &read_config();
    }
    return $config{database};
}

sub read_config{
    $Bin =~ s/cgi$/etc/;
    my $conf=$Bin."/config.txt";
    open(IN, "$conf") or die "Cannot open $conf\n";
    my $toppar_home; my $toppar_web;
    while(<IN>){
	chomp();
	if($_ =~ /(\S+)=(\S+)/){
	    my $key=$1; my $value=$2;
            if($key =~ /TOPPAR_HOME/){
                $toppar_home=$value;
            }
            elsif($key =~ /TOPPAR_WEB/){
                $toppar_web=$value;
            }
            $value =~ s/TOPPAR_HOME/$toppar_home/;
            $value =~ s/TOPPAR_WEB/$toppar_web/;
	    $config{$key}=$value;
	}
    }close(IN);
    return \%config;
}

sub is_user_pwd_valid{
    my ($usr, $pwd)=@_;
    &read_config();
    my $is_valid=0;
    if(($config{user} =~ /^$usr$/)&& ($config{password} =~ /^$pwd$/)){
        $is_valid=1;
    }
    return $is_valid;
}

sub is_safe{
    my $param=shift;
    my $safe_chars="a-zA-Z0-9_.-";
    $param =~ tr/ /_/;
    my $safe=0;
    if($param =~ /(^[$safe_chars]+$)/){
        if($param !~ /(SELECT|INSERT|UPDATE|ALTER|DELETE)/){
            $safe=1;
        }
    }
    $safe=1;
    return $safe;
}

1;
