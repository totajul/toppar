#!/usr/bin/perl

use DBI();

print "Content-type: text/html; charset=iso-8859-1\n\n";
print "<html>";
print "<body>";
print "CGI Test Page";
print "</body>";
print "</html>";
