
//cgi scripts
var cgi_url="http://localhost/cgi/";

//CGI scripts
var getData_cgi=cgi_url+"getData.cgi";  
var populateMenus_cgi=cgi_url+"populateMenus.cgi"; 
var getPopulation_cgi=cgi_url+"getPopulation.cgi";
var geneAnnot_cgi=cgi_url+"geneAnnotHuman.cgi";
var getSnp_cgi=cgi_url+"getSnp.cgi";
var getGene_cgi=cgi_url+"getGene.cgi";
var getExons_cgi=cgi_url+"getExons.cgi";
var getChr_cgi=cgi_url+"getChr.cgi";
var getMarkers_cgi=cgi_url+"getMarkers.cgi";
var getGWASCatSnps_cgi=cgi_url+"getGWASCatSNPs.cgi";
var getGenomeBuild_cgi=cgi_url+"getGenomeBuild.cgi";

var links="Ensembl (<b>E</b>) and UCSC (<b>U</b>)";
var ensembl="http://www.ensembl.org/Homo_sapiens/geneview?gene=";
var ucsc="http://genome.ucsc.edu/cgi-bin/hgTracks?org=human&db=hg19&position=chr";
var disease="http://diseases.jensenlab.org/Entity?order=textmining,knowledge,experiments&textmining=10&knowledge=10&experiments=10&type1=9606&type2=-26&id1=";
var expression="http://tissues.jensenlab.org/Entity?figures=tissues_body_human&knowledge=10&experiments=10&textmining=10&type1=9606&type2=-25&id1=";


var colors=["#191970","#99CCFF","#9933CC","#33CC00","#CC9900","#8F246B","#FF99CC","#006600","#660066","#CCFF00","#33FF00","#7A96EA","#CCCCCC", "#6668FF", "#003300", "#FFFF66", "#3300CC", "#CC00FF"]; 

var genome_build="GRCh37";



