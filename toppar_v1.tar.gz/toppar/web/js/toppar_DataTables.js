
var colDefs_assoc_results=[
    {"title": "Pos", "targets": 0, "visible": true},
    {"title" : "rs_name","targets": 1, "render":
    function(data,type,full,meta){      var probeId=full[2]; if(full[2].match(/^rs/)){probeId=getdbSNPHref(full[2])}return "<div class='width_100 text-wrap' >"+probeId+"</div>"}
    }, //<a href=# onclick=\"show_id(\""+full[2]+"\")\"\></a>   onmouseover=\"show_id("+full[2]+")\"
    {"title": "pval_log10", "targets": 2, "render": function(data,type,full,meta){ return full[1].toFixed(2);}},
    {"title": "Description", "targets": 3, "render": function(data, type, full, meta){
            var items=full[3].split(";");
            var desc_string="";
            $.each(items, function(i, item){
                var key_val=item.split(":");
                 if(typeof(key_val[0]) !== "undefined")
                    desc_string+="<b>"+key_val[0]+"</b>: "+key_val[1]+", ";
            });
            return desc_string;
        }
    }
];

var colDefs_gwascat=[
    {"title": "Pos", "targets": 0, "visible": true},
    {"title": "pval_log10", "targets": 1, "visible": false}, //"render": function(data,type,full,meta){ return full[1].toFixed(2);}},
    {"title" : "rs_name","targets": 2, "render": function(data,type,full,meta){return "<div class='narrow_col2 text-wrap' >"+full[2]+"</div>"}}, //<a href=# onclick=\"show_id(\""+full[2]+"\")\"\></a>   onmouseover=\"show_id("+full[2]+")\"
    {"title": "disease", "targets": 3},
    {"title" : "pval", "targets": 4},   //,"className" : "nowrap narrow_col",  "render": function(data,type,full,meta){return full[11].toExponential(2);}},
    {"title": "or_beta", "targets": 5},
    {"title": "reported gene", "targets": 6},
    {"title": "str.snp.risk.all", "targets": 7},
    {"title": "pubmed id", "targets": 8,
    "render":
      function(data, type, full, meta){
        return getPubmedHref(full[8])}
      },
    {"title": "author", "targets": 9},
    {"title": "pub date", "targets": 10},
    {"title": "journal", "targets": 11},
  // {"title": "Link", "targets": 12, "visible": false},
  // {"title": "Ingergenic", "targets": 13, "visible":false},
//, "render": function(data,type,full,meta){ return full[5].toFixed(12);}},
];

function redraw_genes_DataTable(from, to, chr){
  var annot=$("#genes_region_label");
  annot.empty();
  annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\">Gene annotations on chr " + chr + " between " + from + " and " + to + "</small></h3>");
  var dt=$("#genes_region_table").DataTable();
  dt.clear().rows.add(genes_current).draw();
}

function show_id(id){
//  alert(id);
}

function mk_genes_DataTable(from, to, chr){
  $("#region_tables_checkboxes").show();
  $("#genes_region_table_div").show();
  //only the genes table is shown on initiation in region view
  $('#genes_region_table_cb').prop('checked', true);
  $('#gwascat_region_table_cb').prop('checked', false);
    $('#variantDetails_table_cb').prop('checked', false);
    var annot=$("#genes_region_label");
    annot.empty();
    annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\">Gene annotations on  chr " + chr + " between " + from + " and " + to + "</small></h3>");
    var table_id="genes_region_table";
    var table_div=$("#"+table_id);
    table_div.empty();
  //  $("#genes_region_table").DataTable();
   table_div.DataTable({
	   "dom": 'Bfrtip',
	       buttons: [
			 'copy', 'csv',  'print'
			 ],
        "processing": true,
        "data": genes_current,
        "bDestroy": true,
        "order" : [[2, "asc"]],
        columns: [
            {"data" : "name", "className": "narrow_width_80"},
            {"data" : "ensId", "className": "width_180 text-wrap"},
            {"data": "bpStart"},
            {"data" : "bpEnd"},
            {"data" : "strand"},
            {"data" : "desc", "className" : "text-wrap"},
            //{"data" : "desc_ens", "className" : "nowrap"},
            {"data" : "disease", "className": "narrow_220 text-wrap"},
            {"data": "protein_id"}
        ],
        columnDefs:[
            {"title": "Name", "targets": 0},
            {"title": "Ensembl id", "targets": 1, "render": function(data,type,full,meta){return getEnsemblHref(full.ensId, full.ensId) + "["+getEnsemblHref(full.ensId,"E")+", "+getUCSCHref(full.chr, full.bpStart, full.bpEnd)+"]";}},
            {"title": "Start", "targets": 2},
            {"title" : "End","targets": 3},
            {"title": "Str", "targets": 4},
            {"title" : "Desc Ensembl", "targets": 5},
          //  {"title": "Desc Ensembl", "targets": 5},
            {"title" : "Disease", "targets": 6, "render": function(data, type, full, meta){ return getDiseaseHref(full.protein_id, full.disease, full.diseaseTooltip);}},
            {"title" : "Protein id", "targets": 7, "render": function(data, type, full, meta){return getExpressionHref(full.protein_id);}}
        ]
    });
    table_div.addClass("compact");
    //bootstrap classes
    //table_div.addClass('table-condensed');
    table_div.addClass('table-striped');
}

function redraw_results_DataTable(from, to, chr, callback){
    $.each(plots, function(i, plot){
        $.each(plot.seriesArray, function(j, series){
            if(series.leadSeries){
              var annot=$("#results_region_label"+i+""+j);
              annot.empty();
              annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\">Association results for "+series.phenotype+" on chr"+chr+" from "+from+" to "+to+"</small></h3>");
              callback(plot.getSeriesByTypeIndex(series.typeIndex), i, j);
          }
        });
    });
  }


function redraw_results(currentData, i, j){
      var dt_r=$("#results_region_table"+i+""+j).DataTable();
      dt_r.clear().rows.add(currentData).draw();
}



function mk_results_region_DataTable(){
    var table_region_div=document.getElementById("results_region_tables");
    var html="";
    $.each(plots, function(i, plot){
      //prepeare the divs for the tables
        $.each(plot.seriesArray, function(j, series){
          if(series.leadSeries){
          html+="<div id=\"results_region_table_div"+i+""+j+"\">";
          html+="<div id=\"results_region_label"+i+""+j+"\"></div>";
          html+="<table style=\"width:100%\" id=\"results_region_table"+i+""+j+"\"></table></div>";
        }

        });
    });
    $("#results_region_tables").append(html);
    $.each(plots, function(i, plot){
        $.each(plot.seriesArray, function(j, series){
          if(series.leadSeries){
            mk_region_DataTable(series, i, j);
          }
        });
    });
}


function mk_results_genome_DataTable(){
    //make a table for each series
    $("#genome_tables_checkboxes").show();
    $("#results_genome_tabels").show();
    //Results tables are shown upon initiation in genome view
    $('#results_genome_table_cb').prop('checked', true);
    $('#gwascat_genome_table_cb').prop('checked', false);
    var table_genome_div=document.getElementById("results_genome_tables");
    var html="";
    $.each(genomePlots, function(i, gplot){
        $.each(gplot.seriesArray, function(j, series){
          html+="<div id=\"results_genome_table_div"+i+""+j+"\">";
          html+="<div id=\"results_genome_label"+i+""+j+"\"></div>";
          html+="<table style=\"width:100%\" id=\"results_genome_table"+i+""+j+"\"></table></div>";
        });
    });
    $("#results_genome_tables").append(html);
    $.each(genomePlots, function(i, gplot){
        $.each(gplot.seriesArray, function(j, series){
          mk_genome_DataTable(series, i, j);
        });
    });
  }

function mk_DataTable(table_id){
  var table_div=$("#"+table_id);
  $("#lookup_table").DataTable();
  table_div.addClass('compact');
  table_div.addClass('table-striped');
}

function redraw_gwas_DataTable(from, to){
  var annot=$("#gwascat_region_label");
  annot.empty();
  annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\">Gwas catalog SNPs on chr " + plots[0].chr + " between " + from + " and " + to + "</small></h3>");
  var table_id="gwascat_region_table";
  var dt_r=$("#"+table_id).DataTable();
  var gwasCat_subset=getDataWithinInterval(gwas_data.data,from, to);
  dt_r.clear().rows.add(gwasCat_subset).draw();
}

function mk_gwas_region_DataTable(){
    if(!($.isEmptyObject(gwas_data)) && (typeof(gwas_data.data) !== "undefined")){
	    mk_gwas_DataTable(gwas_data);
    }
    else
	getGWASseries(plots[0], mk_gwas_DataTable);
}


function mk_gwas_DataTable(gwas_data){
  var annot=$("#gwascat_region_label");
  annot.empty();
  if(typeof(plots[0].ranges) != "undefined"){ //are we zoomed in?
      var ranges=plots[0].ranges;
      var from=parseInt(ranges.xaxis.from); var to=parseInt(ranges.xaxis.to);
      annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\">Gwas catalog SNPs on chr " + plots[0].chr + " between " + from + " and " + to + "</small></h3>");
      gwas_data_sub=getDataWithinInterval(gwas_data.data,from, to);
}
else{
    annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\">GWAS catalog SNPs on chr "+plots[0].chr+"</small></h3>");
    gwas_data_sub=gwas_data.data;
}

  var table_id="gwascat_region_table";
  var table_div=$("#"+table_id);
  table_div.empty();
  table_div.DataTable({
	  dom: 'Bfrtip',
	      buttons: [
			'copy', 'csv',  'print'
			],
      processing: true,
      data: gwas_data_sub,
      bDestroy: true,
      order : [[4, "asc"]],
      columnDefs: colDefs_gwascat
    });
    table_div.addClass("compact");
    table_div.addClass('table-striped');
}


function mk_region_DataTable(series, i, j){
    var annot=$("#results_region_label"+i+""+j);
    var data=plots[i].getSeriesByTypeIndex(series.typeIndex);
    annot.empty();
    annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\"><a href=\"javascript:void(0)\" onclick=\"showhide('results_region_table"+i+""+j+"_wrapper'); return(false);\">Association results for "+series.phenotype +"</a></small></h3>");
    var table_id="results_region_table"+i+""+j;
    var table_div=$("#"+table_id);
    table_div.DataTable({
	dom: 'Bfrtip',
		buttons: [
			  'copy', 'csv',  'print'
			  ],
        processing: true,
        data: data,
        bDestroy: true,
        bAutoWidth: false,
        order : [[2, "desc"]],
        columnDefs: colDefs_assoc_results
    });
    //reorder the columns
    table_div.addClass("compact");
    table_div.addClass('table-striped');
}



function mk_genome_DataTable(series, i, j){
    var annot=$("#results_genome_label"+i+""+j);
    annot.empty();
    annot.append("<h3><small class=\"text-primary\" style=\"color:#08519C\"><a href=\"javascript:void(0)\" onclick=\"showhide('results_genome_table"+i+""+j+"_wrapper'); return(false);\">Association results for "+series.phenotype +"</a></small></h3>");
    var table_id="results_genome_table"+i+""+j;
    var table_div=$("#"+table_id);
    table_div.DataTable({
	    dom: 'Bfrtip',
		buttons: [
			  'copy', 'csv',  'print'
			  ],
        processing: true,
        data: series.data,
        bDestroy: true,
        bAutoWidth: false,
        order : [[1, "asc"]],
        columnDefs: colDefs_assoc_results
    });
    //reorder the columns
    table_div.addClass("compact");
    table_div.addClass('table-striped');
}

function getDiseaseHref(protein_id, disease, tooltip){
    return "<a href=\""+diseaseURL+""+protein_id+"\"target=\"_blank\" title=\""+tooltip+"\">"+disease+"</a>";
}
function getExpressionHref(protein_id){
    return "<a href=\""+expressionURL+""+protein_id+"\"target=\"_blank\">"+protein_id+"</a>";
}
function getPubmedHref(pubmed_id){
//  var pubmedURL="https://www.ncbi.nlm.nih.gov/pubmed/";
  return "<a href=\""+pubmedURL+""+pubmed_id+"\"target=\"_blank\">"+pubmed_id+"</a>";

}


function getEnsemblHref(ensId, id){
    var alert_onclick="";
    var build=$("#build").val();
    var re=new RegExp(build);
    if(!(build.match("38"))){
	alert_onclick="onclick=\"alert('Note that you are being redirected to Ensembl genome build 38!')\"";
    } 
    return "<a href=\""+ensemblURL+""+ensId+"\"target=\"_blank\""+alert_onclick+"\">"+id+" </a>";
}

function getUCSCHref(chr, to, from){
    var alert_onclick="";
    var build=$("#build").val();
    var re=new RegExp(build);
    if(!(build.match("38"))){
        alert_onclick="onclick=\"alert('Note that you are being redirected to UCSC genome build 38!')\"";
    }
    return "<a href=\""+ucscURL+""+chr+"%3A"+from+"-"+to+"\"target=\"_blank\">U</a>";
}

function getTairHref(tairURL, name){
  var tair=tairURL+""+name.replace("-TAIR-G","")+"&sub_type=gene";
  return "<a href=\""+tair+"\"target=\"_blank\" >T</a> ";
}
function getdbSNPHref(rs_id){
  return "<a href=\""+dbSNP_URL+""+rs_id+"\"target=\"_blank\">"+rs_id+"</a>";
}
function getNascHref(nascURL, name){
  return "<a href=\""+nascURL+""+name+"\"target=\"_blank\" >N</a>";
}
function getRgdHref(rgdURL, rgdId){
  return "<a href=\""+rgdURL+""+rgdId+"\"target=\"_blank\" >R</a>";
}
