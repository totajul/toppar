var database;
var chr_names;
var chr_lengths;
var chr_ends;
var x_to_gl;
var x_from_gl;
var pop_data;
var menus;
var label2pheno = {};
var build;

//INITIATE MENUS and Menu functions
$(function() {
    $("select#build").change(function() {
        initPopulationMenu();
    });
});

$(function() {
    $("select#population").change(function() {
        initFilterMenus(pop_data);
        populateMenusOnChange();
    });
});

function getAllLabelsInDB() {
    try {
	var script = getAllLabels_cgi;
	$.ajax({
                type: "GET",
		    url: script,
		    success: function(jsonFile) {
                    try {
                        all_labels=[];
                        all_labels_info=[];
                        $.getJSON(jsonFile, function(data) {
				$.each(data, function(i, d){
					all_labels.push(d[0]);
					var tmp=[d[0], d[1], d[2]];  //{"\"build\":"+d[1], \"pop\":"+ d[2], "\"label\":" +d[0]]};
					all_labels_info.push(tmp);
				    });
			    });
                    } catch (e) {
                        alert("error when reading jsonFile " + e);
                    }
                }
            });
    } catch (e) {
	alert("error when running "+script+ " " + e);
    }
}


$(function() {
    $("select#phenotype").change(function() {
        var phenoInd = $(this).val();
        var f1 = [];
        var f2 = [];
        var f3 = [];
        var labels = [];
        $.each(phenoInd, function(i, phenoI) {
            f1 = addData(f1, menus[phenoI].f1s);
            $.each(menus[phenoI].f1s, function(j, f1_j) {
                f2 = addData(f2, f1_j.f2s);
                $.each(f1_j.f2s, function(k, f2_k) {
                    f3 = addData(f3, f2_k.f3s);
                    $.each(f2_k.f3s, function(h, labels_h) {
                        labels = addData(labels, labels_h.label);
                    });
                });
            });
        });
        populateDropDown3($('select#f1'), f1);
        populateDropDown3($('select#f2'), f2);
        populateDropDown3($('select#f3'), f3);
        populateDropDown3($('select#label'), labels);
    });
});

function getSubMenuf2() {
    var subMenu = [];
    var p_items = $("select#phenotype option:selected").map(function() {
        return $(this).text();
    }).get();
    var f1_items = $("select#f1 option:selected").map(function() {
        return $(this).text();
    }).get();
    $.each(menus, function(i, menu) {
        $.each(p_items, function(j, p) {
            if (menu.name === p) {
                $.each(menu.f1s, function(k, f1) {
                    $.each(f1_items, function(h, f1_sel) {
                        if (f1.name === f1_sel) {
                            subMenu.push({
                                name: menu.name,
                                f1s: [{
                                    name: f1.name,
                                    f2s: f1.f2s
                                }]
                            });
                        }
                    });
                });
            }
        });
    });
    return subMenu;
}

function getSubMenuf3() {
    var subMenuf2 = getSubMenuf2();
    var subMenu = [];
    var f2_items = $("select#f2 option:selected").map(function() {
        return $(this).text();
    }).get();
    $.each(subMenuf2, function(i, menu) {
        $.each(menu.f1s, function(j, f1) {
            $.each(f1.f2s, function(k, f2) {
                $.each(f2_items, function(h, f2_item) {
                    if (f2.name === f2_item) {
                        subMenu.push({
                            name: menu.name,
                            f1s: [{
                                name: f1.name,
                                f2s: [{
                                    name: f2.name,
                                    f3s: f2.f3s
                                }]
                            }]
                        });
                    }
                });
            });
        });
    });
    return subMenu;

}

function getSubMenuLabel() {
    var subMenuf3 = getSubMenuf3();
    var subMenu = [];
    var f3_items = $("select#f3 option:selected").map(function() {
        return $(this).text();
    }).get();
    $.each(subMenuf3, function(i, menu) {
        $.each(menu.f1s, function(j, f1) {
            $.each(f1.f2s, function(k, f2) {
                $.each(f2.f3s, function(h, f3) {
                    $.each(f3_items, function(l, f3_item) {
                        //$.each(f3.label, function(o, label){
                        if (f3.name === f3_item) {
                            subMenu.push({
                                name: menu.name,
                                f1s: [{
                                    name: f1.name,
                                    f2s: [{
                                        name: f2.name,
                                        f3s: [{
                                            name: f3.name,
                                            label: f3.label
                                        }]
                                    }]
                                }]
                            });
                        }
                        //  });
                    });
                });
            });
        });
    });
    return subMenu;
}

function addData(myArray, items) {
    for (var i = 0; i < items.length; i++) {
        myArray.add(items[i].name);
    }
    return myArray;
}

$(function() {
    $("select#f1").change(function() {
        var f2 = [];
        var f3 = [];
        var labels = [];
        var subMenu = getSubMenuf2();
        $.each(subMenu, function(i, m) {
            $.each(m.f1s, function(k, f1) {
                f2 = addData(f2, f1.f2s);
                $.each(f1.f2s, function(k, f2k) {
                    f3 = addData(f3, f2k.f3s);
                    $.each(f2k.f3s, function(h, labels_h) {
                        labels = addData(labels, labels_h.label);
                    });
                });
            });
        });
        populateDropDown3($('select#f2'), f2);
        populateDropDown3($('select#f3'), f3);
        populateDropDown3($('select#label'), labels);
    });
});

$(function() {
    $("select#f2").change(function() {
        var subMenu = getSubMenuf3();
        var f3 = [];
        var labels = [];
        $.each(subMenu, function(i, m) {
            $.each(m.f1s, function(k, f1) {
                $.each(f1.f2s, function(k, f2k) {
                    f3 = addData(f3, f2k.f3s);
                    $.each(f2k.f3s, function(h, labels_h) {
                        labels = addData(labels, labels_h.label);
                    });
                });
            });
        });
        populateDropDown3($('select#f3'), f3);
        populateDropDown3($('select#label'), labels);
    });
});

$(function() {
    $("select#f3").change(function() {
        var subMenu = getSubMenuLabel();
        var labels = [];
        $.each(subMenu, function(i, m) {
            $.each(m.f1s, function(k, f1) {
                $.each(f1.f2s, function(k, f2k) {
                    $.each(f2k.f3s, function(h, labels_h) {
                        labels = addData(labels, labels_h.label);
                    });
                });
            });
        });
        populateDropDown3($('select#label'), labels);
    });
});

Array.prototype.add = function(element) {
    var itemExists = false;
    for (var i = 0; i < this.length; i++) {
        if (this[i] == element) {
            itemExists = true;
            break;
        }
    }
    if (itemExists == false)
        return this.push(element);
}

function populateDropDown3(drop, items) {
    drop.empty();
    for (var i = 0; i < items.length; i++) {
        drop.append('<option value=' + i + '>' + items[i] + '</option>');
    }
    drop.show();
}

function populateDropDown(drop, items) {
    for (var i = 0; i < items.length; i++) {
        drop.append('<option value=' + i + '>' + items[i].name + '</option>');
    }
}

//populates the population menu on start up
function initGenomeBuildMenu() {
    var options = '';
    try {
        var script = getGenomeBuild_cgi;
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonFile) {
                try {
                    $.getJSON(jsonFile, function(data) {
                        var options = '';
                        for (var i = 0; i < data.length; i++) {
                            var selected = "";
                            if (i === 0) {
                                selected = ' selected="selected"';
                                options += '<option value="' + data[i].name + '"' + selected + '>' + data[i].name + '</option>';
                                build = data[i].name;
                            } else {
                                options += '<option value="' + data[i].name + '">' + data[i].name + '</option>';
                            }
                        }
                        $("select#build").html(options);
			initPopulationMenu();
			});
                } catch (e) {
                    alert("error when reading jsonFile " + e);
                }
            }
        });
    } catch (e) {
        alert("error when running getGenomeBuild.cgi " + e);
    }
}

function initPopulationMenu() {
    if ($("#build").val()) {
        build = $("#build").val();
    }
    try {
        var script = getPopulation_cgi + '?build=' + build;
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonFile) {
                try {
                    $.getJSON(jsonFile, function(data) {
                        var options = '';
                        for (var i = 0; i < data.length; i++) {
                            options += '<option>' + data[i].name + '</option>';
                        }
                        $("select#population").html(options);
                        initFilterMenus(data);
                        populateMenusOnChange();
                    });
                } catch (e) {
                    alert("error when reading jsonFile " + e);
                }
            }
        });
    } catch (e) {
        alert("error when running populateMenus.cgi " + e);
    }
}

function initFilterMenus(data) {
    //get selected population
    pop_data = data;
    var pop = $("#population").val();
    $("#phenotype").empty();
    $("#label").empty();
    var filter_names = "";
    var filters_menu = "";
    var filters = [];
    var filter_ids = ["f1", "f2", "f3"];
    var filter_th_ids = ["f1_th", "f2_th", "f3_th"];
    //first hide all and then show the right number of filters
    //empty menus
    for (var i = 0; i < filter_ids.length; i++) {
        $("#" + filter_ids[i]).hide();
        $("#" + filter_th_ids[i]).hide();
    }
    for (var i = 0; i < data.length; i++) {
        var d = data[i];
        if (d.name === pop) {
            for (var j = 0; j < d.filters.length; j++) {
                var filter = d.filters[j];
                $("#" + filter_th_ids[j]).show();
                $("#" + filter_th_ids[j]).html(filter);
                $("#" + filter_ids[j]).empty();
                $("#" + filter_ids[j]).show();
            }
            i = data.length;
        }
    }
}

function populateDropDown2(drop, items) {
    //drop.empty();
    for (var i = 0; i < items.length; i++) {
        drop.append('<option value=' + i + '>' + items[i] + '</option>');
    }
    drop.show();
}

//populateMenusOnChange is called whenever there is a change in the selection menus
function populateMenusOnChange() {
    if ($("#build").val()) {
        build = $("#build").val();
	if(build !== "GRCh38"){
	    alert("Since you are not using build it is worth noting that the gwascatalog data shown is mapped to build GRCh38 and the links to UCSC and Ensembl also refer to build 38. LD calculations can only be shown for build 38. To be able to use this feature, you can do a liftover of your data and re-upload.");
	}
    }
    $("#region").hide();
    $("#regionPlots").empty();
    $("#genomePlots").empty();
    $("#backToGenome").hide();
    $("#backToRegion").hide();
    $("#message").empty();
    try {
        var pop = $("#population").val();
        var script = populateMenus_cgi + "?pop=" + pop + "&build=" + build;
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonFile) {
                //    $.get(populateMenus_cgi ,{pop:pop,build:build,database:database}, function(jsonFile) {
                try {
                    $.getJSON(jsonFile, function(data) {
                        data = data.jsonobj;
                        menus = data;
                        var f1a = [];
                        var f2a = [];
                        var f3a = [];
                        var labels_a = [];
                        populateDropDown($('select#phenotype'), data);
                        for (var i = 0; i < data.length; i++) {
                            var f1s = data[i].f1s;
                            var pheno = data[i].name;
                            f1a = addData(f1a, f1s);
                            for (var j = 0; j < f1s.length; j++) {
                                var f2s = f1s[j].f2s;
                                f2a = addData(f2a, f2s);
                                for (var k = 0; k < f2s.length; k++) {
                                    var f3s = f2s[k].f3s;
                                    f3a = addData(f3a, f3s);
                                    for (var h = 0; h < f3s.length; h++) {
                                        var labels = f3s[h].label;
                                        labels_a = addData(labels_a, labels);
                                        label2pheno[labels[0].name] = pheno;
                                    }
                                }
                            }
                        }
                        populateDropDown2($('select#f1'), f1a);
                        populateDropDown2($('select#f2'), f2a);
                        populateDropDown2($('select#f3'), f3a);
                        populateDropDown2($('select#label'), labels_a);

                    });
                } catch (e) {
                    alert("ERROR " + e);
                }
            }
        });
    } catch (err) {
        alert("ERROR AJAX " + err);
    }
    chromosomeMenu(build);
    $('#noData').empty();
    $('#noDataFor').hide();
    $("#regionBtns").hide();
    //$("#genomePlots").hide();
    // $("#regionPlots").hide();
    //$("#backToGenome").hide();
    //$("#backToRegion").hide();

}

function getScanTypes() {
    var build = $("#build").val();
    var pop = $("#population").val();
    var phenotypes = $("#phenotype").val();
    var labels = $("select#label option:selected").map(function() {
        return $(this).text();
    }).get();
    try {
        var script = populateMenus_cgi + "?pop=" + pop + "&build=" + build + "&phenotype=" + phenotypes + "&database=" + database;
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonfile) {
                try {
                    $.getJSON(jsonfile, function(data) {
                        var options = '';
                        for (var i = 0; i < data.label.length; i++) {
                            options += '<option >' + data.label[i] + '</option>';
                        }
                        $("select#label").html(options);
                        options = '';
                        if (data.f1 !== undefined) {
                            for (var i = 0; i < data.f1.length; i++) {
                                options += '<option >' + data.f1[i] + '</option>';
                            }
                            $("select#f1").html(options);
                        }
                        options = '';
                        if (data.f2 !== undefined) {
                            for (var i = 0; i < data.f2.length; i++) {
                                options += '<option >' + data.f2[i] + '</option>';
                            }
                            $("select#f2").html(options);
                            options = '';
                        }
                        if (data.f3 !== undefined) {
                            for (var i = 0; i < data.f3.length; i++) {
                                options += '<option >' + data.f3[i] + '</option>';
                            }
                            $("select#f3").html(options);
                        }

                    });
                } catch (err) {
                    alert("error " + err);
                }
            }
        });
    } catch (e) {
        alert("error " + e);
    }
}

//chromosomeMenu is called upon startup to populate the chromosome menu and create placeholders for multiple graph display
function chromosomeMenu(build) {
    chr_names = [];
    chr_lengths = [];
    $.get(getChr_cgi, {
        build: build,
        database: database
    }, function(jsonFile) {
        try {
            $.getJSON(jsonFile, function(data) {
                var options = '';
                var sum = 0;
                $.each(data.chr, function(i, c) {
                    chr_names.push(c[0]);
                    chr_lengths.push(c[1]);
                    options += '<option >' + c[0] + '</option>';

                })
                $("select#chromosomes").html(options);
                setChrEnds();
            });
        } catch (e) {}
    });
}

function showhide(id) {
    var obj;
    if (document.getElementById) {
        obj = document.getElementById(id);
        if (obj.style.display == "none")
            obj.style.display = "";
        else
            obj.style.display = "none";
    }
}

$(document).ajaxStart(function() {
    $("#ajaxBusy").show();
}).ajaxStop(function() {
    $("#ajaxBusy").hide();
});

function emptyTxtBoxes() {
    $("#snp").val("");
    $("#gene_symbol").val("");
    $("#coord").val("");
}

//select the first items in the menus if none are selected
function checkSelection() {
    var labels = $("select#label option:selected").map(function() {
        return $(this).text();
    }).get();
    if (labels.length == 0) {
        $("#label option")[0]['selected'] = true;
    }
    //getScanTypes();
}

function rangeOk(maxRange) {
    if (typeof(x_from_gl) != "undefined") {
        if (parseInt(x_to_gl) - parseInt(x_from_gl) < maxRange) {
            return true;
        }
    }
    return false;
}

function remove(array, from, to) {
    var rest = array.slice((to || from) + 1 || array.length);
    array.length = from < 0 ? array.length + from : from;
    return array.push.apply(array, rest);
};

function addLabelToTxtBox() {
    var txtBox = $("#coord");
    $('input[title]').each(function() {
        if (txtBox.val() === '') {
            txtBox.val(txtBox.attr('title'));
            //adds the title to the text box
        }
        txtBox.focus(function() {
            // alert("focus title--"+txtBox.attr('title')+"---val--"+txtBox.val());
            // txtBox.val('');
            if (txtBox.val().substring(0, 2) === 'eg') { // txtBox.attr('title')){
                txtBox.val('').addClass('focused'); //removes title text on click
            }
        });
        txtBox.blur(function() {
            if (txtBox.val() === '') {
                txtBox.val(txtBox.attr('title')).removeClass('focused');
            }
        });
    });
}

function goTo(type) {
    var orig_name;
    var name;
    var script;

    if (type == "snp") {
        orig_name = $("#snp").val();
        script = getSnp_cgi;
    } else if (type == "gene") {
        orig_name = $("#gene_symbol").val();
        script = getGene_cgi;
    }
    var name = orig_name.toLowerCase();
    var build = $("#build").val();
    var currentChr = $("#chromosomes").val();
    if ($("#genome:visible").length > 0)
        currentChr = 0; //in genome view, no chromosome is selected
    try {
        $.ajax({
            type: "GET",
            url: script + "?name=" + name + "&database=" + database + "&build=" + build,
            success: function(response) {
                if (response != "") {
                    var row = response.split(",");
                    var name = row[0];
                    var chr = row[1].replace(/ /g, "");
                    var bp_pos = row[2].replace(/ /g, "");
                    var from;
                    var to;

                    if (type == "snp") {
                        from = parseInt(bp_pos) - 500;
                        to = parseInt(bp_pos) + 500;
                    } else {
                        from = parseInt(bp_pos) - 1000;
                        to = parseInt(row[3].replace(/ /g, "")) + 1000;
                    }
                    if (chr == currentChr) {
                        zoomToRange({
                            xaxis: {
                                from: from,
                                to: to
                            },
                            yaxis: {}
                        });
                    } else {
                        $("#chromosomes").val(chr);
                        geneExonMarkings = [];
                        genesSeen = [];
                        getRegion(chr, from, to);
                    }
                } else
                    alert(orig_name + " not found");
            }
        });
    } catch (e) {
        alert("error when running " + script + " " + e);
    }
}

function goToCoord() {
    var coord = $("#coord").val();
    // coord = coord.replace(/ /g, ""); //remove all white spaces
    var chr;
    var values = [];
    values = coord.split("\.\.");
    var val2 = [];
    val2 = values[0].split(":");
    var from;
    if (val2.length > 1) {
        //chromosome defined;
        chr = val2[0];
        // $("#chromosomes").val(chr);
        values[0] = val2[1];
    }
    var to = 0;
    if (values.length == 2) {
        from = getValueInCorrectFormat(values[0]);
        to = getValueInCorrectFormat(values[1]);
    } else
        to = getValueInCorrectFormat(values[0]);
    if (!from)
        alert("incorrect format!");
    if (to > from)
        zoomToRange({
            xaxis: {
                from: parseInt(from),
                to: parseInt(to)
            },
            yaxis: {}
        });
}

function getValueInCorrectFormat(val) {
    var tmpVal = val.split(".");
    if (tmpVal.length == 2) {
        tmpVal[0] += addZeros(tmpVal[1]);
        return tmpVal[0];
    }
    return val; //use value as it is
}

function addZeros(tail) {
    while (tail.length < 6) {
        tail += "0";
    }
    return tail;
}
function change_menu(id){
    var label=$("#menus_label");
    label.empty();
    $(".snp_label").remove();   //remove outstanding marker labels
    $("#tooltip").remove();
    if (id === "lookup_menu"){ //show the lookup menu and hide the currently displayed filter menu
        label.append("<a id=\"menu_label_href\" href=\"#\" onclick=\"change_menu('filter_menu'); return(false);\">Change to Filter Menu.\
..</a>");
        $("#filter_menu").hide();
        $("#lookup_menu").show();

	$("#find_lists").autocomplete({
	     source: all_labels,
	          minLength: 2
	       });

    }
    else{ //show the filter menu and hide the lookup menu
        label.append("<a id=\"menu_label_href\" href=\"#\" onclick=\"change_menu('lookup_menu'); return(false);\">Change to Lookup Menu.\
..</a>");
        $("#lookup_menu").hide();
        $("#filter_menu").show();
    }
}
