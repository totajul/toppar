
var plots = [];
var genomePlots = [];
var geneMarkings = [];
var exonMarkings = [];
var markerPlot = [];
var annotMarkings = [];
var annotMarkingsArray = [];
var annotMax;
var markerScores = [];
var genesSeen = []; //empty this array when we get new gene data
var noGenesOnDisplay = 1000;
var currentScore = "MAF";
var thresholdLog10=7.30103; //5e-08

function show_regionBtns() {
    $("#regionBtns").show();
}
function hide_regionBtns() {
    $("#regionBtns").hide();
}

function getData() {
    $("#regionBtns").show();
    if ($("#radio_region").is(":checked")) {
        //check whether gene,chr or coord are checked
        getRegion();
    } else {
        //select genome if nothing has been selected
        $("#radio_genome").is(":checked", true);

        getGenome();
    }
}

function getRegion(chr, from, to) {
  console.log("calling getPlotData from getRegion");
    if (!from)
        emptyTxtBoxes();
    $("#regionPlots").show();
    $("#annotation").empty();
    $("#tooltip").remove(); //remove any outstanding tooltips
    $(".marker_label").remove(); //remove outstanding marker labels
    if (!chr) {
        chr = $("#chromosomes").val();
        if (!chr)
            chr = "1"; //use chromosome 1 as default if no value has been selected
    }
    if (!from) {
        from = 0;
        to = getChrLength(chr);
    }
    prepareRegionHolder();
    getPlotData(false, chr, from, to);
}

function prepareRegionHolder() {
    $("#region").show();
    $("#regionPlots").empty();
    $("#radio_region").prop('checked', true);
    $("#other").prop('checked', false);
    $("#high").prop('checked', false);
    $("#low").prop('checked', false);
    $("#moderate").prop('checked', false);
    // $("#radio_genome").prop('checked' , false);
    addLabelToTxtBox();
    $("#genes").empty();
    $("#message").empty();
    $("#markers").empty();
    $("#markers").hide();
    $("#markerCB").prop("disabled", true);
    var children = document.getElementById("genomePlots").childNodes;
    if (children.length > 0)
        $("#backToGenome").show();
    $("#genome").hide();
    $("#traitLociTable").hide();
}

function prepareGenomeHolder() {
    $("#region").hide();
    $("#genomePlots").empty();
    //$("#regionBtns").show();
    $(".marker_label").remove(); //remove outstanding marker labels
    addLabelToTxtBox();
    $("#message").empty();
    $("#markers").empty();
    $("#markers").hide();
    var children = document.getElementById("regionPlots").childNodes;
    if (children.length > 0)
        $("#backToRegion").show();
    $("#genome").show();
    $("#traitLociTable").hide();
}

function backToGenomeView() {
    $("#region").hide();
    $("#genome").show();
    var children = document.getElementById("regionPlots").childNodes;
    if (children.length > 0)
        $("#backToRegion").show();

}

function backToRegionView() {
    $("#genome").hide();
    $("#backToGenome").show();
    $("#region").show();
    $("#radio_region").is("checked", true);
    show_regionBtns();
    var children = document.getElementById("genomePlots").childNodes;
    if (children.length > 0)
        $("#backToGenome").show();
}

//getGenomes when the genome button is clicked
function getGenome() {
    $("#tooltip").remove();
    $("#genomePlots").show();
    checkSelection();
    prepareGenomeHolder();
    console.log("Calling getPlotData from getGENOME")
    getPlotData(true, "null");
}

function getMatchingPhenos(labels) {
    var phenos = [];
    $.each(labels, function(i, label) {
        phenos.add(label2pheno[label]);
    });
    return phenos;
}

function arrayContains(phenoArray, pheno) {
    var itemFound = false;
    for (var i = 0; i < phenoArray.length; i++) {
        if (phenoArray[i] === pheno) {
            itemFound = true;
            break;
        }
    }
    return itemFound;
}

function labelMatchesPheno(label, pheno) {
    var itemFound = false;
    if (label2pheno[label] === pheno) {
        itemFound = true;
    }
    return itemFound;
}

function getPlotData(condensed, chr, from, to) {
     console.log("CALLING getPLOTDATA "+condensed);
    var build = $("#build").val();
    var pop = $("#population").val();
    var phenotype = $("select#phenotype option:selected").map(function() {
        return $(this).text();
    }).get();
    var labels = $("select#label option:selected").map(function() {
        return $(this).text();
    }).get();
    if (labels == "") {
        $("#label").prop("selectedIndex", 0);
        labels[0] = $("#label option:selected").text();
    }
    if (phenotype == "") {
        $("#phenotype").prop("selectedIndex", 0);
        phenotype[0] = $("#phenotype option:selected").text();
    }
    $("#noDataFor").hide();
    $("#noData").empty();
    var filesLookedAt = 0;
    if (condensed)
        genomePlots = [];
    else
        plots = [];
    //create phenotype label map in init - only get data if label is in phenotype
    var matchingPhenos = getMatchingPhenos(labels);
    $.each(phenotype, function(phenoIndex, pheno) {
        if (arrayContains(matchingPhenos, pheno)) {
            var plot = new Plot(phenoIndex, chr, condensed, from, to, pheno);
            var counter = 0;
            if (condensed)
                genomePlots.push(plot);
            else
                plots.push(plot); //plots are stored in a global array
            $.each(labels, function(typeIndex, label) {
		    if (labelMatchesPheno(label, pheno)) {
			try {
			    var script = getData_cgi + "?build=" + build + "&pop=" + pop + "&chr=" + chr + "&pheno=" + pheno + "&label=" + label + "&condensed=" + condensed;
			    $.ajax({
				    type: "GET",
					url: script,
					success: function(jsonfile) {
					if (jsonfile.substring(2, 0).toLowerCase() == "no") { // No data for scantype or no data for chromosome?
					    plot.addNoData(label);
					    filesLookedAt++;
					    if (filesLookedAt == (labels.length))
						if (condensed)
						    plotData(genomePlots, condensed);
						else
						    plotData(plots, condensed, from, to);
					} else {
                                    try {
                                        $.getJSON(jsonfile, function(d) {
						if(condensed){
						    var series = new Series(typeIndex, "circle", "other");
                series.maxScore=d.maxScore;
                series.data=d.data;
						    series.label=d.label;
						    plot.addSeries(series);
						}
						else{
						    var seriesArray_by_impact=create_series_by_impact(d, typeIndex, condensed);
						    plot.addSeriesArray(seriesArray_by_impact);
						}
						filesLookedAt++;
						counter++;
						if (filesLookedAt == (labels.length)) {
						    if (condensed)
							plotData(genomePlots, condensed);
                                                else {
                                                    plotData(plots, condensed, from, to);
                                                    //getMarkers(build, pop, chr, database,plots);
                                                }
                                            }
                                        });
                                    } catch (err) {
                                        alert("error " + err);
                                    }
                                }
                            }
                        });
                    } catch (err) {
                        ("ERROR " + err);
                    }
                }
            }); //each scantype
        }
    }); //each phenotype
    getMarkers(build, pop, chr, database);
}

function create_series_by_impact(d, typeIndex, condensed){
    var series_by_impact=[];
    var series = new Series(typeIndex, "circle", "other");
    var serHigh = new Series(typeIndex, "diamond", "high");
    var serLow = new Series(typeIndex, "square", "low");
    var serMod = new Series(typeIndex, "triangle", "moderate"); //cross;
    $.each(d.data, function(k, dp) {
	    if (dp[4] !== null) {
		if (dp[4] === "LOW")
		    serLow.data.push(dp);
		else if (dp[4] === "MODERATE")
		    serMod.data.push(dp);
		else if (dp[4] === "HIGH")
		    serHigh.data.push(dp);
		else
		    series.data.push(dp);

	    } else
		series.data.push(dp);
	});
    series.origData = series.data;
    serLow.origData = serLow.data;
    serHigh.origData = serHigh.data;
    serMod.origData = serMod.data;
    series.mkLeadSeries(d, " :(" + d.data.length + "/" + serLow.data.length + "/" + serMod.data.length + "/" + serHigh.data.length + ")");
    series_by_impact.push(series, serLow, serHigh, serMod);
    return series_by_impact;
}



function getMarkers(build, pop, chr, database) {
    try {
        var marker_script = getMarkers_cgi + "?build=" + build + "&pop=" + pop + "&chr=" + chr;
        $.ajax({
            type: "GET",
            url: marker_script,
            success: function(jsonfile) {
                try {
                    $.getJSON(jsonfile, function(d) {
                        var markersArray = groupByMarkerType(d.data, d.scores);
                        markerScores = d.scores;
                        markerPlot = new Plot("1", chr);
                        markerPlot.addMarkers(markersArray);
                        markerPlot.placeHolder = "markerPlot";
                        var options = '<option selected value="' + currentScore + '">' + currentScore + '</option>';
                        for (var i = 0; i < markerScores.length; i++) {
                            options += '<option value="' + markerScores[i] + '">' + markerScores[i] + '</option>';
                        }
                        $("select#marker_score").html(options);

                    });
                } catch (err) {
                    alert("error " + err);
                }
            }
        });
    } catch (err) {
        alert("error " + err);
    }
}


function groupByMarkerType(markers, scores) {
    var other = [];
    var counter = 0;
    var cats = {};
    var count = 1;
    var moreScores = {};
    var annot_cats=[{"name": "other", "color": "gray", "symbol":"circle"},{"name": "LOW", "color":"#FF9900","symbol":"square"},{"name":"MODERATE","color":"#CF5300","symbol":"triangle"},{"name":"HIGH","color":"#FF0000","symbol":"triangle"}];
    //make an array for each score category
    $.each(scores, function(i, score) {
        moreScores[score] = [];
    });
    //create an array for each impact category
    $.each(annot_cats, function(i, cat) {
        cat.count = count;
        cats[cat.name] = [];
        count++;
    });
    $.each(markers, function(i, m) {
	var type=m[3];
        var match = 0;
        var test = 0;
        if (m[5].length > 0) {
            var scoresHash = {
                [currentScore]: m[1]
            };
            var scoresArray = m[5].split(";");
            $.each(scoresArray, function(i, score) {
                var keyval = score.split(":");
                var myKey = keyval[0];
                var myVal = keyval[1];
                if (myVal == "NA") {
                    myVal = 0;
                }
                scoresHash[myKey] = parseFloat(myVal);
            });
            test = 1;
            m[6] = scoresHash;
        }
        $.each(annot_cats, function(j, cat) {
		if(type === cat.name){
		    cats[cat.name].push(m);
		    match = 1;
		}
      });
        if (!(match)) {
	    cats["other"].push(m);
        }
    });
    var markers_grouped = [];
    //loop through array in the reverse order;
    var i = annot_cats.length;
    while (i--) {
        cat = annot_cats[i];
        markers_grouped.push({
            label: cat.name + ":  " + cats[cat.name].length,
            data: cats[cat.name],
            color: cat.color,
            points: {
		    show: true,
		    symbol: cat.symbol
            }
        });
    }
    return markers_grouped;
}


function plotData(p, condensed, from, to) {
    var thereIsData = 0;
    var html;
    var phenotype = $("#phenotype").val();
    var scantypes = $("#label").val();
    $.each(p, function(i, plot) {
        //initColorsAndDisplay(plot.seriesArray);
        if (plot.seriesArray.length > 0) {
            thereIsData = 1;
            if (condensed) {
                $("#genomePlots").append(setGenomePlotDivs(plot));
                addGenomeStyles(plot.phenoIndex);
                plotGenome(plot);
            } else {
                $("#regionPlots").append(setSinglePlotDivs(plot));
                addStyles(plot.phenoIndex);
                if ($("#gwasCB").is(":checked")) {
                    addGWASseries(plot);
                }
                plotSinglePlot(plot);
            }
        }
    });
    if (!condensed) {
        if (thereIsData) {
            addGenesPlot(plots[0], from, to);
            $("#markers").append(setMarkerPlotDiv());
            //add2ndGenePlot(plots[0],from,to);
            bindSinglePlots(plots);
            //includeGbrowse();
        }
    }
}

function condense(seriesArray, limit) {
    $.each(seriesArray, function(i, series) {
        if (series.origData.length > limit)
            series.data = condenseData2(series.origData);
        else
            series.data = series.origData;
    });
}

function plotGenome(plot) {
    var phenoIndex = plot.phenoIndex;
    var plotName = $("#genomePlot" + phenoIndex); //mainPlot0
    plotName.show();
    plot.labelsDiv = $("#mlabels" + phenoIndex);
    $("#unitG" + phenoIndex).empty();
    $("#unitG" + phenoIndex).show();
    $("#genomeLabel" + phenoIndex).show();
    plot.labelsDiv.show();

    $("#unitG" + phenoIndex).append(plot.seriesArray[0].unit);
    try {
        plot.flotplot = $.plot(plotName, plot.seriesArray, getMultiPlotOptions(plot.labelsDiv, plot.seriesArray));

    } catch (e) {
        alert("ERROR in function plotGenome: " + e);
    }
    addChrLabelsToGenome(plot);
    addEvalueDivs(plot);
    bindGenomePlotClick(plotName, plot)
    bindGenomePlotHover(plotName, plot);
}

function displayRegionForChr(pos) {
    var lastPos = getChrEnd(chr_names.length - 1);
    var chrStart=0;
    for (var i = 0; i < getNoOfChr(); i++) {
      if(i > 0)
          chrStart=getChrEnd(i-1);
          if (pos < getChrEnd(i)  && pos > chrStart) {
            $("#chromosomes").val(getChr(i));
            getRegion(getChr(i));
            break;
              //i = getNoOfChr();
        }
        lastPos = getChrEnd(i);
    }
}

function condenseData2(data) {
    var noOfDataPoints = data.length - 1; //TODO: shouldnt have to be "-1"
    var points = 1000;
    var interval = Math.round(noOfDataPoints / points);
    var dataRows = [];
    // data.sort();
    for (var i = 0; i < noOfDataPoints; i = i) {
        var minScore = 100;
        var dataMin = [];
        var maxScore = 0;
        var dataMax = [];
        for (var j = 0; j < interval; j++) {
            if (i < noOfDataPoints) {
                var score = data[i][1];
                if (score < minScore) {
                    minScore = score;
                    dataMin = data[i];
                }
                if (score > maxScore) {
                    maxScore = score;
                    dataMax = data[i];
                }
            }
            i++;
        }
        if (dataMax[0] > dataMin[0]) {
            dataRows.push(dataMin);
            dataRows.push(dataMax)
        } else {
            dataRows.push(dataMax);
            dataRows.push(dataMin);
        }
    }
    return dataRows;
}

function addStyles(pi) {
    $("#mainPlot" + pi).addClass('regionPlot');
    $("#markerPlot").addClass('markerPlot');
    $("#overview" + pi).addClass('overviewPlot');
    $("#unit" + pi).addClass('verticalTxt');
}

function addGenomeStyles(phenoIndex) {
    //    $('#genomeLabel' + phenoIndex).addClass('graphTxt');
    $('#unitG' + phenoIndex).addClass('verticalTxt');
}

function plotSinglePlot(plot) {
    if ($("#unit" + plot.phenoIndex).text() == '')
        $("#unit" + plot.phenoIndex).append(plot.seriesArray[0].unit);
    plot.labelsDiv = $("#labels" + plot.phenoIndex);

    //do the plotting
    plot.options = getSinglePlotOptions(plot.labelsDiv, plot.seriesArray, 0, getChrLength(plot.chr)); //same for all series??

    plot.flotplot = $.plot($("#" + plot.placeHolder), plot.seriesArray, plot.options);

    //make the points smaller for the overview plot
    changeRadius(plot.seriesArray, 0.2);
    var overview_serArray = [];
    //make a copy of the seriesArray for the overview plot and point data to the original data
    $.each(plot.seriesArray, function(i, series) {
        var s = series;
        s.data = series.origData;
        overview_serArray.push(s);
    });
    plot.overviewPlot = $.plot($("#overview" + plot.phenoIndex), overview_serArray, getOverviewOptions(getChrLength(plot.chr)));
    changeRadius(plot.seriesArray, 1);

    //add Buttons and Labels to the plot
    addZoomOutBtn(plot.placeHolder, plot.flotplot, plot.chr);
    addChrLabel(plot);
    //  addTraitLoci(plot, null);
    addEvalueDivs(plot);
}

function changeRadius(seriesArray, radius) {
    $.each(seriesArray, function(i, series) {
        series.points.radius = radius;
    });
}

function addChrLabel(plot) {
    var o = plot.flotplot.getPlotOffset();
    var axes = plot.flotplot.getAxes();
    var xc = axes.xaxis.p2c;
    $("#" + plot.placeHolder).append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + (o.top) + 'px;color:#666;font-size:smaller">' + plot.phenoType + ' - chr' + plot.chr + '</div>');
}

function addChrLabelsToGenome(plot) {
    var axes = plot.flotplot.getAxes();
    var xc = axes.xaxis.p2c;
    var yMax = plot.flotplot.getAxes().yaxis.max;
    //for chromosome 1
    o = plot.flotplot.pointOffset({
        x: 0,
        y: yMax
    });
    $("#" + plot.placeHolder).append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + o.top + 'px;color:#666;font-size:smaller">' + getChr(0) + '</div>');

    for (var i = 0; i < chr_names.length - 1; i++) {
        o = plot.flotplot.pointOffset({
            x: getChrEnd(i),
            y: yMax
        });
        $("#" + plot.placeHolder).append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + o.top + 'px;color:#666;font-size:smaller">' + getChr(i + 1) + '</div>');
    }
}

function setSinglePlotDivs(plot) {
    var pi = plot.phenoIndex;
    var html = "";
    plot.placeHolder = "mainPlot" + pi;
    plot.overviewPlaceHolder = "overview" + pi;
    plot.markersPlaceHolder = "marker" + pi;

    //Create all the elements, put unitDiv, and plotDiv into the first 2 columns of the maintable, the overview Div goes into the 3rd column
    //goes in main table, row 1 and column 1
    var unitDiv = '<div id="unit' + pi + '"></div>';
    //main table row 1 column 2
    var plotDiv = '<div id="mainPlot' + pi + '"></div>';

    //the third column of the main table contains a sub table with 1 column and 6 rows
    //overview plot is in the first row in the sub table
    var overview = '<div id="overview' + pi + '"></div>';
    //labels is in the 2nd row in the sub table
    var labels = '<div id="labels' + pi + '"></div>';
    //info is in the 3rd row of the sub table and the showAll checkbox in the 4rth row
    var info = '<div id="info' + pi + '"></div>';
    var showAllCheckBox = '<div  class="checkbox"><label><input onclick="showAll()" id="showAllcheckbox' + pi + '" type="checkbox" disabled>display all</label></div>';
    var showAll = '<div id="showAll' + pi + '">' + showAllCheckBox + '</div>';
    //the gwasDiv in the 5th row contains the gwasCheckbox
    var gwasCheckBox = '<div  class="checkbox" ><label><input id="gwasCB' + pi + '" onclick="plotGWASCatalog(\'' + pi + '\')" type="checkbox">show GWAS catalog SNPs</label></div>';
    var gwasDiv = '<div id="gwasCheckbox' + pi + '">' + gwasCheckBox + '</div>';
    //gwasColorLabel and gwasLabelText (textbox, select menu and submit btn) are in the 6th and 7th rows of sub table
    var gwasColorLabel = '<label id="gwasColorLabel' + pi + '" class="graphTxt">Color GWAS snp/s by trait:</label>';
    var gwasLabelText = '<div class="form-inline2"><input type="text"  placeholder="Ex: Ulcerative" id="gwasTermRegion' + pi + '" name="gwasTermRegion' + pi + '">';
    gwasLabelText += '<select class="form-control2" id="gwasColorSelectRegion' + pi + '"><option selected>red</option><option>purple</option><option>orange</option><option>lightblue</option><option>green</option><option>yellow</option><option>black</option></select><button type="submit" class="btn btn-smaller btn-info" onclick="gwasTermFilterRegion(\'' + pi + '\')">Submit</button> </div>';


    //put the elements in the table
    html += '<table><tr><td>' + unitDiv + '</td><td>' + plotDiv + '</td>';
    html += '<td valign="top"><table cellspacing="0" padding="0"><tr><td>' + overview + '</td></tr><tr><td>' + labels + '</td></tr>';
    html += '<tr style="height:1px"><td style="height:1px"><hr class="reducedPadding2"></td></tr>';
    html += '<tr><td>' + info + '</td></tr><tr style="height:20px"><td>' + showAll + '</td></tr>';
    html += '<tr><td><hr class="reducedPadding2" style="border-top: dotted 1px;"> </td></tr>';
    html += '<tr><td>' + gwasDiv + '</td></tr>';
    html += '<tr><td><hr class="reducedPadding2" style="border-top: dotted 1px;"> </td></tr>';
    html += '<tr><td>' + gwasColorLabel + '</td></tr><tr><td>' + gwasLabelText + '</td></tr><tr><td>&nbsp&nbsp&nbsp</td><tr>';
    html += '</table></table>';
    return html;
}

function setMarkerPlotDiv() {
    //var markerDiv='<div id="marker" style="display:none">
    var markerDiv = '<div id="spacefiller" style="display:none">&nbsp&nbsp&nbsp</div>';
    var markerTxt = '<div id="markerTxt" class="verticalTxt">SNPs</div>';
    var markerPlot = '<div id="markerPlot" class="markerPlot">';
    var marker_labels = '<td><div id="marker_labels"></div></td>';
    var html = markerDiv + '<table><tr><td>' + markerTxt + '</td><td>' + markerPlot + '</td><td>';
    //put menu and labels in a table in the third column
    html += '<table><tr><td><select id="marker_score" onchange=change_marker_score(this.value)></select></td></tr>';
    html += '<tr>' + marker_labels + '</tr></table>';
    //sub table ends
    html += '</td></table></div>';
    return html;
}

function setGenomePlotDivs(plot) {
    var phenoIndex = plot.phenoIndex;
    var label = '<span id="mlabels' + phenoIndex + '"></span>';
    plot.placeHolder = "genomePlot" + phenoIndex;
    var genomeLabel = '<span style="display:none" class="phenoLabel" id="genomeLabel' + phenoIndex + '">' + plot.phenoType + '</span>';
    var unitDiv = '<div id="unitG' + phenoIndex + '"></div>';
    $("#unitG" + phenoIndex).empty();

    var gwasCheckBox = '<div  class="checkbox" ><label><input id="gwasGenomeCB' + phenoIndex + '" onclick="plotGWASCatalogGenome(\'' + phenoIndex + '\')" type="checkbox">show GWAS catalog SNPs</label></div>';

    //var gwasCheckBox='<input id="gwasGenomeCB'+phenoIndex+'" type="checkbox" class="graphTxt" onclick="plotGWASCatalogGenome(\''+phenoIndex+'\')">show GWAS catalog SNPs</input></div>'; -->

    var gwasDiv = '<div id="gwasGenomeCheckbox' + phenoIndex + '" class="graphTxt">' + gwasCheckBox + '</div>';

    var gwasColorLabel = '<label id="gwasColorLabel' + phenoIndex + '" class="graphTxt">Color GWAS snp/s by trait:</label>';
    var gwasLabelText = '<div class="form-inline2"><input type="text" class="form-control2" placeholder="Ex: Ulcerative" id="gwasTermGenome' + phenoIndex + '" name="gwasTermGenome' + phenoIndex + '">';
    gwasLabelText += '<select class="form-control2" id="gwasColorSelectGenome' + phenoIndex + '"><option selected>red</option><option>purple</option><option>orange</option><option>lightblue</option><option>green</option><option>yellow</option><option>black</option></select><button type="submit" class="btn btn-smaller btn-info" onclick="gwasTermFilterGenome(\'' + phenoIndex + '\')">Submit</button> </div>';


    var html = '<table><tr><td></td><td>';
    //html+='<table><tr><td>&nbsp&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbsp&nbsp</td><td>';
    //html+=gwasDiv+'</td><td>&nbsp&nbsp</td><td>&nbsp&nbsp</td><td>'+gwasColorLabel+''+gwasLabelText+'</td></tr></table>';
    html += '</td></tr>';

    html += '<tr><td>&nbsp</td><td>';
    html += '<table><tr><tr><td>' + genomeLabel + '</td><td><td>&nbsp&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbsp&nbsp</td><td>';
    html += gwasDiv + '</td><td>&nbsp&nbsp</td><td>&nbsp&nbsp</td><td>' + gwasColorLabel + '' + gwasLabelText + '</td></tr></table>';
    html += '</td></tr><tr><td>' + unitDiv + '</td><td><div  class=\"genomePlot\" " id="genomePlot' + phenoIndex + '"></div></td></tr><tr><td></td><td>' + label + '</td></tr></table><hr>';
    return html;
}

//Buttons and labels displayed on plots

function addZoomOutBtn(plotDiv, plot, chr) {
    $('<div class="button" style="right:24px;top:9px">zoom out</div>').appendTo($("#" + plotDiv)).click(function(e) {
        e.preventDefault();
        var axes = plot.getAxes();
        var min = parseFloat(axes.xaxis.min);
        var max = parseFloat(axes.xaxis.max);
        var zoomAmount = (max - min) * 0.75;
        var from = min - zoomAmount;
        var to = max + zoomAmount;
        zoomToRange({
            xaxis: {
                from: from,
                to: to
            },
            yaxis: {}
        });
    });
    addArrow('left', 58, 29, plotDiv, plot);
    addArrow('right', 28, 29, plotDiv, plot);
}

function addArrow(dir, right, top, plotDiv, plot) {
    var axes = plot.getAxes();
    var xaxis = axes.xaxis;
    var yaxis = axes.yaxis;
    var ranges;
    $('<img class="button" src="images/arrow-' + dir + '.gif" style="right:' + right + 'px;top:' + top + 'px">').appendTo($("#" + plotDiv)).click(function(e) {
        e.preventDefault();
        var min = parseInt(xaxis.datamin);
        var max = parseInt(xaxis.datamax);
        var panRange = parseInt((max - min) * 0.15);
        var x_from;
        var x_to;
        if (dir == 'left') {
            x_from = min - panRange;
            x_to = max - panRange;
        } else {
            x_from = min + panRange;
            x_to = max + panRange;
        }
        ranges = {
            xaxis: {
                from: x_from,
                to: x_to
            },
            yaxis: {
                from: parseInt(yaxis.datamin),
                to: parseInt(yaxis.datamax)
            }
        };
        zoomToRange(ranges, plot);
        //  plot.pan(offset);
    });
}

function addTraitLoci(plot, ranges) {
    var o = plot.flotplot.getPlotOffset();
    var axes = plot.flotplot.getAxes();
    var xc = axes.xaxis.p2c;
    var series = plot.seriesArray[0];
    if (series.trait_loci) {
        var trait_loci = series.trait_loci;
        var divName = $("#" + plot.placeHolder);
        for (var i = 0; i < trait_loci.length; i++) {
            if (trait_loci[i]) {
                var score = trait_loci[i][2];
                var x1 = trait_loci[i][0];
                var x2 = trait_loci[i][1];
                var xStart = xc(x1) + o.left;
                var xEnd = xc(x2) + o.left;
                if (ranges) {
                    var from = ranges.xaxis.from;
                    var to = ranges.xaxis.to;
                    var show = 0;
                    if (from <= x1) {
                        if (to >= x2) //trait loci is within the range
                            show = 1;
                        else {
                            if (to >= x1) {
                                xEnd = xc(to) + o.left;
                                show = 1;
                            }
                        }
                    } else if ((from >= x1) && (from <= x2)) {
                        show = 1;
                        if (x2 >= to)
                            xEnd = xc(to) + o.left;
                        if (x1 <= from)
                            xStart = xStart = xc(from) + o.left;
                    }
                    var range = xEnd - xStart;
                    if (show)
                        divName.append('<div class="button" style="position:absolute; background: #FF9900; left:' + xStart + 'px; top:20px; height: 9px; width: ' + range + 'px; color: rgb(0,0,0); font-size: 9px;">' + score + '</div>');
                } else {
                    var range = xEnd - xStart;
                    divName.append('<div class="button" style="position:absolute; background: #FF9900; left:' + xStart + 'px; top:20px; height: 9px; width: ' + range + 'px; color: rgb(0,0,0); font-size: 9px;">' + score + '</div>');
                }
            }
        }
    }
}

function addEvalueDivs(plot) {
    var dataWithThr;
    //check if any of the datasets have threeshold information
    var plotDiv = $("#" + plot.placeHolder);
    var series;
    for (var i = 0; i < plot.seriesArray.length; i++) {
        series = plot.seriesArray[i];
        if (series.thresh)
            i = plot.seriesArray.length; //leave the for-loop since we only need one
    }
    if (series) {
        if ((series.thresh) && (series.evalue))
            addDiv(plotDiv, plot, series.thresh, series.evalue);
        //    if((series.thresh2)&&(series.evalue2))
        //    addDiv(plotDiv, plot, series.thresh2, series.evalue2);
        // if((series.thresh3)&&(series.evalue3))
        //  addDiv(plotDiv, plot, series.thresh3, series.evalue3);
    }
}

function addDiv(plotDiv, plot, thr, eval) {
    var yc = (plot.flotplot).getAxes().yaxis.p2c;
    var o = (plot.flotplot).getPlotOffset();
    var y = yc(thr) + o.top;
    plotDiv.append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + y + 'px;color:#D00000;font-size:10px">' + eval + '</div>');
}

function showTooltip(x, y, contents) {
    $('<div id="tooltip">' + contents + '</div>').css({
        position: 'absolute',
        display: 'none',
        top: y + 5,
        left: x + 5,
        border: '1px solid #fdd',
        padding: '6px',
        'background-color': '#fee',
        opacity: 0.90
    }).appendTo("body").show();
}

function showImpactType(id, show) {
    var redraw = false;
    $.each(plots, function(i, plot) {
        $.each(plot.seriesArray, function(j, series) {
            if (series.impact === id) {
                if (series.points.show !== show)
                    redraw = true;
                series.points.show = show;
            }
        });
        //if there was a change, draw:
        if (redraw) {
            plot.flotplot.setData(plot.seriesArray)
            plot.flotplot.draw();
        }
    });
}

function hideByImpact(id) {
    if (document.getElementById(id).checked)
        showImpactType(id, false);
    else
        showImpactType(id, true);
}

function hideSeries(labelDiv) {
    var pi = labelDiv.substr(labelDiv.length - 1);
    var plot;
    if (labelDiv === "#marker_labels") {
        $.each(markerPlot.seriesArray, function(i, series) {
            series.points.show = true;
        });
        $(labelDiv + ' input[type=checkbox]').each(function() {
            if ($(this).prop('checked')) {
                var labelCh = $(this).attr('value');
                $.each(markerPlot.seriesArray, function(i, series) {
                    if (labelCh === series.label) {
                        series.points.show = false;
                    }
                });
            }
        });
        markerPlot.flotplot.setData(markerPlot.seriesArray)
        markerPlot.flotplot.draw();
    } else {
        if ($('#genomePlots').is(':visible')) {
            plot = genomePlots[pi];
        } else {
            plot = plots[pi];
        }
        $.each(plot.seriesArray, function(i, series) {
            series.points.show = true;
	    if (!(series.gwasCatalog)) {
                hideShowChildren(plot, series.typeIndex, true);

            } else {
                series.points.show = true;
            }
        });
        $(labelDiv + ' input[type=checkbox]').each(function() {
            if ($(this).prop('checked')) {
                var labelCh = $(this).attr('value');
                $.each(plot.seriesArray, function(i, series) {
                    if (labelCh === series.label) {
                        if (!(series.gwasCatalog)) {
                            hideShowChildren(plot, series.typeIndex, false);
                        } else {
                            series.points.show = false;
                        }
                    }
                });
            }
        });
        plot.flotplot.setData(plot.seriesArray)
        plot.flotplot.draw();
    }
}

function hideShowChildren(plot, pI, show) {
    console.log("IM ni hideShowChildren");
    $.each(plot.seriesArray, function(i, series) {
        if (series.typeIndex === pI) {
	    //console.log(series.impact);
            if (document.getElementById(series.impact).checked) {
                series.points.show = false;
            } else {
                series.points.show = show;
            }
        }
    });
}
