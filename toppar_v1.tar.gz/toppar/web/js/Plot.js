
function Plot(proj_index, phenoType, condensed,chr, from, to){
  this.phenoIndex=proj_index;
  this.phenoType=phenoType;
  this.seriesArray=[];
  this.chr=chr;
  this.from=from;
  this.to=to;
  this.condensed=condensed;
  this.ranges;
  this.placeHolder;
  this.overviewPlaceHolder;
  this.flotplot;
  this.overviewPlot;
  this.labelsDiv;
  this.noData=[];//an array to store the scan_types that have no data
  this.maxScore=0;
}

Plot.prototype.resetMaxScore=function(score){
  var maxScore = 0;
/*get max score for all series, move this into Plot?*/
$.each(seriesArray, function(j, series) {
    if (maxScore < parseFloat(series.maxScore)) {
        maxScore = series.maxScore;
    }
});
 this.maxScore=maxScore;
}

Plot.prototype.getSeriesByTypeIndex=function(ti){
    var extendedData=[];
    //ignore selected and ld series
    $.each(this.seriesArray, function(i, series){
        if(series.typeIndex === ti){
          if((!series.selected)&&(!series.gwasCatalog)&&(!series.ldSeries)){
          if(typeof(series.data) !== "undefined"){
          //  if(series.data.length > 1){
                    extendedData.push.apply(extendedData, series.data);
        //  }
        }
      }
      }
    });
    return extendedData;
}

Plot.prototype.setRanges=function(ranges){
  this.ranges=ranges;
}
Plot.prototype.getSeries=function(){
    return this.seriesArray;
}

Plot.prototype.changeSeriesArrayRadius=function(radius){
  $.each(this.seriesArray, function(i, series){
        series.points.radius=radius;
   });
}

Plot.prototype.addSeries=function(series){
    this.seriesArray.push(series);
    if(typeof(series.maxScore) !== "undefined"){
	if(parseFloat(series.maxScore) > parseFloat(this.maxScore)){
	    this.maxScore=series.maxScore;
	}
    }
}

Plot.prototype.add_seriesArray=function(sa){
       for(var i=0; i< sa.length;i++){
	         this.addSeries(sa[i]);
    }
}

Plot.prototype.rmGwasSeries=function(){
    var seriesArrayTmp=[];
    var seriesArrayTmp=Array.from(this.seriesArray);
    var maxScore=0;
    $.each (this.seriesArray, function(i, series){
	     if(typeof(series) != "undefined"){
	        if(series.gwasCatalog){
		          var noGwasElements=(seriesArrayTmp.length)-i;
  		          seriesArrayTmp.splice(i, noGwasElements);
	    }
      else if (series.leadSeries){ //reset the maxScore with the maxScore of a series which is not GWAS catalog
          if(parseFloat(series.maxScore) > parseFloat(maxScore))
               maxScore=series.maxScore;
      }
	}
	});
  this.seriesArray=Array.from(seriesArrayTmp);
  this.maxScore=maxScore;
  //  callback(this);
}


Plot.prototype.rmLDSeries=function(callback){
    var seriesArrayTmp=[];
    var seriesArrayTmp=Array.from(this.seriesArray);
    $.each (this.seriesArray, function(i, series){
   	if(typeof(series) != "undefined"){
	     if(series.ldSeries){
		 var noGwasElements=(seriesArrayTmp.length)-i;
		 seriesArrayTmp.splice(i, noGwasElements);
	    }
	}
	});
    this.seriesArray=Array.from(seriesArrayTmp);
    callback(this);
}

Plot.prototype.rmSelectedSeries=function(){
    var seriesArrayTmp=[];
    var seriesArrayTmp=Array.from(this.seriesArray);
    $.each (this.seriesArray, function(i, series){
	if(typeof(series) != "undefined"){
	    if(series.selected){
		//var noGwasElements=(seriesArrayTmp.length)-i;
		seriesArrayTmp.splice(i, 1);
	    }
	}
	});
    this.seriesArray=Array.from(seriesArrayTmp);
}

Plot.prototype.rmSeries=function(){
    this.seriesArray.pop();
}
Plot.prototype.addNoData=function(phenotype){
  this.noData.push(phenotype);
}
