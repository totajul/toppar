var all_labels;
var all_labels_info;
var label2pheno={};

$(document).ready(function(){
  if (navigator.appName =="Microsoft Internet Explorer"){
      alert("Toppar does NOT work in Interet Explorer!! Please use  Chrome, Firefox or Safari instead!");
  }
  else{
      $('#noData').hide();
      $('#noDataHolder').hide();
      $("#radio_region").prop('checked' , false);
      $("#radio_genome").prop('checked' , false);
      emptyTxtBoxes();
      initGenomeBuildMenu();
      all_labels=getAllLabelsInDB(); //for autocomplete 
  }
});
