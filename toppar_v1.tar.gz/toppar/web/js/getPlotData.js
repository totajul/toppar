
function getData(){
    if($("#radio_region").is(":checked")){
	      getRegion();   //check whether gene,chr or coord are checked	orig_name=$("#gene_symbol").val();
    }
    else{
	    //select genome if nothing has been selected
	    $("#radio_genome").is(":checked" , true);
	    getGenome();
    }
}

function getPlotData(condensed, chr, from, to) {
    var build = $("#build").val();
    var pop = $("#population").val();
    var phenotype = $("select#phenotype option:selected").map(function() {
        return $(this).text();
    }).get();
    var labels = $("select#label option:selected").map(function() {
        return $(this).text();
    }).get();
    if (labels == "") {
        $("#label").prop("selectedIndex", 0);
        labels[0] = $("#label option:selected").text();
    }
    if (phenotype == "") {
        $("#phenotype").prop("selectedIndex", 0);
        phenotype[0] = $("#phenotype option:selected").text();
    }
    $("#noDataFor").hide();
    $("#noData").empty();

    if (condensed){genomePlots = [];}
    else{plots = [];}

    var mk_plotObj = true;
    var pheno_count = 0; var label_count=0;
    var plot_copy; var onePlot=false;
    var plot;
    if(document.getElementById("onePlot").checked){
    //display all the data on one plot;
       onePlot=true;
    }

    //create phenotype label map in init - only get data if label is in phenotype
    var matchingPhenos = getMatchingPhenos(labels);
    $.each(phenotype, function(phenoIndex, pheno) {
        var mk_plotObj=true;
        var plot;
        if(onePlot && phenoIndex>0){
            mk_plotObj=false;
            plot=plot_copy;
        }
        if (arrayContains(matchingPhenos, pheno)) {
            if (mk_plotObj) {
                plot = get_plotObj(condensed, pheno_count, pheno, chr);
                plot.maxScore = 0;
                mk_plotObj = false; //only make one plotobject per project
                pheno_count++;
                plot_copy = Object.create(plot); //copy the plot in case user has selected "show all in one plot"
            }
            //var plot = new Plot(phenoIndex, chr, condensed, from, to, pheno);
            var counter = 0;

            $.each(labels, function(typeIndex, label) {

                if (labelMatchesPheno(label, pheno)) {
                    try {
                        var script = getData_cgi + "?build=" + build + "&pop=" + pop + "&chr=" + chr + "&pheno=" + pheno + "&label=" + label + "&condensed=" + condensed;
                        $.ajax({
                            type: "GET",
                            url: script,
                            success: function(jsonfile) {
                                if (jsonfile.substring(2, 0).toLowerCase() == "no") { // No data for scantype or no data for chromosome?
                                    // plot.addNoData(label); label_count++;
                                    //if (label_count == (labels.length))
                                    //    if (condensed) {plotData(genomePlots, condensed);}
                                    //    else {plotData(plots, condensed, from, to);}
                                } else {
                                    try {
                                        $.getJSON(jsonfile, function(json) {
                                            if (condensed) {

                                              var series=new Series(label_count, "circle", 1, "other", json.label);

                                              series.data=json.data;//
                                              //series.setLabel(json.label);
                                              series.mkLeadSeries(json.maxScore, "");
                                              if(parseFloat(json.maxScore) > parseFloat(plot.maxScore)){
                                                  plot.maxScore=parseFloat(json.maxScore);
                                              }
                                                 plot.addSeries(series);

                                            } else {
                                             
						plot.add_seriesArray(create_series_by_impact(json, label_count,condensed, false));
						if(parseFloat(json.maxScore) > parseFloat(plot.maxScore)){
						    plot.maxScore=parseFloat(json.maxScore);
						}
					    }
                                            label_count++; //same as pheno_count in vD
                                            counter++;
                                            if (label_count == (labels.length)) {
                                                if (condensed)
                                                    plotData(genomePlots, condensed);
                                                else{
						    $.each(plots, function(i, pl){
							    if(parseFloat(pl.maxScore) < parseFloat(plot.maxScore)){
								pl.maxScore=plot.maxScore;
							    }
							});
						    plotData(plots, condensed, chr, from, to);
                                                    //getMarkers(build, pop, chr, database,plots);
                                                }
                                            }
                                        });
                                    } catch (err) {
                                        alert("error " + err);
                                    }
                                }
                            }
                        });
                    } catch (err) {
                        ("ERROR " + err);
                    }
                }
            }); //each scantype
        }
    }); //each phenotype
    //getMarkers(build, pop, chr, database);
}


function plotData(p, condensed,chr, from, to){
  var thereIsData=false;
  $.each(p, function(i, plot){
      if(plot.seriesArray.length > 0){
         thereIsData=true;
	       if(condensed){
		         $("#genomePlots").append(setGenomePlotDivs(plot));
              plotGenome(plot);
	      }
	      else{
		          $("#regionPlots").append(setSinglePlotDivs(plot));
		          addStyles(plot.phenoIndex);
		          if($("#gwasCB").is(":checked")){
		               addGWASseries(plot, condensed);
		           }
		           plotSinglePlot(plot);
	      }
	    }
});
if(!condensed && thereIsData){
	   addGenesPlot(plots[0], from, to);
     if( $('#showTADs').prop('checked') )
           addTADs(plots[0], from,to);
     bindSinglePlots(plots);
  }
  //else
    //  mk_results_genome_DataTable(); only in Dv
      //addGenesGenomePlot(p[0]);

}


function getMatchingPhenos(labels) {
    var phenos = [];
    $.each(labels, function(i, label) {
        phenos.add(label2pheno[label]);
    });
    return phenos;
}

function labelMatchesPheno(label, pheno) {
    var itemFound = false;
    if (label2pheno[label] === pheno) {
        itemFound = true;
    }
    return itemFound;
}

function condense(seriesArray, limit) {
    $.each(seriesArray, function(i, series) {
        if (series.origData.length > limit)
            series.data = condenseData2(series.origData);
        else
            series.data = series.origData;
    });
}

function create_series_by_impact(json, type_index,condensed, ld_series){
    var series_by_impact=[];
    var radius="1";
    var serLow=new Series(type_index, "circle", radius, "low", json.label);
    var serOther=new Series(type_index, "square",radius, "other", json.label);
    var serHigh=new Series(type_index, "diamond",radius, "high", json.label);
    var serMod=new Series(type_index,"triangle",radius, "moderate", json.label); //cross;
    var impact_pos=4;
    if(condensed)
         impact_pos=4;
    $.each(json.data, function(k, dp){

      if(dp[impact_pos] !== null){
	      if(dp[impact_pos] === "MODIFIER")
		       serLow.data.push(dp);
	      else if(dp[impact_pos] === "MODERATE")
	           serMod.data.push(dp);
	      else if(dp[impact_pos] === "HIGH")
	             serHigh.data.push(dp);
	      else if(dp[impact_pos] === "LOW"){
	        serOther.data.push(dp);
        }
        else{
            serOther.data.push(dp);
        }
	  }
	 else
	    serOther.data.push(dp);
    });
    serLow.origData=serLow.data; serHigh.origData=serHigh.data; serMod.origData=serMod.data;serOther.origData=serOther.data;
    if(ld_series){
     if(serLow.data.length > 0){
          serLow.ldSeries=true; serMod.ldSeries=true; serHigh.ldSeries=true; serLow.ldSeries=true;
	        serLow.mkLDSeries(json.r2, ": ("+json.data.length+")"); // " :  "+serLow.data.length+"/"+serMod.data.length+"/"+serHigh.data.length+"/"+serOther.data.length+")");
          serMod.color=serLow.color; serHigh.color=serLow.color; serOther.color=serLow.color;
        }
        else{
          serOther.ldSeries=true; serMod.ldSeries=true; serHigh.ldSeries=true; serLow.ldSeries=true;
          serOther.mkLDSeries(json.r2, ": ("+json.data.length+")"); // " :  "+serLow.data.length+"/"+serMod.data.length+"/"+serHigh.data.length+"/"+serOther.data.length+")");
          serMod.color=serLow.color; serHigh.color=serLow.color; serOther.color=serLow.color;
        }
    }
    else{
      if(serLow.data.length > 0)
    	   serLow.mkLeadSeries(json.maxScore, " ("+json.data.length+" :  "+serLow.data.length+"/"+serMod.data.length+"/"+serHigh.data.length+"/"+serOther.data.length+")");
      else if (serOther.data.length > 0)
          serOther.mkLeadSeries(json.maxScore, " ("+json.data.length+" :  "+serLow.data.length+"/"+serMod.data.length+"/"+serHigh.data.length+"/"+serOther.data.length+")");
      else if (serMod.data.length > 0)
            serMod.mkLeadSeries(json.maxScore, " ("+json.data.length+" :  "+serLow.data.length+"/"+serMod.data.length+"/"+serHigh.data.length+"/"+serOther.data.length+")");
      else {
        serHigh.mkLeadSeries(json.maxScore, " ("+json.data.length+" :  "+serLow.data.length+"/"+serMod.data.length+"/"+serHigh.data.length+"/"+serOther.data.length+")");

      }
    }
    //if(ld_series) /// make them LD series with the appropriate colors and labels
    series_by_impact.push(serLow, serMod, serHigh, serOther);
    return series_by_impact;
}
