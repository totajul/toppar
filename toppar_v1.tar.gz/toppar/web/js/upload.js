var pop_data;

$(document).ready(
    function() {
        var browserName = navigator.appName;
        if (browserName == "Microsoft Internet Explorer")
            alert("The Genome Scan Viewer does NOT work in Interet Explorer!! Please use  Chrome, Firefox or Safari instead!");
        else {
          set_builds();
              //initGenomeBuildMenu();
        }
    });

    $(document).ajaxStart(function() {
        $("#ajaxBusy").show();
    }).ajaxStop(function() {
        $("#ajaxBusy").hide();
    });
//INITIATE MENUS and Menu functions
$(function() {
    $("select#build").change(function() {
        initPopulationMenu();
    });
});
$(function() {
    $("select#population").change(function() {
        initFilterMenus();
        //populateMenusOnChange();
    });
});

function initFilterMenus() {
    //get selected population
    var pop = $("#population").val();
    var filter_th_ids = ["f1_label", "f2_label", "f3_label"];
    for (var i = 0; i < pop_data.length; i++) {
        var d = pop_data[i];
        if (d.name === pop) {
            for (var j = 0; j < d.filters.length; j++) {
                var filter = d.filters[j];
                $("#" + filter_th_ids[j]).empty();
                $("#" + filter_th_ids[j]).html(filter+":");
            }
            i = pop_data.length;
        }
    }
}

//populates the genome build menu on start up
function initGenomeBuildMenu() {
    var options = '';
    try {
        var script = getGenomeBuild_cgi;
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonFile) {
                try {
                    $.getJSON(jsonFile, function(data) {
                        var options = '';
                        for (var i = 0; i < data.length; i++) {
                            var selected = "";
                            if (i === 0) {
                                selected = ' selected="selected"';
                                options += '<option value="' + data[i].name + '"' + selected + '>' + data[i].name + '</option>';
                                build = data[i].name;
                            } else {
                                options += '<option value="' + data[i].name + '">' + data[i].name + '</option>';
                            }
                        }
                        $("select#build").html(options);
                        initPopulationMenu();
                    });
                } catch (e) {
                    alert("error when reading jsonFile " + e);
                }
            }
        });
    } catch (e) {
        alert("error when running getGenomeBuild.cgi " + e);
    }
}

function set_builds(){
  var options='<option value="GRCh38" selected>GRCh38</option><option value="GRCh37">GRCh37</option><option value="NCBI36">NCBI36</option>';
  $("select#build").html(options);
  initPopulationMenu();
}


function initPopulationMenu() {
    if ($("#build").val()) {
        build = $("#build").val();
    }
    try {
        var script = getPopulation_cgi + '?build=' + build;
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonFile) {
                try {
                    $.getJSON(jsonFile, function(data) {
                        var options = '';
                        for (var i = 0; i < data.length; i++) {
                            options += '<option>' + data[i].name + '</option>';
                        }
                        $("select#population").html(options);
                        pop_data=data;
                        initFilterMenus();
                        //populateMenusOnChange();
                    });
                } catch (e) {
                    alert("error when reading jsonFile " + e);
                }
            }
        });
    } catch (e) {
        alert("error when running "+script+" "+ e);
    }
}

function showhide(id) {
    var obj;
    if (document.getElementById) {
        obj = document.getElementById(id);
        if (obj.style.display == "none")
            obj.style.display = "";
        else
            obj.style.display = "none";
    }
  $("#upload_msg").empty();
}



function upload_pop(){
//  e.preventDefault();
  $("#upload_msg").empty();
  $("#upload_pop").prop("disabled", true);
  var pop=document.getElementById("pop_name_upload").value;
  var f1=document.getElementById("f1_upload").value;
  var f2=document.getElementById("f2_upload").value;
  var f3=document.getElementById("f3_upload").value;
  var user=document.getElementById("user2").value;
  var pwd=document.getElementById("password2").value;
  var build=document.getElementById("build").value;
  var script=insert_pop+"?pop="+pop+"&f1="+f1+"&f2="+f2+"&f3="+f3+"&pwd="+pwd+"&user="+user+"&build="+build;
  $("#upload_msg").html("Uploading...<br>");
  console.log(script);
  if((!isEmpty(pop)) && (!isEmpty(f1)) && (!isEmpty(f2)) && (!isEmpty(f3))){
      if(!isEmpty(user)  && !isEmpty(pwd)){
        try{
            $.ajax({
                type: "GET",
                dataType: "json",
                url: script,
                success: function(data){
                    $("#upload_msg").append(data.msg);
                    if(data.success){
                      initPopulationMenu();
                    }
                    else{
                      alert("Something went wrong when trying to upload population to the database! "+data.msg);
                    }
                    $("#upload_pop").prop("disabled", false);
                    }
            });
        }
        catch(e){
          alert("Error when calling ajax "+e)
        }
      }
      else{
        alert("User name and Password to the toppar_db database is required!")
      }
}
  else{
    alert("One or more fields are missing! Make sure the Population field and the 3 Filter fields are filled out.")
  }
}


function isEmpty(str){
  return(!str || 0 === str.length);
}

//$('#assoc_form').on('submit', function (event, force) {
$('#assoc_upload_btn').click(function (e) {
  e.preventDefault();
  //  if (!force) {
    setTimeout(function () {
            upload_data();

      }, 2000);
      return false;
});



function upload_data(){
  $("#upload_assoc_msg").show();
  $("#ajaxBusy2").show();
  $("#upload_assoc_msg").empty();
  $("#upload_assoc_btn").prop("disabled", true);
  var build = $("#build").val();
  var population=$("#population").val();
  var phenotype=$("#phenotype").val();
  var f1=$("#f1").val();
  var f2=$("#f2").val();
  var f3=$("#f3").val();
  var description=$("#description_fields").val();
  var user=document.getElementById("user3").value;
  var pwd=document.getElementById("password3").value;

  var file_data=document.getElementById("assoc_file").files[0];
  var form_data=new FormData();
  form_data.append("assoc_file", file_data);
  form_data.append("user", document.getElementById("user3").value)
  form_data.append("password", document.getElementById("password3").value)
  form_data.append("build", document.getElementById("build").value);
  form_data.append("population", document.getElementById("population").value);
  form_data.append("phenotype", document.getElementById("phenotype").value);
  form_data.append("f1", document.getElementById("f1").value);
  form_data.append("f2", document.getElementById("f2").value);
  form_data.append("f3", document.getElementById("f3").value);
  form_data.append("description", document.getElementById("description_fields").value);

if((!isEmpty(build)) && (!isEmpty(population)) && (!isEmpty(phenotype)) && (!isEmpty(f1)) && (!isEmpty(f2)) && (!isEmpty(f3))){
    if( (!isEmpty(user))  && (!isEmpty(pwd)) ){
      $("#upload_assoc_msg").append("Starting data upload. Build and population: "+build+", "+population+". Phenotype and filters:  "+phenotype+", "+f1+", "+f2+", "+f3);
try{
      $.ajax({
                  url: upload_file_cgi,
                  type: 'POST',
                  data: form_data,
                 dataType: 'json',
                processData: false, // Don't process the files
                 contentType: false, // Set content type to false as jQuery will tell the server its a query string request
                  success: function(data, textStatus, jqXHR)  {
                        $("#upload_assoc_msg").append("&#13;&#10;"+data.msg);
                        $("#upload_assoc_msg").append("&#13;&#10;Making markers file...&#13;&#10;");
                        if(data.success){
                          mk_markers_file(data.file);
                      }
                  },
                  error: function(e)
                  {
                    // Handle errors here
                    console.log('ERRORS: ');
                    console.log(e);


                    // STOP LOADING SPINNER
                    //  $("#ajaxBusy2").hide();
                  }
                });
        }
        catch(e){
          alert("error when running "+upload_file_cgi +" "+e);
        }
   }
      else{
        alert("User name and Password to the toppar_db database is required!")
      }
    }
  else{
      alert("One or more fields are missing! Make sure the phenotype and the 3 Filter fields are filled out.")
  }
}

function mk_markers_file(assoc_file) {
    if ($("#build").val()) {
        build = $("#build").val();
    }
    try {
        var script = mk_markers_file_cgi + '?build=' + build+ '&file='+assoc_file;
        console.log(script);
        $.ajax({
            type: "GET",
            url: script,
            dataType: 'json',
            success: function(data) {
                  $("#upload_assoc_msg").append("&#13;&#10;Markers file was generated!&#13;&#10;");
                  $("#upload_assoc_msg").append("&#13;&#10;Uploading the markers file...&#13;&#10;");
                  document.getElementById("upload_assoc_msg").scrollTop = document.getElementById("upload_assoc_msg").scrollHeight
                  upload_markers(data.file, assoc_file);
            }
        });
    } catch (e) {
        alert("error when running populateMenus.cgi " + e);
    }
}

function upload_markers(file, assoc_file) {
    if ($("#build").val()) {
        build = $("#build").val();
    }
    try {
        var population=$("#population").val();
        var script = upload_markers_cgi + '?build=' + build+ '&file='+file+'&population='+population;
        $.ajax({
            type: "GET",
            url: script,
            dataType: 'json',
            success: function(data) {
                  $("#upload_assoc_msg").append("&#13;&#10;Upload of marker file complete!&#13;&#10;");
                  $("#upload_assoc_msg").append(data.msg);
                  $("#upload_assoc_msg").append("&#13;&#10;Uploading association data...&#13;&#10;");
                  document.getElementById("upload_assoc_msg").scrollTop = document.getElementById("upload_assoc_msg").scrollHeight
                  console.log(data);
                  console.log(data.success);
                  if(data.success){
                       upload_assoc_data(assoc_file);
                }
            }
        });
    } catch (e) {
        alert("error when running populateMenus.cgi " + e);
    }
}

function upload_assoc_data(assoc_file) {
    if ($("#build").val()) {
        build = $("#build").val();
    }
    var pop=document.getElementById("population").value;
    var pheno=document.getElementById("phenotype").value;
    var desc=document.getElementById("description_fields").value;
    //var user=document.getElementById("user3").value;
    //var pwd=document.getElementById("password3").value;
    var script = upload_assoc_data_cgi + '?build=' + build+ '&file='+assoc_file+'&pop='+pop+'&pheno='+pheno+'&desc='+desc;
  //+'&user='+user+'&password='+pwd;
    console.log(script);
    //  if( (!isEmpty(user))  && (!isEmpty(pwd)) ){
   try {
        $.ajax({
            type: "GET",
            url: script,
            dataType: 'json',
            success: function(data) {
              $("#upload_assoc_msg").append(data.msg);
              $("#upload_assoc_msg").append(data.success);
              document.getElementById("upload_assoc_msg").scrollTop = document.getElementById("upload_assoc_msg").scrollHeight;
              $("#ajaxBusy2").hide();
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert("Status: " + textStatus); alert("Error: " + errorThrown);
              }

        });

    } catch (e) {
        alert("error when running upload_assoc_data " + e);
    }
//  }
//  else{
//            alert("User name and Password to the toppar_db database is required!")
//  }

}
