var ld_on_display = 0;

function get_LD(phenoIndex) {
  var plot = plots[phenoIndex];

if (currently_sel_dp === "") {
    alert("No datapoint is selected!! Please select a datapoint on the plot and try again.");
    $('#ldBtn' + phenoIndex).prop("checked", false);
  }
  else if (sel_item_coord.gwas_cat){
    alert("Ld calculations can currently not be applied to GWAS catalog SNPs");
  }
  else {
    if (!(ld_on_display)) {
      //get the series for the selected plot
      var ld_series_array = [];
      ld_on_display = 1;
      $.each(plot.seriesArray, function(i, series) {
        if (series.phenotype === pheno_of_curr_sel_db) {
          if (typeof(series.data[1]) !== "undefined") {
            ld_series_array.push(series);
          }
        }
      });
      //make a deep copy of the ld_series_array
      //var ld_array_copy = $.extend(true, {}, ld_series_array);
      //plot = addLDSeries(plot, ld_array_copy, model, phenoIndex);
      plot = get_LD_calc(plot, ld_series_array, redrawPlot) /// redrawPlot);
      //getPointsWithinInterval(ld_series_array, plot);
      //add_recomb_rates(plot, redrawPlot);
    }
  }

}

function rm_LD(pi) {
  plots[pi].rmLDSeries(redrawPlot);
  $("#rmLDBtn" + pi).hide();
  ld_on_display = 0;
}


function get_LD_calc(plot, ld_series_array, redrawPlot) { //}, model, add_recomb_rates) {
  var x_from = plot.flotplot.getAxes().xaxis.min.toFixed(0);
  var x_to = plot.flotplot.getAxes().xaxis.max.toFixed(0);
  var lead_snp_pos = sel_item_coord.x;
  var script = get_LD_cgi + "?chr=" + chr + "&from=" + x_from + "&to=" + x_to + "&lead_snp_pos=" + lead_snp_pos;

  try {
    $.ajax({
      type: "GET",
      url: script,
      dataType: 'json',
      success: function(output) {
        if(output.success){
        try {
          $.getJSON(output.jsonfile, function(d) {
            $("#rmLDBtn" + plot.phenoIndex).show();
            //5 data arrays, each with the different r2
            var r2_lowest = [];
            var r2_lower = []; // r2: 0.2-0.4
            var r2_medium = []; // r2: 0.4-0.6
            var r2_higher = []; // r2: 0.6-0.8
            var r2_highest = []; //r2: 0.8-1.0
            $.each(ld_series_array, function(i, series) {
            //  if (series instanceof Series) {
                $.each(series.data, function(k, data) {
                  if ((x_from <= data[0]) && (data[0] <= x_to)) {
                    var inhouse_marker_id = data[3];
                    //  if (inhouse_marker_id !== sel_inhouse_id) {
                    if (parseInt(sel_item_coord.x) !== parseInt(data[0])) { // dont want to include the selected snp

                      $.each(d, function(j, dp) {
                        if (parseInt(dp[0]) === parseInt(data[0])) {
                          var r2 = dp[1];
                          data.r2 = r2;
                          if (r2 < 0.2) { //>0.2
                            r2_lowest.push(data);
                          } else if (r2 < 0.4) {
                            r2_lower.push(data);
                          } else if (r2 < 0.6) {
                            r2_medium.push(data);
                          } else if (r2 < 0.8)
                            r2_higher.push(data);
                          else if (r2 <= 1.0) {
                            r2_highest.push(data);
                          } else
                            alert("something is wrong with this r2 value " + r2 + " for marker " + inhouse_marker_id);
                        }
                      });
                    }
                  }

                });
              //}
            }); //EACH
            var last_series = plot.seriesArray[plot.seriesArray.length - 1]; //get the last pheno count
            var json = {
              "data": r2_lowest,
              "phenotype": pheno_of_curr_sel_db,
              "r2": 0.2
            };

            var sa = create_series_by_impact(json, last_series.typeIndex, false, true);

            plot.add_seriesArray(sa);
            json = {
              "data": r2_lower,
              "phenotype": pheno_of_curr_sel_db,
              "r2": 0.4
            };
            plot.add_seriesArray(create_series_by_impact(json, last_series.typeIndex, false, true));
            json = {
              "data": r2_medium,
              "phenotype": pheno_of_curr_sel_db,
              "r2": 0.6
            };
            plot.add_seriesArray(create_series_by_impact(json, last_series.typeIndex, false, true));
            json = {
              "data": r2_higher,
              "phenotype": pheno_of_curr_sel_db,
              "r2": 0.8
            };

            plot.add_seriesArray(create_series_by_impact(json, last_series.typeIndex, false, true));
            json = {
              "data": r2_highest,
              "phenotype": pheno_of_curr_sel_db,
              "r2": 1.0
            };
            plot.add_seriesArray(create_series_by_impact(json, last_series.typeIndex, false, true));
            redrawPlot(plot);
            //add_recomb_rates(plot, redrawPlot)

          }); //GETjson
        } //TRY
        catch (err) {
          alert("Error in getJSON when getting LD data " + err);
        }
      }
      else{
        alert(output.msg);
      }
    }

    });
  } catch (err) {
    alert("Ajax error when trying to get LD data: " + err);
  }
  return plot;

}

function addLDSeries(plot, ld_series_array, model, phenoIndex) {
  var x_from = plot.flotplot.getAxes().xaxis.min.toFixed(0);
  var x_to = plot.flotplot.getAxes().xaxis.max.toFixed(0);
  var script = mk_marker_spec_file_cgi + "?main_marker=" + sel_inhouse_id + "&phenotype=" + pheno_of_curr_sel_db + "&x_from=" + x_from + "&x_to=" + x_to + "&model=" + model + "&chr=" + chr
  try {
    $.ajax({
      type: "GET",
      url: script,
      success: function(jsonfile) {
        plot = get_LD_calc(jsonfile, plot, ld_series_array, model, add_recomb_rates) /// redrawPlot);
        $("#rmLDBtn" + phenoIndex).show();
      }
    });
  } catch (err) {
    alert("Ajax error when trying to get LD data: " + err);
  }

  return plot;
}

function getPointsWithinInterval(seriesArray, plot) {
  var count = 0;
  var x_from = plot.flotplot.getAxes().xaxis.min.toFixed(0);
  var x_to = plot.flotplot.getAxes().xaxis.max.toFixed(0);
  $.each(seriesArray, function(i, series) {
    $.each(series.data, function(j, dp) {
      if ((x_from <= dp[0]) && (dp[0] <= x_to)) {
        count++;
      }
    })
  });
}






function add_recomb_rates(plot, redrawPlot) {
  var x_from = plot.flotplot.getAxes().xaxis.min.toFixed(0);
  var x_to = plot.flotplot.getAxes().xaxis.max.toFixed(0);
  var y_min = plot.flotplot.getAxes().yaxis.min.toFixed(0);
  var script = get_recomb_rates + "?chr=" + plot.chr + "&x_from=" + x_from + "&x_to=" + x_to;
  try {
    $.ajax({
      type: "GET",
      url: script,
      success: function(jsonfile) {
        try {
          $.getJSON(jsonfile, function(d) {
            var d_perc = [];
            $.each(d, function(i, coords) {
              var y = parseFloat(plot.maxScore) - parseFloat(y_min);
              var y_perc = parseFloat(coords[1]) / parseFloat(100);
              var new_val = y_perc * y
              var new_vals = [parseInt(coords[0]), new_val + 2, "", ""];
              d_perc.push(new_vals);
            });
            var last_series = plot.seriesArray[plot.seriesArray.length - 1];
            var series = new Series(last_series.typeIndex + 1, "circle", 2, "other", "recomb", "A");
            series.points = {
              show: false
            }
            series.lines = {
              show: true,
              lineWidth: 0.2
            };
            series.data = d_perc;
            series.origData = d_perc;
            series.mkLeadSeries(plot.maxScore, "");
            series.phenotype = "recombinataion";
            series.label = "recombination";
            series.color = "red";
            plot.addSeries(series);
            redrawPlot(plot);

          });
        } catch (err) {
          alert("Error in getJSON when getting LD data " + err);
        }
      }
    });
  } catch (err) {
    alert("Error when calling script " + script + " Error message: " + err)
  }
  redrawPlot(plot);
}
