
use strict;

my $out=`RScript convertPval2log10.pl 0.00005`;

print "OUT $out \n";
