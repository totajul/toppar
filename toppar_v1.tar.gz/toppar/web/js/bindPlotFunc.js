var dbSNP_url = "http://www.ncbi.nlm.nih.gov/projects/SNP/snp_ref.cgi?rs=";
var variantDetails = {};
var currently_sel_dp = "";
var sel_inhouse_id = "";
var pheno_of_curr_sel_db = "";
var sel_item_coord = {};


function bindSinglePlots(plots) {
  $.each(plots, function(index, plot) {
    var plotDiv = $("#" + plot.placeHolder);
    var overviewDiv = $("#" + plot.overviewPlaceHolder);
    plotDiv.bind("plotselected", function(event, ranges) {
      zoomToRange(ranges, plot); //do the zooming
    });
    overviewDiv.bind("plotselected", function(event, ranges) {
      try {
        $.each(plots, function(index2, plot2) {
          plot2.flotplot.setSelection(ranges);
        });
      } catch (e) {
        alert("ERROR when binding plots " + e);
      }
    });
    bindPlotHover(plotDiv);
    bindPlotClick(plotDiv, plot);
    bindPlotZoom(plotDiv, plot.overviewPlot);
    bindPlotPan(plotDiv, plot.overviewPlot, plot.flotplot);
  });
}

function bindPlotZoom(divName, overview, plot) {
  divName.bind('plotzoom', function(event, plot) {
    var axes = plot.getAxes();
    $("#message").html("Zooming to : " + axes.xaxis.min.toFixed(0) + " &ndash;" + axes.xaxis.max.toFixed(0));
    overview.setSelection({
      xaxis: {
        from: axes.xaxis.min,
        to: axes.xaxis.max
      }
    });
  });
}

function bindPlotPan(divName, overview, plot) {
  // show pan messages to illustrate events
  divName.bind('plotpan', function(event, plot) {
    var axes = plot.getAxes();
    $("#message").html("Panning to x: " + axes.xaxis.min.toFixed(0) +
      " &ndash; " + axes.xaxis.max.toFixed(0));
    overview.setSelection({
      xaxis: {
        from: axes.xaxis.min,
        to: axes.xaxis.max
      }
    });
  });
}

function bindPlotHover(divName) {
  //tooltip text
  var previousPoint = null;
  divName.bind("plothover", function(event, pos, item) {
    $("#x").text(pos.x.toFixed(2));
    $("#y").text(pos.y.toFixed(2));

    if (item) {
      if (previousPoint != item.datapoint) {
        previousPoint = item.datapoint;
        var x = item.datapoint[0].toFixed(0);
        var y = item.datapoint[1].toFixed(2);
        var xyl = item.series.data[item.dataIndex];
        var probeId = xyl[2];
        $("#tooltip").remove();
        if (item.series.gwasCatalog) {
          var trait = xyl[3];
          var pval = xyl[4];
          var or_beta = xyl[5];
          var reported_gene = xyl[6];
          var strongest_snp_all = xyl[7];
          var pid = xyl[8];
          var pub_date = xyl[7];
          var journal = xyl[8];
          var first_author = xyl[9];
          var pub_date = xyl[10];
          var journal = xyl[11];

          var tooltip_txt = "<h5><i><b>" + probeId + "</b></i></h5>";
          tooltip_txt += "<i>" + trait + "</i><br>";
          tooltip_txt += "<b>pval: </b>" + pval + "<br>";
          tooltip_txt += "<b>or_beta:</b>" + or_beta + "<br>";
          tooltip_txt += "<a href=\"" + pubmedURL + "\">" + pid + "</a><br>";
          tooltip_txt += first_author + ", " + pub_date + "<br>";
          tooltip_txt += "<i>" + journal + "</i>";

          //<br><b>effect: </b>"+effect+"<br><b>info: </b>"+info+"<br><b>impact: </b>"+impact;
          showTooltip(item.pageX, item.pageY, tooltip_txt);
        } else {
          var desc_string = "<br>";
          var desc = xyl[3];
          var items = desc.split(";");
          $.each(items, function(i, item) {
            var key_val = item.split(":");
            desc_string += "<b>" + key_val[0] + "</b>: " + key_val[1] + "<br>";
          });
          $("#tooltip").remove();
          var tooltip_txt = "<h5><i><b>" + probeId + "</b></i></h5><hr class=\"reducedPadding_col\"><b>x</b>: " + x + "<br><b>y</b>: " + y;
          tooltip_txt += desc_string;
          showTooltip(item.pageX, item.pageY, tooltip_txt);
        }
      }
    } else {
      $("#tooltip").remove();
      previousPoint = null;
    }
  });
}

function bindGenomePlotHover(plot) {
  //tooltip text
  var previousPoint = null;
  var plotDiv = $("#" + plot.placeHolder);
  plotDiv.bind("plothover", function(event, pos, item) {
    //$("#x").text(pos.x.toFixed(2));
    //  $("#y").text(pos.y.toFixed(2));
    //updateLegend(plot.flotplot, pos);
    /*  if (item) {
	      if (previousPoint != item.datapoint) {
		        previousPoint = item.datapoint;
		  $("#tooltip").remove();
		  var x = item.datapoint[0].toFixed(0);
		  var y = item.datapoint[1].toFixed(2);
		  var xyl = item.series.data[item.dataIndex];
		  var probeId= xyl[2];
		  var type=xyl[3];
      var tooltip_txt="<h5><i><b>"+probeId+"</b></i></h5>";
        showTooltip(item.pageX, item.pageY,tooltip_txt);
	      }
	  }
	  else {
	      $("#tooltip").remove();
	      previousPoint = null;
	  }
    */
  });
}

function bindGenomePlotClick(divName, plot) {
  divName.off().on("plotclick", function(event, pos, item) {
    displayRegionForChr(pos.x);
  });
}

function updateLegend(plot, latestPosition) {
  updateLegendTimeout = null;
  var pos = latestPosition;
  var axes = plot.getAxes();
  var i, j, data = plot.getData();
  for (i = 0; i < 1; ++i) {
    $("#message").eq(i).text("y=" + pos.y.toFixed(2));
  }
}

function bindPlotClick(divName, plot) {
  divName.bind("plotclick", function(event, pos, item) {
    if (item) {
      if (document.getElementById("variantDetails_table_cb").checked) {
        $("#variantDetailsContainer").show();
      }
      var x = item.datapoint[0].toFixed(0);
      var y = item.datapoint[1].toFixed(3);
      var xyl = item.series.data[item.dataIndex];
      var probeId = xyl[2];
      var desc_string = "";
      if (item.series.gwasCatalog) {
        desc_string = "<b>Trait</b>: " + xyl[3] + " <b>Pubmed</b>: " + getPubmedHref(xyl[8]);
        currently_sel_dp="gwas_cat";
      } else {
        var desc = xyl[3];
        var items = desc.split(";");
        $.each(items, function(i, item) {
          var key_val = item.split(":");
          desc_string += "<b>" + key_val[0] + "</b>: " + key_val[1] + " ";
        });
      }
      var plot_id = divName[0].id;
      var plot_index = plot_id.charAt(plot_id.length - 1);
      var mainPlot = plots[plot_index];

      if (currently_sel_dp !== "") {
          mainPlot.rmSelectedSeries(); //remove the previously selected series
       if(!(ld_on_display)){
         if (currently_sel_dp !== probeId) {
           make_series_for_selected_point(item.series, xyl, mainPlot, probeId);
           showTooltip_snp_id("selected_snp", item.pageX, item.pageY, probeId);
           var x_can = plot.flotplot.getAxes().xaxis.p2c(sel_item_coord.x);
           var y_can = plot.flotplot.getAxes().yaxis.p2c(sel_item_coord.y);
           sel_item_coord = {"probeId": probeId,"x": x,"y": y, "gwas_cat": item.series.gwasCatalog};
        } else {
          currently_sel_dp = ""; //nothing is selected
          sel_inhouse_id = "";
          redrawPlot(mainPlot);
        }
      }
        else{
           rm_LD(plot_index);
           currently_sel_dp = ""; //nothing is selected
           sel_inhouse_id = "";
           redrawPlot(mainPlot);
        }
      }
      else {
        make_series_for_selected_point(item.series, xyl, mainPlot, probeId);
        showTooltip_snp_id("selected_snp", item.pageX, item.pageY, probeId);
        sel_item_coord = {"probeId": probeId,"x": x,"y": y, "gwas_cat": item.series.gwasCatalog};
      }
      if (typeof(item.series.phenotype) !== "undefined") {
        variantDetails[probeId] = [probeId, x, y, desc_string, item.series.phenotype];
        makeVariantDetailsTable();
      }
    }
  });
}

function redrawPlot(plot) {
  if (typeof(plot.ranges) != "undefined") { //are we zoomed in?
    plotSinglePlot(plot);
    zoomToRange(plot.ranges, plot);
  } else
    plotSinglePlot(plot);
}

function make_series_for_selected_point(series, data, mainPlot, probeId) {
  var sel_series = new Series(series.typeIndex, series.points.symbol, series.points.radius, series.impact);
  var tmp = [];
  tmp[0] = data;
  sel_series.set_as_selected(tmp);
  mainPlot.addSeries(sel_series);
  redrawPlot(mainPlot);
  pheno_of_curr_sel_db = series.phenotype;
  currently_sel_dp = probeId;
  return sel_series;
}

function makeVariantDetailsTable() {
  var tr;
  var td;
  var remover;
  var tbody = document.getElementById('variantDetailsBody');
  tbody.innerHTML = '';
  var variants = Object.keys(variantDetails);
  if (variants.length > 0) {
    for (var variant of variants) {
      tr = document.createElement('tr');
      var i = 0;
      for (var field of variantDetails[variant]) {
        if (i === 0) {
          if (field === currently_sel_dp) {
            tr.style = "background-color: #fee;opacity: 0.80";
          }
        }
        td = document.createElement('td');
        td.innerHTML = field; //field
        tr.appendChild(td);
        if (i === 4) { //put the remove button here instead of last
          td = document.createElement('td');
          remover = document.createElement('button');
          remover.className = "btn btn-smaller btn-primary";
          remover.innerHTML = 'Remove';
          remover.addEventListener('click', removeVariantDetails, true);
          td.appendChild(remover);
          tr.appendChild(td);
        }
        i++;
      }

      tbody.appendChild(tr);
    }
  } else {
    //  $("#variantDetailsContainer").hide();
    tbody.innerHTML = '<td colspan="9"><span class="instruction">Click on a variant in the plot to show its details here.</span></td>';
  }
  //make it a DataTable
  //$("#variantDetails").DataTable({"order" : [[3, "asc"]]});
}

function removeVariantDetails(evt) {
  evt.stopPropagation();
  var tr = evt.currentTarget.parentNode.parentNode;
  delete variantDetails[tr.firstChild.innerHTML];
  requestAnimationFrame(makeVariantDetailsTable);
}

//displays marker id above the point
function showTooltip_snp_id(div_id, x, y, contents) {
  $("#" + div_id).remove();
  $('<div id="' + div_id + '" class="snp_label">' + contents + '</div>').css({
    position: 'absolute',
    display: 'none',
    top: y - 23,
    left: x - 25,
    padding: '2px',
  }).appendTo("body").fadeIn(50);
}

function colorGene(evt, gene_id) {
  evt.stopPropagation();
  $.each(genes, function(i, gene) {
    if (typeof(gene.name) !== "undefined") {

      var gene = getGene(gene_id);
      if (typeof(gene) !== undefined) {}
    }
  });
}


function getGene(gene_id) {
  var gene;
  for (var i = 0; i < genes.length; i++) {
    if (genes[i].name === gene_id) {
      gene = genes[i];
      break;
    }
  }
  return gene;
}

function bindGenePlotHover() {
  var previousMarking = null;
  try {
    $("#genePlot").bind("plothover", function(event, pos, item) {
      $("#tooltip").remove();
      var markings = geneMarkings;
      if (noGenesOnDisplay < 30) {
        markings = exonMarkings;
      }
      var x_from;
      var x_to;
      var y_from;
      var y_to;
      var name;
      var gene;
      var disease = "";
      for (var i = 0; i < markings.length; i++) {
        gene = markings[i];
        name = gene.name;
        x_from = gene.xaxis.from;
        x_to = gene.xaxis.to;
        y_from = gene.yaxis.from;
        y_to = gene.yaxis.to;

        if (typeof(gene.disease) !== "undefined") {
          disease = gene.disease;
        }
        if ((pos.x >= x_from && pos.x <= x_to) && (pos.y >= y_from && pos.y <= y_to)) {
          //     $("#tooltip").remove();
          if (y_to != 0) { //dont display tooltip when hovering over the black divider line
            $("#tooltip").remove();
            //  showTooltip(pos.pageX, pos.pageY, "");

            showTooltip(pos.pageX, pos.pageY, "<h5><i>" + name + "</i></h5><b>pos:</b>" + x_from + "-" + x_to + "<br><i>" + disease + "</i>");

            if (item) {
              alert("You clicked at a gene  " + pos.x + ", " + pos.y);
            }
          }
        }
      }
    });
  } catch (e) {
    alert("ERROR in bindGenePlotHover " + e);
  }
}

function bindGenePlotClick() {
  $("#genePlot").bind("plotclick", function(event, pos, item) {
    var x_from;
    var x_to;
    var y_from;
    var y_to;
    var name;
    var gene;
    var ensId;
    for (var i = 0; i < geneMarkings.length; i++) {
      gene = geneMarkings[i];
      name = gene.name;
      ensId = gene.ensId;
      x_from = gene.xaxis.from;
      x_to = gene.xaxis.to;
      y_from = gene.yaxis.from;
      y_to = gene.yaxis.to;

      if ((pos.x >= x_from && pos.x <= x_to) && (pos.y >= y_from && pos.y <= y_to)) {
        $("#tooltip").remove();
        //  alert("click "+ensemblURL+""+ensId);
        window.open(ensemblURL + "" + ensId);
        $("#tooltip").remove();

        if (y_to != 0) { //dont display tooltip when hovering over the black divider line
          showTooltip(pos.pageX, pos.pageY, "");
          showTooltip(pos.pageX, pos.pageY, name + ", " + x_from + "-" + x_to);
          $("#tooltip").remove();
          if (item) {
            alert("You clicked at a gene  " + pos.x + ", " + pos.y);
          }
        }
      }
    }

  });
}
