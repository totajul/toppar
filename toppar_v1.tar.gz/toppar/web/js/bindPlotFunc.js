var dbSNP_url="http://www.ncbi.nlm.nih.gov/projects/SNP/snp_ref.cgi?rs=";

function bindSinglePlots(plots){

  $.each(plots, function(index, plot){
	   var plotDiv=$("#"+plot.placeHolder);
           var overviewDiv=$("#"+plot.overviewPlaceHolder);
	   plotDiv.bind("plotselected", function (event, ranges) {
			  zoomToRange(ranges, plot);//do the zooming
			});
	   overviewDiv.bind("plotselected", function (event, ranges) {
			      try{
				$.each(plots, function(index2, plot2){
					 plot2.flotplot.setSelection(ranges);
				       });
			      }catch(e){ alert("ERROR when binding plots "+e);}
			    });
	   bindPlotHover(plotDiv);
	   bindPlotClick(plotDiv, plot.flotplot);
           bindPlotZoom(plotDiv, plot.overviewPlot);
	   bindPlotPan(plotDiv, plot.overviewPlot, plot.flotplot);
         });
}

function bindPlotZoom(divName, overview, plot){
  divName.bind('plotzoom', function (event, plot) {
                 var axes = plot.getAxes();
                 $("#message").html("Zooming to : "  + axes.xaxis.min.toFixed(0)
                                    + " &ndash; " + axes.xaxis.max.toFixed(0));
                 overview.setSelection({xaxis: {from: axes.xaxis.min, to: axes.xaxis.max}});
               });
}

function bindPlotPan(divName, overview, plot){
  // show pan messages to illustrate events
  divName.bind('plotpan', function (event, plot) {
                 var axes = plot.getAxes();
                 $("#message").html("Panning to x: "  + axes.xaxis.min.toFixed(0)
                                    + " &ndash; " + axes.xaxis.max.toFixed(0));
                 overview.setSelection({xaxis: {from: axes.xaxis.min, to: axes.xaxis.max}});
               });
}

function bindPlotHover(divName){
  //tooltip text
  var previousPoint = null;
  divName.bind("plothover", function (event, pos, item) {
		 $("#x").text(pos.x.toFixed(2));
		 $("#y").text(pos.y.toFixed(2));
		 if (item) {
		   if (previousPoint != item.datapoint) {
		       previousPoint = item.datapoint;
		     var x = item.datapoint[0].toFixed(0);
		     var y = item.datapoint[1].toFixed(2);
		     var xyl = item.series.data[item.dataIndex];
		     var probeId= xyl[2];
		     var type=xyl[3];
		     $("#tooltip").remove();
		     //bold text, fix this, bad short term solution
		     type="<BR>"+type;
		     var type_b=type.replace(/<BR>/g, "<BR><B>");
		     type_b=type_b.replace(/:/g , " : </B>");
		     showTooltip(item.pageX, item.pageY, "<h5>"+probeId+"</h5><b>x</b>: "+x+"<br><b>y</b>: "+y+""+type_b);
		   }
		 }
		 else {
		     $("#tooltip").remove();
		   previousPoint = null;
		 }
	       });
}

function bindGenomePlotHover(divName,plot){
  //tooltip text
  var previousPoint = null;
  divName.bind("plothover", function (event, pos, item) {
	  $("#x").text(pos.x.toFixed(2));
	  $("#y").text(pos.y.toFixed(2));
	  //updateLegend(plot.flotplot, pos);

	  if (item) {
	      if (previousPoint != item.datapoint) {
		  previousPoint = item.datapoint;
		  $("#tooltip").remove();
		  var x = item.datapoint[0].toFixed(0);
		  var y = item.datapoint[1].toFixed(2);
		  var xyl = item.series.data[item.dataIndex];
		  var probeId= xyl[2];
		  var type=xyl[3];

		  // if(typeof type ===  ''){

		  //		 	 showTooltip(xyl[1], xyl[2]);

		  // }
		  //else{
		  //showTooltip("HELLO");//probeId+","+x+", "+y+"<br>");
		  //}
	      }
	  }
	  else {
	      $("#tooltip").remove();
	      previousPoint = null;
	  }
      });
}

function updateLegend(plot,latestPosition) {
  updateLegendTimeout = null;
  var pos = latestPosition;
  var axes = plot.getAxes();
  var i, j, data = plot.getData();
  for (i = 0; i < 1; ++i) {
    $("#message").eq(i).text("y=" + pos.y.toFixed(2));
  }
}

function bindGenomePlotClick(divName, plot){
  //  divName.bind("plotclick", function(event, pos, item){ //}").click(function(event, pos, item){ //})("plotclick", function(event, pos, item) {
  //use off() and on to prevent event from firing multiple times
  divName.off().on("plotclick", function(event, pos, item){ //}").cl
        displayRegionForChr(pos.x);
  });
}


function bindPlotClick(divName, plot){
  divName.bind("plotclick", function (event, pos, item) {
      var pubmed_url="http://www.ncbi.nlm.nih.gov/pubmed/";
      if (item) {
                   $("#clickdata").text("You clicked point " + item.dataIndex + " in " + item.series.label + ".");
                   //plot.highlight(item.series, item.datapoint);
		   var x=item.datapoint[0].toFixed(0);
		   var  y = item.datapoint[1].toFixed(0);
		   var xyl=item.series.data[item.dataIndex];
		   var probeId=xyl[2];
	  	 var pubmed_id=xyl[4];
	      var id=probeId.substring(2, probeId.length);
		   var div_id="tooltip"+probeId;
		   var divContent=$('#'+div_id);
		   if(divContent.length){
		       divContent.remove();
		       plot.unhighlight(item.series, item.datapoint);
		   }
		 else{
		     $("#tooltip").remove();
         var isnum = /^\d+$/.test(pubmed_id);
		     if((typeof(pubmed_id) != "undefined") && isnum)
                window.open(pubmed_url+''+pubmed_id, '_blank'); //_newtab
		     else
			       showTooltip3(div_id, item.pageX, item.pageY, probeId);
		    }
		 }
    });
}

//displays marker id above the point
function showTooltip3(div_id, x, y, contents) {
    $('<div id="'+div_id+'" class="marker_label">' + contents + '</div>').css({
            position: 'absolute',
		display: 'none',
		top: y - 23 ,
		left: x - 25,
		//border: '1px solid #fdd',
		padding: '2px',
		"font-size": "small",
		//'background-color': '#fee'
		}).appendTo("body").fadeIn(50);
}

function bindMarkerPlotClick(divName, plot){
    var previousPoint=null;
  divName.bind("plotclick", function (event, pos, item) {
                 if (item) {
		     if(previousPoint != item.datapoint){
			 previousPoint=item.datapoint;
			 $("#tooltip").remove();
		 	 var x=item.datapoint[0].toFixed(0);
			 var xyl=item.series.data[item.dataIndex];
			 var probeId=xyl[2];
			 var id=probeId.substring(2, probeId.length);
			 window.open(dbSNP_url+''+id, '_blank'); //_newtab
		     }
		     //window.open('http://www.well.ox.ac.uk','_blank');//_newtab


   //$("#clickdata").text("You clicked point " + item.dataIndex + " in " + item.series.label + ".");
		     //plot.highlight(item.series, item.datapoint);
                 }
               });
}

function bindMarkerPlotHover(divName){
  var previousPoint = null;
  divName.bind("plothover", function (event, pos, item) {
		 $("#x").text(pos.x.toFixed(2));
		 $("#y").text(pos.y.toFixed(2));
		 if (item) {
		   if (previousPoint != item.datapoint) {
		     previousPoint = item.datapoint;
		     $("#tooltip").remove();
		      var x = item.datapoint[0].toFixed(0);
		      var xyl = item.series.data[item.dataIndex];
		      var maf=xyl[1];
		      //var pos=xyl[2];
		      var probeId= xyl[2];
		      var type=xyl[3];
		      var annot=xyl[4];
		     if(probeId.match(/^rs/)){
			     var id=probeId.substring(2, probeId.length);
			     probeId="<a href="+dbSNP_url+""+id+" target=_blank>"+probeId+"</a>";
		     }
		     showTooltip(item.pageX, item.pageY, probeId+", "+x+"<br>MAF:"+maf+"<br>type: "+type+"<br>"+annot);
		   }
		 }
		 else {
		   $("#tooltip").remove();
		   previousPoint = null;
		 }
	       });
}

function bindGenePlotHover(){
  var previousMarking = null;
    try{
    $("#genePlot").bind("plothover", function (event, pos, item) {
	    $("#tooltip").remove();
	var markings=geneMarkings;
	if(noGenesOnDisplay < 30){
	    markings=exonMarkings;
	}
        var x_from; var x_to; var y_from; var y_to;
	var name; var gene; var disease="";
                          for (var i = 0; i < markings.length; i++) {
                            gene=markings[i];
                            name=gene.name;
                            x_from=gene.xaxis.from;
                            x_to=gene.xaxis.to;
                            y_from=gene.yaxis.from;
                            y_to=gene.yaxis.to;

			    if(typeof(gene.disease) !== "undefined"){
				disease=gene.disease;
			    }
                            if((pos.x >= x_from && pos.x <= x_to)&& (pos.y >= y_from && pos.y <= y_to)){
				//     $("#tooltip").remove();
                              if(y_to != 0){ //dont display tooltip when hovering over the black divider line
				  $("#tooltip").remove();
                              //  showTooltip(pos.pageX, pos.pageY, "");

				  showTooltip(pos.pageX, pos.pageY, "<h5>"+name+"</h5><b>pos:</b>"+x_from+"-"+x_to+"<br><i>"+disease+"</i>");

                                if(item){
                                  alert("You clicked at a gene  " + pos.x + ", " + pos.y);
                                }
                              }
                            }
                          }
                        });
  }
  catch(e){
    alert("ERROR in bindGenePlotHover "+e);
  }
}

function bindGeneGenomePlotHover(genomeMarkings){
  var previousMarking = null;
    try{
	$("#genesGenomePlot").bind("plothover", function (event, pos, item) {
	 $("#tooltip").remove();
	    var markings=genomeMarkings;
            var x_from; var x_to; var y_from; var y_to;
            var name; var gene;
            for (var i = 0; i < markings.length; i++) {
                gene=markings[i];
                //console.log(gene);
		if(typeof(gene.yaxis) !=  "undefined"){
		    name=gene.name;
		    x_from=gene.xaxis.from;
		    x_to=gene.xaxis.to;
		    y_from=gene.yaxis.from;
		    y_to=gene.yaxis.to;
		     if((pos.x >= x_from && pos.x <= x_to)&& (pos.y >= y_from && pos.y <= y_to)){
			$("#tooltip").remove();
			if(y_to != 0){ //dont display tooltip when hovering over the black divider line
			    $("#tooltip").remove();
			    //  showTooltip(pos.pageX, pos.pageY, "");
			    showTooltip(pos.pageX, pos.pageY, name+", "+gene.disease);

			    if(item){
				alert("You clicked at a gene  " + pos.x + ", " + pos.y);
			    }
			 }
		    }
		     }
	    }
	    });
    }
  catch(e){
    alert("ERROR in bindGenePlotHover "+e);
  }
}

function bindGenePlotClick(){
  var ensemblURL=ensembl;
  $("#genePlot").bind("plotclick", function(event, pos, item){
                        var x_from; var x_to; var y_from; var y_to;
                        var name; var gene; var ensId;
                        for (var i = 0; i < geneMarkings.length; i++) {
                          gene=geneMarkings[i];
                          name=gene.name;
                          ensId=gene.ensId;
                          x_from=gene.xaxis.from;
                          x_to=gene.xaxis.to;
                          y_from=gene.yaxis.from;
                          y_to=gene.yaxis.to;

                          if((pos.x >= x_from && pos.x <= x_to)&& (pos.y >= y_from && pos.y <= y_to)){
                            $("#tooltip").remove();
                            //  alert("click "+ensemblURL+""+ensId);
                            window.open(ensemblURL+""+ensId);
                            $("#tooltip").remove();

                            if(y_to != 0){ //dont display tooltip when hovering over the black divider line
                              showTooltip(pos.pageX, pos.pageY, "");
                              showTooltip(pos.pageX, pos.pageY, name+", "+x_from+"-"+x_to);
                              $("#tooltip").remove();
                              if(item){
                                alert("You clicked at a gene  " + pos.x + ", " + pos.y);
                              }
                            }
                          }
                        }

                      });
}
