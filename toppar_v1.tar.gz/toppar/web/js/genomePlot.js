

function prepareGenomeHolder(){
  //hide
  $("#region").hide();
  $("#variantDetailsContainer").hide();
  //empty
  $("#results_genome_tables").empty();
  $("#genomePlots").empty();
  $("#message").empty();
  //show
  $("#genomePlots").show();
  $("#genome").show();
  if(document.getElementById("regionPlots").childNodes.length > 0)
      $("#backToRegion").show();
  //remove
  $(".snp_label").remove();   //remove outstanding marker labels
  $("#tooltip").remove();
}

function backToGenomeView(){
  $("#region").hide();
  $("#genome").show()
  $("#radio_genome").prop('checked' , true);
//$("#regionBtns_href").show();
 $("#regionBtns_href").hide();
  $(".snp_label").remove();   //remove outstanding marker labels
  $("#tooltip").remove();
  show_genome_btns();
  if(document.getElementById("regionPlots").childNodes.length > 0)
    $("#backToRegion").show();
}


//getGenomes when the genome button is clicked
function getGenome(){
//  checkSelection();
  prepareGenomeHolder();
  getPlotData(true, "null");
}//plot.flotplot= $.plot(plotDiv, plot.seriesArray, $.extend(true, {}, getRegionPlotOptions(plot, x_from, x_to) , getExtendedOptions(ranges, axes, plot.plot_type, null))); //replace with m.yMin


function plotGenome(plot){
  var phenoIndex=plot.phenoIndex;
  var plotName=$("#genomePlot"+phenoIndex); //mainPlot0
  plotName.show();
  plot.labelsDiv=$("#mlabels"+phenoIndex);
  $("#unitG"+phenoIndex).empty();
  $("#unitG"+phenoIndex).show();
  $("#genomeLabel"+phenoIndex).show();
  plot.labelsDiv.show();
  $("#unitG" + phenoIndex).append(plot.seriesArray[0].unit);
    try{
        var options=getMultiPlotOptions(plot.labelsDiv, plot.seriesArray);
        plot.flotplot = $.plot(plotName, plot.seriesArray, options);
  }
  catch(e){
    alert("ERROR in function plotGenome: "+e);
  }
  addChrLabelsToGenome(plot);
  addSignificanceThreshold(plot);
  bindGenomePlotHover(plot);
  bindGenomePlotClick(plotName, plot);
}

 function displayRegionForChr(pos){
   var lastPos=getChrEnd(chr_names.length-1);
   for(var i=0; i< getNoOfChr(); i++){
     if(pos < getChrEnd(i)){
       $("#chromosomes").val(getChr(i));
       show_region_btns();
       getRegion(getChr(i));
       i=getNoOfChr();
     }
     lastPos=getChrEnd(i);
   }
 }


 function addChrLabelsToGenome(plot){
   var axes = plot.flotplot.getAxes();
   var xc = axes.xaxis.p2c;
   var yMax=plot.flotplot.getAxes().yaxis.max;
   o = plot.flotplot.pointOffset({ x: 0, y: yMax});
   $("#"+plot.placeHolder).append('<div style="position:absolute;left:' + (o.left+4) + 'px;top:' + o.top + 'px;color:#666;font-size:smaller">'+getChr(0)+'</div>');
   for(var i=0; i< chr_names.length-1; i++){
      o = plot.flotplot.pointOffset({ x: getChrEnd(i), y: yMax});
      $("#"+plot.placeHolder).append('<div style="position:absolute;left:' + (o.left+4) + 'px;top:' + o.top + 'px;color:#666;font-size:smaller">'+getChr(i+1)+'</div>');
   }
 }

 function setGenomePlotDivs(plot){
   var html="";
   var phenoIndex=plot.phenoIndex;
   var label='<span id="mlabels'+phenoIndex+'"></span>';
   plot.placeHolder="genomePlot"+phenoIndex;
   var genomeLabel='<span style="display:none" class="phenoLabel" id="genomeLabel'+phenoIndex+'">'+plot.phenoType+'</span>';
   var unitDiv='<div id="unitG'+phenoIndex+'"></div>';
   $("#unitG"+phenoIndex).empty();
   var gwasCheckBox='<div  class="checkbox" ><label><input id="gwasGenomeCB'+phenoIndex+'" onclick="plotGWASCatalogGenome(\''+phenoIndex+'\')" type="checkbox">show GWAS catalog SNPs</label></div>';
   var gwasDiv='<div id="gwasGenomeCheckbox'+phenoIndex+'" class="graphTxt">'+gwasCheckBox+'</div>';
   var gwasColorLabel='<label id="gwasColorLabel'+phenoIndex+'" class="graphTxt">Color GWAS snp/s by trait:</label>';
   var gwasLabelText='<div class="form-inline2"><input type="text" class="form-control2" placeholder="Ex: Ulcerative" id="gwasTermGenome'+phenoIndex+'" name="gwasTermGenome'+phenoIndex+'">';
   gwasLabelText+='<select class="form-control2" id="gwasColorSelectGenome'+phenoIndex+'"><option selected>red</option><option>purple</option><option>orange</option><option>lightblue</option><option>green</option><option>yellow</option><option>black</option></select><button type="submit" class="btn btn-smaller btn-info" onclick="gwasTermFilterGenome(\''+phenoIndex+'\')">Submit</button> </div>';

   var html='<table><tr><td></td><td>';
   html+='</td></tr>';
   html+='<tr><td>&nbsp</td><td>';

   html+='<table><tr><td>'+genomeLabel+'</td><td><td>&nbsp&nbsp&nbsp&nbsp</td><td>&nbsp&nbsp&nbsp&nbsp</td>';
   html+='<td>'+gwasDiv+'</td><td>&nbsp&nbsp</td><td>&nbsp&nbsp</td><td>'+gwasColorLabel+''+gwasLabelText+'</td>';
   html+='</tr></table>';
   html+='</td></tr><tr><td>'+unitDiv+'</td><td><div class=\"genomePlot\" id="genomePlot'+phenoIndex+'\"></div></td>';
   html+='<td valign="top">'+label+'</td>';
   html+='</tr></table>';
   return html;
 }


function hideResultsGenomeTableDiv(id){
     if(document.getElementById(id).checked){
 	         $('#results_genome_tables').show();
            //check whether the table has already been created:
             if($("#resultsgenome_table").html() === "")
                  mk_results_genome_DataTable();
      }
     else
          $('#results_genome_tables').hide();
 }
