var useMultiSelect=true; //turn the select menus into a multipleSelect menu
var n_total_proj=0; var n_total_pheno=0; var n_total_qt=0; var n_total_cc=0;
var cat2proj; var proj2pheno;
var projects; var phenotypes;
var qt_checked=true; var cc_checked=true;
var selected_projects;

function init_cat_proj_menus(){
    try{
     	$.ajax({
	    type: "get",
	    url: get_cat2proj,
	    success: function(jsonFile){
		      try{
		          $.getJSON(jsonFile, function(d){
                  cat2proj=d;
                  category_and_project_menu_insert(d);
              });
            }catch(e){alert("error when reading jsonFile "+e);}
	   }
	});
  }catch(e){ alert("error when reading jsonFile "+e);}
}

function init_phenotype_menu(){
    try{
     	$.ajax({
	    type: "get",
	    url: get_proj2pheno,
	    success: function(jsonFile){
          try{
		          $.getJSON(jsonFile, function(d){
                  proj2pheno=d;
                  phenotype_menu_init(d);
              });
            }catch(e){alert("error when reading jsonFile in init_phenotype_menu "+jsonFile+"  "+e);}
	   }
	});
}catch(e){ alert("Ajax error in init_phenotype_menu "+e);}
}
/*Upon initiation, fill the category and project menus with all the categories and projects in the database*/
function category_and_project_menu_insert(data){
      var categories=[]; projects=[];
      $.each(data, function(i, category){
           categories.push(category.name);

           projects.push.apply(projects, category.projects);
         });
    n_total_proj=projects.length;
    populate_menu($("select#category"), categories, "Categories",  categories.length+"/"+categories.length);
    populate_menu($("select#project"), projects, "Projects", projects.length+"/"+projects.length);
}

/*Upon initiation, fill the category and project menus with all the categories and projects in the database*/
function phenotype_menu_init(data){
      phenotypes=[];
      qt=[];cc=[];
      $.each(data, function(i, project){
              qt.push.apply(qt, project.qt);
              cc.push.apply(cc, project.cc);
              phenotypes.push.apply(phenotypes, project.qt);
              phenotypes.push.apply(phenotypes, project.cc);
         });
    n_total_qt=qt.length; n_total_cc=cc.length;
    n_total_pheno=n_total_qt+n_total_cc;
    if(useMultiSelect)
        set_multipleSelect($("select#phenotype"));
    $("#Phenotypes_count").html("Phenotypes : 0/"+phenotypes.length+ "  :( QT: 0/"+n_total_qt+" and CC: 0/"+n_total_cc+" )");
  //  populate_menu($("select#phenotype"), phenotypes, "Phenotypes", phenotypes.length);
}

/*When menu items get selected (or content changes) these functions get triggered*/
$(function(){
$("select#category").change(function(){
	  var selected_categories=$(this).val();
    if(selected_categories !== null){
       if(selected_categories.length > 0)
            set_projects_for_selected_categories(selected_categories);
        else {
              populate_menu($("select#project"), projects, "Projects", projects.length+"/"+n_total_proj);
        }
  }
  else {//fill the projects menu with all the projects if no category is selected. This is consisent with the menu setup on initiation. Alternatively,just empty the projects menu
        populate_menu($("select#project"), projects, "Projects", projects.length+"/"+n_total_proj);
      }
    });
  $("select#project").change(function(){
      var tmp=$(this).val();
      if(tmp !== null){
        selected_projects=unique(tmp);
        if(selected_projects.length > 0)
            set_phenotypes_for_selected_projects();
        else
          populate_menu($("select#phenotype"), [], "Phenotypes", "0/"+n_total_pheno+" :(QT: 0/"+n_total_qt+" and CC: 0/"+n_total_cc+")");
      }
      else{
          populate_menu($("select#phenotype"), [], "Phenotypes", "0/"+n_total_pheno+" :(QT: 0/"+n_total_qt+" and CC: 0/"+n_total_cc+")");
      }
  });
  $("#QT_checkb").change(function(){
    qt_checked=false;
    if( $('#QT_checkb').prop('checked'))
      qt_checked=true;
    if(selected_projects.length > 0)
        set_phenotypes_for_selected_projects();
  });
  $("#CC_checkb").change(function(){
    cc_checked=false;
    if( $('#CC_checkb').prop('checked') )
          cc_checked=true;
      if(selected_projects.length > 0)
          set_phenotypes_for_selected_projects();
  });
});
/*The functions below are used after initiation */
/*change the projects menu to only include projects under the selected categories*/
function set_projects_for_selected_categories(selected_categories){
    var projects_sel=[];
    $.each(selected_categories, function(j, selected){
      $.each(cat2proj, function (i, cat_obj){
          if(cat_obj.name === selected)
               projects_sel.push.apply(projects_sel, cat_obj.projects);
    });
});
  populate_menu($("select#project"), projects_sel, "Projects", projects_sel.length+"/"+n_total_proj);
}

/*change the phenotype menu to only include phenotypes under the selected projects*/
function set_phenotypes_for_selected_projects(){
    var phenotypes_sel=[]; var cc_c=0; var qt_c=0;
   $.each(selected_projects, function(j, selected){
      $.each(proj2pheno, function (i, proj_obj){
          if(proj_obj.name == selected){
               //if QT selected
               if(qt_checked){
                    phenotypes_sel.push.apply(phenotypes_sel, proj_obj.qt);
                    qt_c+=proj_obj.qt.length;
                  }
               if(cc_checked){
                  phenotypes_sel.push.apply(phenotypes_sel, proj_obj.cc);
                  cc_c+=proj_obj.cc.length;
                }
          }
      });
    });
 populate_menu($("select#phenotype"), unique(phenotypes_sel), "Phenotypes",  "<b>"+phenotypes_sel.length+"</b>/"+n_total_pheno+" :(QT: <b>"+qt_c+"</b>/"+n_total_qt+" and CC: <b>"+cc_c+"</b>/"+n_total_cc+")");
}

/*populate the drop down menu with the id/tag drop with items*/
function populate_menu(drop, itm, type, item_count){
    drop.empty();
    items=unique(itm);
    for(var i=0; i< items.length; i++){
	     drop.append('<option value=' +items[i]+ '> ' +items[i]+ ' </option>');
    }
    if(useMultiSelect){
        drop.hide();
        set_multipleSelect(drop);
    }
      $("#"+type+"_count").html(type+": "+item_count);
}

function set_multipleSelect(drop){
  //  $("select#"+menu_id).multipleSelect({
drop.multipleSelect({
  isOpen:true,
	keepOpen: true,
	filter: true,
        maxHeight: 210
    });
}

function set_multipleSelect_wo_filter(drop){
  //  $("select#"+menu_id).multipleSelect({
drop.multipleSelect({
	isOpen: true,
	keepOpen:  true,
	filter: false,
	maxHeight: 70
    });
}

function get_qt_phenotypes(project_name, type){
  var qt=[];
    $.each(proj2pheno, function(i, project){
        if(project.name ===  project_name){
              qt=project.qt;
              return qt;
        }
    });
    return qt;
}

function get_cc_phenotypes(project_name, type){
  var cc=[];
    $.each(proj2pheno, function(i, project){
        if(project.name ===  project_name){
              cc=project.cc;
              return cc;
        }
    });
    return cc;
}

function change_menu(id){
  var label=$("#menus_label");
  label.empty();
  $(".snp_label").remove();   //remove outstanding marker labels
  $("#tooltip").remove();
  if (id === "lookup_menu"){ //show the lookup menu and hide the currently displayed filter menu
      label.append("<a id=\"menu_label_href\" href=\"#\" onclick=\"change_menu('filter_menu'); return(false);\">Change to Filter Menu...</a>");
      $("#filter_menu").hide();
      $("#lookup_menu").show();
      $("#find_lists").autocomplete({
          source: phenotypes,
          minLength: 2
      });

  }
  else{ //show the filter menu and hide the lookup menu
    label.append("<a id=\"menu_label_href\" href=\"#\" onclick=\"change_menu('lookup_menu'); return(false);\">Change to Lookup Menu...</a>");
    $("#lookup_menu").hide();
    $("#filter_menu").show();

  }
}
