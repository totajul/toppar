var genesSeen = [];

function zoomToRange(ranges, plot, bp_pos, find_and_select_datapoint){
    $("#tooltip").remove(); //remove any remaining tooltips                                                                                                                                  
    //$(".snp_label").remove();                                                                                                                                                              
    if(!(plot))
        plot=plots[0];
    setGenesWithinInterval(Math.round(ranges.xaxis.from), Math.round(ranges.xaxis.to), plot.chr, redraw_genes_DataTable);
    $("#message").html("Zooming to : "  +ranges.xaxis.from.toFixed(0)+ "-" +ranges.xaxis.to.toFixed(0));
    $.each(plots, function(i, plot){ //for every plottable scan                                                                                                                                
	    zoomOnPlots(plot, 2, ranges);
	});
    if($("#results_region_tables").html() !== ""){
	redraw_results_DataTable(Math.round(ranges.xaxis.from), Math.round(ranges.xaxis.to), plot.chr, redraw_results);
    }
    else{
	//results_region_table_cb                                                                                                                                                                
	if(document.getElementById("results_region_table_cb").checked){
	    mk_results_region_DataTable();
	    redraw_results_DataTable(Math.round(ranges.xaxis.from), Math.round(ranges.xaxis.to), plot.chr, redraw_results);
	}
    }
    //do the same for gwas cat table
if($("#gwascat_region_table").html() !== ""){
	redraw_gwas_DataTable(Math.round(ranges.xaxis.from), Math.round(ranges.xaxis.to));
    }
    else{
	if($("#gwascat_region_table_cb").is(":checked")){
	    mk_gwas_region_DataTable();
	    redraw_gwas_DataTable(Math.round(ranges.xaxis.from), Math.round(ranges.xaxis.to));
	}
    }
    if(find_and_select_datapoint && typeof(find_and_select_datapoint) === "function"){
        find_and_select_datapoint(plot.chr,bp_pos);
    }
}


function zoomOnPlots(plot, radius, ranges){
    var x_from=parseInt(ranges.xaxis.from.toFixed(0));
    var x_to=parseInt(ranges.xaxis.to.toFixed(0));
  //  var phenoIndex=plot.proj_index;
    var seriesCounter=plot.seriesArray.length;
    $('#info'+plot.proj_index).empty();
    plot.setRanges(ranges);
    $.each(plot.seriesArray, function(index, series){
	    //series.data=[];
	     series.data=getDataWithinInterval(series.origData, x_from, x_to);
     	 changeDisplay(series, x_from, x_to, plot.phenoIndex);
       seriesCounter--;
       if(seriesCounter == 0)
          zoom(plot,ranges, add_tooltip);

   });
}

function setRange(options, x_from, x_to){
  options.xaxis.min=x_from;
  options.xaxis.max=x_to;
}

function add_tooltip(plot){
  if(currently_sel_dp !== ""){
      var flotplot=plot.flotplot;
      var plotDiv=$("#"+plot.placeHolder);
      var graphx=plotDiv.offset().left+30;
      var graphy=plotDiv.offset().top+10;
      var x_can=flotplot.getAxes().xaxis.p2c(sel_item_coord.x);
      var y_can=flotplot.getAxes().yaxis.p2c(sel_item_coord.y);
      var probeId=sel_item_coord.probeId;
      showTooltip_snp_id("selected_snp", parseFloat(graphx)+parseFloat(x_can), parseFloat(y_can)+parseFloat(graphy), probeId);
  }
}

function zoom(plot, ranges, add_tooltip){
  var x_from=ranges.xaxis.from;
  var x_to=ranges.xaxis.to;
  var axes=plot.flotplot.getAxes();
  var plotDiv=$("#"+plot.placeHolder);
  $(".snp_label").remove(); //remove all marker labels since coordinates wont match after zooming
  plot.flotplot.clearSelection();
  plot.flotplot= $.plot(plotDiv, plot.seriesArray,  getRegionPlotOptions(plot,ranges)); //replace with m.yMin
  if(plot){
      addZoomOutBtn(plot.placeHolder, plot.flotplot, chr);
      addChrLabel(plot);
      addSignificanceThreshold(plot);
      plot.overviewPlot.setSelection(ranges, true);
  }
  zoomToRangeOnGenePlot(ranges, plot.chr);
  if( $('#showTADs').prop('checked') )
     zoomToRangeOnTADPlot(ranges, plot.chr);
   if(add_tooltip && typeof(add_tooltip) === "function")
      add_tooltip(plot);
}

function changeLabel(val, type, options){
  var innerHTML=options.legend.container[0].innerHTML;
  var scantypes=$("#scantypes").val();
  $.each(scantypes, function(i, scantype){
	   if(type === scantype){
	     innerHTML=innerHTML.replace(scantype, scantype+ "  "+val);
	   }
	 });
  return innerHTML;
}



function zoomToRangeOnGenePlot(ranges,chr){
  //genePlot = $.plot($("#genePlot"), geneMarkings, getGenePlotOptions(0, chrLength));
    var x_from=parseInt(ranges.xaxis.from);
    var x_to=parseInt(ranges.xaxis.to);
    var exons=[];
    if(typeof(genes_current) != "undefined")
	       noGenesOnDisplay=genes_current.length;
    if(noGenesOnDisplay < 30)
       get_exons(chr, ranges)
    else{
	      var options=getGenePlotOptions(x_from, x_to,geneMarkings);
	      var genePlot=$.plot(("#genePlot"), geneMarkings, options);
	      overviewGenePlot.setSelection(ranges,true);
	      addStrandLabel(genePlot);
    }
}

function zoomToRangeOnTADPlot(ranges,chr){
  var x_from=parseInt(ranges.xaxis.from);
  var x_to=parseInt(ranges.xaxis.to);
  var tadMarkings = getTADMarkings(tads, getChrEnd(chr));
  var tadPlot=$.plot(("#TADPlot"), tadMarkings, getTADPlotOptions(x_from, x_to, tadMarkings));
}

function checkSeenGenes(){
    var notSeen=[];
    $.each(genes_current, function(i, gene){
      var name=gene.name;
	if(!(_.contains(genesSeen, name))){
	    notSeen.push(name);
	    genesSeen.push(name);
	}
    });
    return notSeen;
}

function getDisease(genename){
  var gene_disease="";
  $.each(genes_current, function(i, gene){
      if(gene.name == genename){
        gene_disease=gene.disease;
      }
  });
  return gene_disease;
}

function get_exons(chr, ranges){
  var x_from = parseInt(ranges.xaxis.from);
  var x_to = parseInt(ranges.xaxis.to);
      var notSeen=checkSeenGenes();
      try {
          //get all the genes for from the specified build and chromosome
          //if genes have not been zoomed in on before.
          if (notSeen.length > 0) {
              gene_names_str = notSeen.join();
              var script = get_exons_cgi + "?chr="+chr+"&genes=" + gene_names_str;
              $.ajax({
                  type: "GET",
                  url: script,
                  data: "format=json&id=123",
                  dataType: 'json',
                  success: function(d) {
                      for (var i = 0; i < d.length; i++) {
                          var disease=getDisease(d[i].gene);
                          $.each(d[i].exons, function(j, exon ){
                              addExonToMarkings(new Exon(exon, d[i].gene, disease));
                          });


                      }
                      plotExons(ranges, x_from, x_to);
                  },
                  error: function(xhr, textStatus, errorTHrown) {
                      alert('request failed');
                  }
              });
          } else {
              plotExons(ranges, x_from, x_to);
          }
      } catch (err) {
          alert("ERROR in function zoomToRangeOnGenePlot " + err);
      }
}



function plotExons(ranges,x_from, x_to){
    var options=getGenePlotOptions(x_from, x_to, exonMarkings);
    var genePlot=$.plot(("#genePlot"), exonMarkings, options);
    overviewGenePlot.setSelection(ranges,true);
    addStrandLabel(genePlot);
}

function addExonsToGeneMarkings(exons,ranges, x_from, x_to){
    $.each(exons, function(i, exon){
      var strand=exon.strand.replace(/ /g,"");
      var y_from=-5; var y_to=-11;

      var exonColor="#FF4F00";
      if((strand == "1")||(strand == "+")){
	          y_from=5;
	          y_to=11;
      }
      exObj={color:exonColor,  xaxis:{from: exon.bpStart, to: exon.bpEnd},yaxis: {from: y_from, to: y_to}, name: exon.ensId, ensId: exon.ensId};
	    exonMarkings.push(exObj);
    });
    plotExons(ranges, x_from,x_to);
}

function getDiffGene(from,to){
  if (to - from < 150000)
    return true;
  return false;
}

function getDiff(from,to){
  if (to - from < range_interactive)
      return true;
  return false;
}
/*
  in big zoom-outs, use original data... in lower level zoom outs use chunks.
  testing: 117467996..119801827  117467996..119801827
*/
function getDataWithinInterval(d,from, to){
  var tmp=[]; var firstPoint=1;var lastPoint;
  for(var j=0; j< d.length; j++){
      var pos=parseInt(d[j][0]);
      if((pos >= from) && (pos <= to)){
	         //if(firstPoint){
	          //  if(j>0)
		        //      tmp.push(d[j-1]);
	          //  firstPoint=0;
	      //  }
	        tmp.push(d[j]);
	      //  lastPoint=j;
    }
  }
//  tmp.push(d[lastPoint+1]);
  return tmp;
}

function changeDisplay(series, x_from, x_to, phenoIndex){
    if(getDiff(x_from, x_to)){
	if(x_to - x_from  >  range_ld_calc){
            series.points.radius=1.5;

	    $('#ldBtn'+phenoIndex).attr("disabled", false);
	}
      else{
          $('#ldBtn'+phenoIndex).attr("disabled", false);
	  series.points.radius=2;
      }
      series.points.fill=false;
    }
    else{
      series.points.radius=1;
      series.points.fill=true;
      $('#ldBtn'+phenoIndex).attr("disabled", true);
    }
  }

//handle this within the series object
function resetDisplay(seriesArray){
  var radius=1;
  $.each(seriesArray, function(i, series){
	  if(series.plot_type == "point"){
	      if(typeof(series.points) !== "undefined"){
		  series.points={show:series.points.show, radius : radius, fillColor: series.color, symbol: series.points.symbol};
		  series.lines={show:false};
	      }
	      else{
		  series.points={show:true, radius : radius, fillColor: series.color, symbol: series.symbol};
		  series.lines={show:false};
	      }
	  }
	  else{
	      series.lines={show:true};
	      series.points={show:false};
           }
      });
}

function showAll(){
  zoomOnPlots(plots[0],2, plots[0].ranges);
}


function  checkJSON (files,from, to){
  var jsfiles=[];//in case two files are needed
  var done=0;
  $.each(files, function(i, file){
	   if(!done){
             var f_from=parseInt(file[1]);
             var f_to=parseInt(file[2]);
             var name=file[0];
             if(f_to >= to){
               if(f_from <= from){ //only one file spanning the interval
                 jsfiles.push(file[0]);
                 done=1;
               }
               else{ //multiple files spanning the interval
                 var j=i;
                 while(f_from >= from){

		   if(files[j]){
		     jsfiles.push(files[j][0]);
		     j--;
		     if(files[j])
		       f_from=parseInt(files[j][1]);
		     else
		       f_from=0;
		   }
                 }
                 //add the last file, when f_from < from
                 if(files[j])
                   jsfiles.push(files[j][0]);
                 done=1;
               }
             }
           }
	 });
  return jsfiles;
}
