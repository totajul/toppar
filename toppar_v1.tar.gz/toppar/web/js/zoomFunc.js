var genesSeen = [];
var gene_names;

function zoomToRange(ranges, plot) {
    $("#tooltip").remove(); //remove any remaining tooltips
    var x_from = ranges.xaxis.from.toFixed(0);
    var x_to = ranges.xaxis.to.toFixed(0);
    x_from_gl = x_from;
    x_to_gl = x_to;
    if (!(plot))
        plot = plots[0];
    gene_names = addAnnotation(Math.round(ranges.xaxis.from), Math.round(ranges.xaxis.to), plot.chr);
    $.each(plots, function(i, plot) { //for every plottable scan
        $("#message").html("Zooming to : " + x_from + ".." + x_to);
        zoomOnPlots(plot, 2, ranges, gene_names);
    });
}

function checkSeenGenes(gene_names) {
    var notSeen = [];
    $.each(gene_names, function(i, name) {
        if (!(_.contains(genesSeen, name))) {
            notSeen.push(name);
            genesSeen.push(name);
        }
    });
    return notSeen;
}

function zoomOnPlots(plot, radius, ranges, gene_names) {
    var x_from = ranges.xaxis.from.toFixed(0);
    var x_to = ranges.xaxis.to.toFixed(0);
    var phenoIndex = plot.phenoIndex;
    var seriesCounter = plot.seriesArray.length;
    var jsonLimit = 500;
    var limit = 2000;
    $('#info' + plot.phenoIndex).empty();
    resetDisplay(plot.seriesArray);
    plot.setRanges(ranges);

    $.each(plot.seriesArray, function(index, series) {
        series.data = [];
        series.data = getDataWithinInterval(series.origData, x_from, x_to);
        series.pointsWithinInterval = series.data.length;
        series.pointsOnDisplay = series.data.length;

        if (series.data.length < jsonLimit) {
            if (series.file) {
                series.json = checkJSON(series.file, x_from, x_to);
                var jsonCount = series.json.length;

                if (jsonCount >= 1) { //if there are jsonFiles
                    disableCheckbox(false, phenoIndex);
                    $.each(series.json, function(i, jsonFile) {
                        var chunk = series.getChunk(jsonFile);
                        if (chunk != "null") {
                            series.data = series.data.concat(chunk.data);
                            jsonCount--;
                            if (jsonCount == 0) {
                                series = setData(series, x_from, x_to, limit, phenoIndex);
                                seriesCounter--;
                                if (seriesCounter == 0) {
                                    $('#info' + phenoIndex).append(series.label + ":  " + series.getPercentage() + "%   (" + series.pointsOnDisplay + "/" + series.pointsWithinInterval + ")");
                                    zoom(plot, ranges, gene_names);
                                }
                            }
                        } else {
                            $.getJSON(jsonFile, function(d) {
                                series.addChunk(jsonFile, d.data);
                                series.data = series.data.concat(d.data);
                                var jsons = jsonFile.split("/");
                                jsonCount--;
                                if (jsonCount == 0) {
                                    series = setData(series, x_from, x_to, limit, phenoIndex);
                                    seriesCounter--;
                                    if (seriesCounter == 0) {
                                        $('#info' + phenoIndex).append(series.label + ":  " + series.getPercentage() + "%   (" + series.pointsOnDisplay + "/" + series.pointsWithinInterval + ")");
                                        zoom(plot, ranges, gene_names);
                                    }
                                }
                            });
                        }
                    });
                }
            } else {
                changeDisplay(series, x_from, x_to);
                seriesCounter--;
                if (series.data.length == 1) //series.data is Undefined since there were no datapoints within the interval...
                    series.data = series.origData;

                if (seriesCounter == 0) {
                    zoom(plot, ranges, gene_names);
                }
            }
        } //if data.length > limit
        else {
            disableCheckbox(true, phenoIndex);
            seriesCounter--;
            if (seriesCounter == 0) {
                var tmp = 2000;
                if (!($("#showAllcheckbox" + phenoIndex).prop('checked'))) {

                    $.each(plot.seriesArray, function(i, series) {
                        var sdl = series.data.length;
                        if (sdl > 2000) {
                            series.data = condenseData2(series.data);
                        }
                    });
                }
                // $('#info'+phenoIndex).append("<br>"+plot.seriesArray[0].pointsWithinInterval+" "+plot.seriesArray[0].data.length);
                zoom(plot, ranges, gene_names);
            }
        }
    });
}

function setRange(options, x_from, x_to) {
    options.xaxis.min = x_from;
    options.xaxis.max = x_to;
}

function zoom(plot, ranges, gene_names) {
    var x_from = ranges.xaxis.from;
    var x_to = ranges.xaxis.to;
    var axes = plot.flotplot.getAxes();
    var plot_type = plot.plot_type;
    var plotDiv = $("#" + plot.placeHolder);
    var labelsDiv = plot.labelsDiv;
    var chr = plot.chr;
    var phenoIndex = plot.phenoIndex;
    $(".marker_label").remove(); //remove all marker labels since coordinates wont match after zooming
    plot.flotplot.clearSelection();
    plot.flotplot = $.plot(plotDiv, plot.seriesArray, $.extend(true, {}, getSinglePlotOptions(labelsDiv, plot.seriesArray, x_from, x_to), getExtendedOptions(ranges, axes, plot_type, null))); //replace with m.yMin

    if ($("#disableTooltip:checked").length > 0) {
        //displayMarkerNames(plotDiv, plot, ranges, m.markers);
    }
    if (plot) {
        addZoomOutBtn(plot.placeHolder, plot.flotplot, chr);
        addChrLabel(plot);
        //addTraitLoci(plot,ranges);
        //addChrLabel2(plot, ranges);
        //addTraitLoci(plot, ranges);
        //addEvalueDivs(plot.plotDiv, flotplot, plot.seriesArray);
        plot.overviewPlot.setSelection(ranges, true);
    }
    //if (!($("#disableAnnotation:checked").length > 0))

    var noOfMarkers = plot.seriesArray[0].data.length;

    if (getDiff(x_from, x_to)) {
        $("#markerCB").prop("disabled", false);
        if ($('#markerCB').prop('checked')) {
            showMarkerPlot(ranges);
        }
    } else {
        $("#markerCB").prop("disabled", true);
        $("#markers").hide();
    }
    zoomToRangeOnGenePlot(ranges, chr, gene_names);
    //zoomToRangeOnGenePlot2(ranges,chr, gene_names);
}

function checkSeenGenes(gene_names) {
    var notSeen = [];
    $.each(gene_names, function(i, name) {
        if (!(_.contains(genesSeen, name))) {
            notSeen.push(name);
            genesSeen.push(name);
        }
    });
    return notSeen;
}

function zoomToRangeOnGenePlot(ranges, chr, gene_names) {
    //genePlot = $.plot($("#genePlot"), geneMarkings, getGenePlotOptions(0, chrLength));
    var x_from = parseInt(ranges.xaxis.from);
    var x_to = parseInt(ranges.xaxis.to);
    var exons = [];
    if (typeof(gene_names) != "undefined") {
        noGenesOnDisplay = gene_names.length;
    }
    //exon code starts

    if (noGenesOnDisplay < 30) {
        var notSeen = checkSeenGenes(gene_names);
        try {
            //get all the genes for from the specified build and chromosome

            if (notSeen.length > 0) {
                gene_names_str = notSeen.join();
                var script = getExons_cgi + "?chr=" + chr + "&database=" + database + "&genes=" + gene_names_str;
                $.ajax({
                    type: "GET",
                    url: script,
                    data: "format=json&id=123",
                    dataType: 'json',
                    success: function(d) {
                        for (var i = 0; i < d.exons.length; i++) {
                            addExonToMarkings(new Exon(d.exons[i]));
                        }
                        plotExons(ranges, x_from, x_to);
                    },
                    error: function(xhr, textStatus, errorTHrown) {
                        alert('request failed');
                    }
                });
            } else {
                plotExons(ranges, x_from, x_to);
            }
        } catch (err) {
            (console.log("ERROR in function zoomToRangeOnGenePlot " + err));
        }
    } //end of if
    //exon code ends
    else {
        var options = getGenePlotOptions(x_from, x_to, geneMarkings);
        var genePlot = $.plot(("#genePlot"), geneMarkings, options);
        overviewGenePlot.setSelection(ranges, true);
        addStrandLabel(genePlot);
    }
}


function zoomToRangeOnGenePlot2(ranges, chr, gene_names) {
    var x_from = parseInt(ranges.xaxis.from);
    var x_to = parseInt(ranges.xaxis.to);
    var exons = [];
    /*    if(typeof(gene_names) != "undefined"){
    	noGenesOnDisplay=gene_names.length;
        }
        //exon code starts

        //exon code ends
        else{
    */
    var options = getGenePlotOptions2(x_from, x_to, annotMarkings);
    var genePlot = $.plot(("#genePlot2"), annotMarkings, options);
    /*    overviewGenePlot.setSelection(ranges,true);
        addStrandLabel(genePlot);*/
}



function plotExons(ranges, x_from, x_to) {
    var options = getGenePlotOptions(x_from, x_to, exonMarkings);
    var genePlot = $.plot(("#genePlot"), exonMarkings, options);
    overviewGenePlot.setSelection(ranges, true);
    addStrandLabel(genePlot);
}

function addExonsToGeneMarkings(exons, ranges, x_from, x_to) {
    $.each(exons, function(i, exon) {
        var strand = exon.strand.replace(/ /g, "");
        var y_from = -5;
        var y_to = -11;
        var exonColor = "#FF4F00";
        //if(typeof(exon.disease) !== "undefined"){
        //  if( 1 < exon.disease.length){
        //      exonColor="blue";
        //  }
        //}
        if ((strand == "1") || (strand == "+")) {
            y_from = 5;
            y_to = 11;
        }
        exObj = {
            color: exonColor,
            xaxis: {
                from: exon.bpStart,
                to: exon.bpEnd
            },
            yaxis: {
                from: y_from,
                to: y_to
            },
            name: exon.ensId,
            ensId: exon.ensId
        };
        exonMarkings.push(exObj);
    });
    plotExons(ranges, x_from, x_to);
}


function getDiffGene(from, to) {
    if (to - from < 150000)
        return true;
    return false;
}


function getDiff(from, to) {
    if (to - from < 15000000)
        return true;
    return false;
}

/*
  in big zoom-outs, use original data... in lower level zoom outs use chunks.
  testing: 117467996..119801827  117467996..119801827
*/
function getDataWithinInterval(d, from, to) {
    var tmp = [];
    var firstPoint = 1;
    var lastPoint;
    for (var j = 0; j < d.length - 1; j++) {
        var pos = d[j][0];
        if ((pos >= from) && (pos <= to)) {
            if (firstPoint) {
                if (j > 0)
                    tmp.push(d[j - 1]);
                firstPoint = 0;
            }
            tmp.push(d[j]);
            lastPoint = j;
        }
    }
    tmp.push(d[lastPoint + 1]);
    return tmp;
}

function changeDisplay(series, from, to) {
    if (getDiff(from, to)) {
        if (series.plot_type == "point") {
            if (typeof(series.points) !== "undefined") {
                series.points = {
                    radius: 2,
                    fill: false,
                    show: series.points.show,
                    symbol: series.points.symbol
                };
                series.lines = {
                    show: false
                };
            } else {
                series.points = {
                    radius: 2,
                    show: true,
                    fill: false
                };
                series.lines = {
                    show: false
                };
            }
        } else {
            series.points = {
                radius: 2
            };
            series.lines = {
                show: true
            };
        }
    }
}

//handle this within the series object
function resetDisplay(seriesArray) {
    var radius = 1;
    $.each(seriesArray, function(i, series) {
        if (series.plot_type == "point") {
            if (typeof(series.points) !== "undefined") {
                series.points = {
                    show: series.points.show,
                    radius: radius,
                    fillColor: series.color,
                    symbol: series.points.symbol
                };
                series.lines = {
                    show: false
                };
            } else {
                series.points = {
                    show: true,
                    radius: radius,
                    fillColor: series.color,
                    symbol: series.symbol
                };
                series.lines = {
                    show: false
                };
            }
        } else {
            series.lines = {
                show: true
            };
            series.points = {
                show: false
            };
        }
    });
}

function setData(series, x_from, x_to, limit, phenoIndex) {
    series.data = getDataWithinInterval(series.data, x_from, x_to);
    series.pointsWithinInterval = series.data.length;
    if (series.data.length > limit) {
        var cb = "showAllcheckbox" + phenoIndex;
        if (!($("#" + cb + ":checked").length > 0))
            series.data = condenseData2(series.data);
    } else
        changeDisplay(series, x_from, x_to);
    series.pointsOnDisplay = series.data.length;
    return series;
}

function showAll() {
    zoomOnPlots(plots[0], 2, plots[0].ranges);
}

function showMarkers() {
    if ($('#markerCB').prop('checked'))
        showMarkerPlot(plots[0].ranges);
    //zoomOnPlots(plots[pi],2, plots[pi].ranges);
    else
        $('#markers').hide();

}

function showGenotypes() {
    $("#maf0").attr('checked', false);
    $("#annot0").attr('checked', false);
    zoom(plots[0], plots[0].ranges);
}

function showMAFs() {
    $("#genocounts0").attr('checked', false);
    $("#annot0").attr('checked', false);
    zoom(plots[0], plots[0].ranges);
}

function showAnnot() {
    $("#genocounts0").attr('checked', false);
    $("#maf0").attr('checked', false);
    zoom(plots[0], plots[0].ranges);

}


/*
  value: true or false, If "true", the checkbox will be disabled, if "false" it is enabled
  phenoIndex: an integer included in the checkbox identifier
*/
function disableCheckbox(value, phenoIndex) {
    $('#showAllcheckbox' + phenoIndex).attr("disabled", value);
    if (!(value))
        $('#showAll' + phenoIndex).removeClass("graphTxt").addClass("showAllTxt");
    else {
        $('#showAll' + phenoIndex).removeClass("showAllTxt").addClass("graphTxt");
        $('#showAllcheckbox' + phenoIndex).prop('checked', false);
    }
}

function checkJSON(files, from, to) {
    var jsfiles = []; //in case two files are needed
    var done = 0;
    $.each(files, function(i, file) {

        if (!done) {
            var f_from = parseInt(file[1]);
            var f_to = parseInt(file[2]);
            var name = file[0];
            if (f_to >= to) {
                if (f_from <= from) { //only one file spanning the interval
                    jsfiles.push(file[0]);
                    done = 1;
                } else { //multiple files spanning the interval
                    var j = i;
                    while (f_from >= from) {

                        if (files[j]) {
                            jsfiles.push(files[j][0]);
                            j--;
                            if (files[j])
                                f_from = parseInt(files[j][1]);
                            else
                                f_from = 0;
                        }
                    }
                    //add the last file, when f_from < from
                    if (files[j])
                        jsfiles.push(files[j][0]);
                    done = 1;
                }
            }
        }
    });
    return jsfiles;
}
