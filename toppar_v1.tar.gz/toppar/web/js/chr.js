
var chr_names=[];
var chr_lengths=[];
var chr_ends=[]; //acc chromosome ends

/*
  chromosomeMenu is called upon startup to populate the chromosome menu and create placeholders for multiple graph display
*/
function init_chr_menu(build){
  try{
  var script=get_chr_cgi+"?build="+build;
  $.ajax({
    type: "get",
    url: script,
    success: function(jsonFile){
      try{
          $.getJSON(jsonFile, function(d){
            var options = '';
            $.each(d, function(i, c){
                chr_names.push(c[0]);
                chr_lengths.push(c[1]);
                options+='<option >'+c[0]+'</option>';
             })
            $("select#chromosomes").html(options);
            setChrEnds();
          });
        }catch(e){alert("error when reading jsonFile "+e);}
 }
});
}catch(e){ alert("error when reading jsonFile "+e);}
}

function getChrArray(){
  return chr_names;
}

function getChr(index){
  return chr_names[index];
}

function getChrLength(chr){
  return chr_lengths[getChrIndex(chr)];
}

function getAccumulatedChrLength(chr){
    return acc_chr_lengths[chr];
}

function getChrEnd(index){
  return parseInt(chr_ends[index]);
}

function getNoOfChr(){
  return chr_names.length;
}


function getChrIndex(chr){
  var index;
  $.each(chr_names, function(i, name){
	   if(chr == name)
	     index=i;
	 });
  return index;
}

function setChrEnds(){
  chr_ends=[];
  var sum=0;
  $.each(chr_lengths, function(i, chrLength){
	   sum=sum+parseInt(chrLength);
	   chr_ends.push(sum);
	 });
}
