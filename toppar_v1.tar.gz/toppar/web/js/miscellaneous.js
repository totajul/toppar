
$(document).ajaxStart(function () {
        $("#ajaxBusy").show();
}).ajaxStop(function (){
    $("#ajaxBusy").hide();
});


function arrayContains(phenoArray, pheno){
    var itemFound=false;
    for(var i=0; i< phenoArray.length; i++){
	     if(phenoArray[i] === pheno){
	        itemFound=true;
	         break;
	   }
  }
    return itemFound;
}

function todo(){
    alert("TODO! This feature is not yet implemented... ");
}
/*remove any duplicate entries from an array*/
function unique(array){
  return array.filter(function(el, index, arr){
    return index === arr.indexOf(el);
  });
}


function showhide(id){
  var obj;
  if (document.getElementById){
    obj = document.getElementById(id);
    if (obj.style.display == "none")
      obj.style.display = "";
    else
      obj.style.display = "none";
  }
}

function emptyTxtBoxes(){
  $("#snp").val("");
  $("#gene_symbol").val("");
  $("#coord").val("");
  $("#y_max").val("");
}

function goTo(type){
  var orig_name;
  var name;
  var script;
  var name;
  if(type === "snp"){
    orig_name=$("#snp").val();
    script=getSnp_cgi;
    name=orig_name; //toLowerCase();
  }
  else if (type === "gene"){
    orig_name=$("#gene_symbol").val();
    script=getGene_cgi;
    name=orig_name.toUpperCase();
  }

  var currentChr=$("#chromosomes").val();
  if ($("#genome:visible").length > 0 )
      currentChr=0; //in genome view, no chromosome is selected
  script+="?name="+name;
try{
     $.ajax({
        type: "GET",
        url:script,
        success : function(jsonfile){  
          try{
              $.getJSON(jsonfile, function(response){
                  var from; var to; var chr;
                  if(response[0] === "NOT_FOUND")
                      alert("Could NOT find a "+type+" with name: "+orig_name);
                  else{
                        if(type === "snp"){
                          var name=response[0][0];
                          chr=response[0][1]; //.replace(/ /g,"");
                          var bp_pos=response[0][2]; //.replace(/ /g, "");
                          from=parseInt(bp_pos)-100000;
                          to=parseInt(bp_pos)+100000;
                        }
                        else{
                            var values=response[0][0].split("-");
                            to=parseInt(values[1])+50000;
                            var tmp=values[0].split(":");
                            from=parseInt(tmp[1])-50000;;
                            chr=tmp[0].replace("chr","");

                            //from=parseInt(bp_pos)-1000;
                          //to=parseInt(response[0][3])+1000;
                        }
                      if(chr == currentChr){
                          if(type === "snp")
                              zoomToRange({ xaxis : {from : from, to: to}, yaxis: {}}, plots[0], bp_pos, find_and_select_datapoint);
                          else
                              zoomToRange({ xaxis : {from : from, to: to}, yaxis: {}});
                      }
                      else{
                        $("#chromosomes").val(chr);
                        geneExonMarkings=[];
                        genesSeen=[];
                        if(type === "snp"){
                             getRegion(chr, from, to, bp_pos, find_and_select_datapoint);
                           }
                        else {
                             getRegion(chr, from, to);
                        }

                      }
                    //  if(type === "snp")
                        //    find_and_select_datapoint(chr, bp_pos);
                      //find the datapoint in the series
                  }
              }
            );
          }
          catch(e){
                alert("error when reading json "+jsonfile+" "+e);
          }
       }
     });
}
catch(e){
      alert("AJAX error when running:  "+script+" "+e);
}
}


function find_and_select_datapoint(chr, bp_pos){
  var plot=plots[0];
  $.each(plot.seriesArray, function(i, series){
      $.each(series.data, function(j, data){
        if(bp_pos === parseInt(data[0])) {
          //match found
          var probe_id=data[2];
          var inhouse_id=data[3];
          make_series_for_selected_point(series, data, plot, probe_id, inhouse_id);
          var flotplot=plot.flotplot;
          var plotDiv=$("#"+plot.placeHolder);
          var graphx=plotDiv.offset().left+30;
          var graphy=plotDiv.offset().top+10;
          var x_can=flotplot.getAxes().xaxis.p2c(data[0]);
          var y_can=flotplot.getAxes().yaxis.p2c(data[1]);
          showTooltip_snp_id("selected_snp", parseFloat(graphx)+parseFloat(x_can), parseFloat(y_can)+parseFloat(graphy), probe_id);
          sel_item_coord={"probeId": probe_id, "x": data[0], "y": data[1]};
          return false;
        }
    });
  });

}
/*
		  if(response != ""){
		      var row=response.split(",");
		      var name=row[0];
		      var chr=row[1].replace(/ /g,"");
		      var bp_pos=row[2].replace(/ /g, "");
		      var from; var to;
		      if(type == "snp"){
			  from=parseInt(bp_pos)-500;
			  to=parseInt(bp_pos)+500;
		      }
		      else{
			  from=parseInt(bp_pos)-1000;
			  to=parseInt(row[3].replace(/ /g,""))+1000;
		      }
		      if(chr == currentChr){
			  zoomToRange({ xaxis : {from : from, to: to}, yaxis: {}});
		      }
		      else{
			  $("#chromosomes").val(chr);
			  geneExonMarkings=[];
			  genesSeen=[];
			  getRegion(chr, from, to);
		      }
		  }
		  else
		      alert(orig_name +" not found");
	      }
	  });
  }
  catch(e){
      alert("error when running "+script+" "+e);
  }
  */


function goToCoord(){
  var coord=$("#coord").val();
  coord=coord.replace(/ /g,""); //remove all white spaces
  coord=coord.replace(/,/g, ""); //remove all commas
  var from;
  if(/\:/.test(coord)){//if the coordinates contain chromsomsome
      //var val_with_chr=coord.split(":");
      //chr=val_with_chr[0];
      //$("#chromosomes").val(chr);
      //chr.replace(/chr/,'');
      //coord=val_with_chr[1];
      alert("goto coordinates is not availalbe in GENOME VIEW at the moment")
  }
  else{
  var values=[];
  values=coord.split("-");
  var to=0;
  if(values.length == 2){
    from=getValueInCorrectFormat(values[0]);
    to=getValueInCorrectFormat(values[1]);
  }
  else
      to=getValueInCorrectFormat(values[0]);
  if(!from)
      alert("incorrect format!");
  if(parseInt(to) > parseInt(from)){
    //  if(!(plot)){
    //    getPlotData(0, chr, ranges.xaxis.from.toFixed(0),ranges.xaxis.toFixed(0), zoomToRange);
    //  }
    //  else{
        zoomToRange({ xaxis : {from : parseInt(from), to: parseInt(to)}, yaxis: {}});
    //  }
    }
    else if (parseInt(to) < parseInt(from)) {

    }
  }
}

function getValueInCorrectFormat(val){
  var tmpVal=val.split(".");
  if(tmpVal.length==2){
    tmpVal[0]+=addZeros(tmpVal[1]);
    return tmpVal[0];
  }
  return val; //use value as it is
}

function addZeros(tail){
  while(tail.length < 6){
    tail+="0";
  }
  return tail;
}
