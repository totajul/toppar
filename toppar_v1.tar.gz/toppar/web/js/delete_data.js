var pop_data;

$(document).ready(
    function() {
        var browserName = navigator.appName;
        if (browserName == "Microsoft Internet Explorer")
            alert("The Genome Scan Viewer does NOT work in Interet Explorer!! Please use  Chrome, Firefox or Safari instead!");
        else {
            initGenomeBuildMenu();
        }
    });

$(document).ajaxStart(function() {
    $("#ajaxBusy").show();
}).ajaxStop(function() {
    $("#ajaxBusy").hide();
});
//INITIATE MENUS and Menu functions
$(function() {
    $("select#build").change(function() {
        initPopulationMenu();
    });
});
$(function() {
    $("select#population").change(function() {
        initFilterMenus(pop_data);
      //  populateMenusOnChange();
    });
});

function ConfirmDelete()
   {
     var phenotype = $("select#phenotype option:selected").map(function() {
         return $(this).text();
     }).get();
     var labels = $("select#label option:selected").map(function() {
         return $(this).text();
     }).get();
     var confirm_msg="Are you sure you want to delete?";
     var user=document.getElementById("user").value;
     var pwd=document.getElementById("password").value;

  //  if(!isEmpty(user)  && !isEmpty(pwd)){
     if (labels == "") {
        alert("Please select at one or more labels to delete!");
        return false;
         //No labels have been selected,
        // if(phenotype == ""){
           //alert("Nothing has been selected for deletion! Select either phenotype or label/s to delete.");
           //return false;
        //  }
      //   else{
      //       confirm_msg="Are you sure you want to delete all data under the ["+phenotype+"] phenotype?";
      //   }
     }
     var x = confirm(confirm_msg);
     if (x){

          delete_data(phenotype, labels, user,pwd);
          return true;
       }
     else{
       alert("Action was cancelled! Nothing was deleted");
        return false;
     }
   //}
   //else{
    // alert("User name and Password to the toppar_db database is required!")
   //}
   }

   function isEmpty(str){
     return(!str || 0 === str.length);
   }

function delete_data(phenotype, labels, user, pwd){
    var build = $("#build").val();
    var pop = $("#population").val();
    console.log("LABELS"+labels);
    console.log(labels);
    var script=delete_data_cgi+"?pop="+pop+"&pwd="+pwd+"&user="+user+"&build="+build+"&pheno="+phenotype+"&labels="+labels;
      try{
          $.ajax({
              type: "GET",
              dataType: "text",
              url: script,
              success: function(data){
                  alert("Data was succesfully deleted.");
                  initPopulationMenu(pop_data);
              }
          });
      }
      catch(e){
        alert("Error when calling ajax "+e)
      }

}
