
function Series(typeIndex, symbol, radius, impact, phenotype, model){
  this.data=[];
  this.phenotype=phenotype;
  this.origData=[];
  this.chunks={};
  this.impact=impact;
  this.typeIndex=typeIndex;
  this.color=colors[typeIndex];
  this.pointsOnDisplay;
  this.gwasCatalog=false;
  this.ldSeries=false;
  this.terms=" ";
  if(typeof(symbol) === undefined)
     symbol="circle";
  this.points={show: true, radius : 1, fillColor: this.color, symbol: symbol};
  this.lines={show:false};
  this.leadSeries=false;
  this.origColor=colors[typeIndex];
  this.selected=false;

  this.model=model;
  this.maxScore;
  this.yaxis=1; //plot using the left hand side y-axis, for recombination plot series, use yaxis=2
  //the below are only for GWAS cat SNPs
  //this.pid;
//  this.author;
//  this.journal;
//  this.pub_date;
}


Series.prototype.addGwasData=function(json){
    var maxScore=0;
    $.each(json.data, function(i, dp){
       if(parseFloat(dp[1]) > parseFloat(maxScore))
         maxScore=dp[1];
    });
    if(parseFloat(maxScore) > 275)
      this.maxScore=275
    else
       this.maxScore=maxScore;
    this.origData=json.data;
    this.data=json.data;
    this.label="GWAS catalog: ("+json.data.length+")";
    this.gwasCatalog=true;
    this.plot_type="point";
    this.unit="log10";
    this.phenotype="GWAS catalog";
}

Series.prototype.set_as_selected=function(data){
  this.color="#8B0000"; // "#800080";
  this.selected=true;
  this.data=data;
  this.origData=data;
}

Series.prototype.setGwasCatalog=function(val){
    this.gwasCatalog=val;
}
//The lead series contains the label and other values that apply to all the series in the group (leader and non-leader Series)

Series.prototype.mkLeadSeries=function(maxScore, labelCounts){
    this.leadSeries=true;
    this.label=this.phenotype+" "+labelCounts;
    this.maxScore=maxScore;
}
Series.prototype.addGeneTypeLabel=function(label){
    this.leadSeries=true;
    this.label=label;
}

Series.prototype.mkLDSeries=function(r2, label){
    this.leadSeries=true;
    var from=r2-0.2;
    this.label="&nbsp"+from.toFixed(1)+" &lt; r2 &le; "+r2.toFixed(1)+" "+label;
    if(r2 > 0.8)
        this.color="red";
    else if(r2 > 0.6)
        this.color="orange";
    else if(r2 >  0.4)
        this.color="#33cc33"; //bright green
    else if(r2 > 0.2)
	      this.color="#00b8e6"; //blue
    else
       this.color="#001a33";  //"#63636D";
}

Series.prototype.addGwasCatData=function(data, color,terms, gwasSeries){
    this.data=data;
    this.origData=data;
    this.terms=terms;
    this.label="GWAS catalog : "+terms+"("+this.data.length+")";
    this.color=color;
    this.gwasCatalog=true;
    this.points={show: true, radius : 1, fillColor:color};
    this.lines={show:false};
    this.plot_type=gwasSeries.plot_type;
    this.unit=gwasSeries.unit;
    this.thresh=gwasSeries.thresh;
    this.evalue=gwasSeries.evalue;
    this.file=undefined;
    this.trait_loci=undefined;
    this.phenotype="GWAS catalog";
}

Series.prototype.setData=function(data){
  this.data=data;
}
  Series.prototype.setColor=function(color){
    this.color=color;
  }

Series.prototype.addToData=function(dataChunk){
    this.data=this.data.concat(data);
    this.data.sort();
}
