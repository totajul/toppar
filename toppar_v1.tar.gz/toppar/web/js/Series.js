function Plot(phenoIndex, chr, condensed, from, to, phenoType) {
    this.phenoIndex = phenoIndex;

    this.phenoType = phenoType;
    this.seriesArray = [];
    this.markersArray = [];
    this.chr = chr;
    this.from = from;
    this.to = to;
    this.condensed = condensed;
    this.ranges;
    this.placeHolder;
    this.overviewPlaceHolder;
    this.markersPlaceHolder;
    this.flotplot;
    this.overviewPlot;
    this.markerPlot;
    this.labelsDiv;
    this.noData = []; //an array to store the scan_types that have no data
}

Plot.prototype.setRanges = function(ranges) {
    this.ranges = ranges;
}
Plot.prototype.getSeries = function() {
    return this.seriesArray;
}
Plot.prototype.addSeries = function(series) {
    this.seriesArray.push(series);
}

Plot.prototype.addSeriesArray=function(sa){
    for(var i=0; i< sa.length; i++){
	this.addSeries(sa[i]);
    }
}


Plot.prototype.rmGwasSeries = function() {
    var seriesArrayTmp = [];
    var seriesArrayTmp = Array.from(this.seriesArray);
    $.each(this.seriesArray, function(i, series) {
        if (typeof(series) != "undefined") {
            if (series.gwasCatalog) {
                var noGwasElements = (seriesArrayTmp.length) - i;
                seriesArrayTmp.splice(i, noGwasElements);
            }
        }
    });
    this.seriesArray = Array.from(seriesArrayTmp);
}
Plot.prototype.rmSeries = function() {
    this.seriesArray.pop();
}
Plot.prototype.addNoData = function(phenotype) {
    this.noData.push(phenotype);
}
Plot.prototype.addMarkers = function(markers) {
    this.seriesArray = markers;
}

function Markers(typeIndex) {
    this.data = [];
    this.typeIndex = typeIndex;
    this.color = "#FF0000";
    this.plot_type = "point";
}

Markers.prototype.addJsonData = function(json) {
    this.data = json.data;
}

function Series(typeIndex, symbol, impact) {
    this.data = [];
    this.origData = [];
    this.chunks = {};
    this.impact = impact;
    this.typeIndex = typeIndex;
    this.color = colors[typeIndex];
    this.file = undefined;
    this.plot_type = "point"; ///fix and inherit from leader
    this.json = [];
    this.pointsOnDisplay;
    this.pointsWithinInterval;
    this.origDataWithinInterval;
    this.fullData;
    this.gwasCatalog = false;
    this.terms = " ";
    this.maxScore;
    if (typeof(symbol) === undefined)
        symbol = "circle";
    this.points = {
        show: true,
        radius: 1,
        fillColor: this.color,
        symbol: symbol
    };
    this.lines = {
        show: false
    };
    this.role = "follow";

}
Series.prototype.setMaxScore=function(maxScore){
  this.maxScore=maxScore;
}

Series.prototype.setSymbol = function(symbol) {
    this.points.symbol = symbol;
}
Series.prototype.setRadius = function(radius) {
    this.points.radius = radius;
}
Series.prototype.addGwasData = function(json) {
    this.maxScore = json.maxScore;
    this.origData = json.data;
    this.data = json.data;
    this.plot_type = json.plot_type;
    this.unit = json.unit;
    this.label = json.label+": ("+json.data.length+")";
    this.gwasCatalog=true;
    console.log(this.gwasCatalog);
}
//Series.prototype.setGwasCatalog = function(val, first) {
//       this.gwasCatalog = val;
//  }
    //The lead series contains the label and other values that apply to all the series in the group (the leader and its followers)

Series.prototype.mkLeadSeries = function(json, labelCounts) {
    this.role = "lead";
    this.file = json.file;
    this.label = json.label + " " + labelCounts;
    this.maxScore = json.maxScore;
    this.plot_type = json.plot_type;
    this.unit = json.unit;
    this.thresh = json.thresh;
    this.evalue = json.evalue;
}
Series.prototype.setNoOfPoints = function(points) {
    this.noOfPoints = points;
}
Series.prototype.addGwasCatData = function(data, color, terms, gwasSeries) {
    this.data = data;
    this.origData = data;
    this.terms = terms;
    this.label = "GWAS catalog : " + terms + "(" + this.data.length + ")";
    this.color = color;
    this.gwasCatalog = true;
    this.points = {
        show: true,
        radius: 1,
        fillColor: color
    };
    this.lines = {
        show: false
    };
    this.maxScore = gwasSeries.maxScore;
    this.plot_type = gwasSeries.plot_type;
    this.unit = gwasSeries.unit;
    this.thresh = gwasSeries.thresh;
    this.evalue = gwasSeries.evalue;
    this.file = undefined;
    this.trait_loci = undefined;
}
Series.prototype.setIntervalPoints = function(points) {
    this.pointsWithinInterval = points;
}
Series.prototype.getIntervalPoints = function() {
    return this.pointsWithinInterval;
}
Series.prototype.getPercentage = function() {
    var result = ((this.pointsOnDisplay / this.pointsWithinInterval) * 100).toFixed(2);
    return result;
}
Series.prototype.setData = function(data) {
    this.data = data;
}
Series.prototype.setColor = function(color) {
    this.color = color;
}
Series.prototype.getChunk = function(jsonFile) {
    if (this.chunks[jsonFile])
        return this.chunks[jsonFile];
    else
        return "null";
}
Series.prototype.addToData = function(dataChunk) {
    this.data = this.data.concat(data);
    this.data.sort();
}
Series.prototype.addChunk = function(file, data) {
    this.chunks[file] = new Chunk(file, data);

    //	this.chunks.push(new Chunk(file, data));
    // this.data=this.data.concat(data);
    //this.data.sort();
}

function Chunk(jsonFile, data) {
    this.data = data;
    this.jsonFile = jsonFile;
}
