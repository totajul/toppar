function show_lists(){
   var obj;
   if(document.getElementById){
      var rows=[];
      obj=document.getElementById('results_lists');
      //$("#results_lists").show();
      $("#lookup_table_div").show();
      //$("#lookup_table_checkb").show();
      //$("#clearBtn").show();
      $("#lookup_table_text").hide();
      var searchTerms=document.getElementById('find_lists').value;

      var valTrimmed=searchTerms.trim();
      
      var re=new  RegExp(valTrimmed, 'i');

      $.each(all_labels_info, function(i, info){
                    if(info[0].match(re)){
                        var tmp=info;
                        rows.push(tmp);
                    }
        });
        displayRowsInTable(rows);
   }
}

function clear_results_list(){
  $("#lookup_table_text").show();
  var table_div = $("#lookup_table_div");
  table_div.empty();
  //annot.empty();
//  results_lists_div.empty();
  $("#clearBtn").hide();
}

function displayRowsInTable(rows){
  var table_div = $("#lookup_table_div");
  table_div.empty();
  var table_id="lookup_table";
  var html = "<br><table id=\""+table_id+"\"><thead><th>Genome build</th><th>Population/study</th><th>Label</th></thead><tbody>";
  var count=0;
  $.each(rows, function(i, row){
           html+="<tr><td>"+row[1]+"</td><td>"+row[2]+"</td><td><input name=\""+row[0]+"\" class=\"list_cb\" type=\"checkbox\" value=\""+row[0]+"\">&nbsp"+row[0]+"</td></tr>";
   });
   html+="</tbody></table>";
   table_div.append(html);
   mk_DataTable(table_id);
}
