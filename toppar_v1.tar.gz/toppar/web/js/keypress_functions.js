
//keypress functions
$(function(){
     $('#gene_symbol').keypress(function(e) {
	    if (e.which == 13){ //if enter was pressed
	        goTo("gene");
		      $("#snp").val("");
		      $("#coord").val("");
	    }
	});
    $('#snp').keypress(function(e) {
	    if (e.which == 13){ //if enter was pressed
          goTo("snp");
		      $("#coord").val("");
		      $("#gene_symbol").val("");
	    }
	});
    $('#coord').keypress(function(e) {
	    if (e.which == 13){  //if enter was pressed
		      goToCoord();
	 	       $("#snp").val("");
	 	        $("#gene_symbol").val("");
	    }
	});
    $('#gwasTerm').keypress(function(e) {
	    if (e.which == 13){  //if enter was pressed
		alert("gwasTerm pressed");

	    }
	});
   $('#y_max').keypress(function(e){
      if(e.which==13){
		        reset_y_axis();
          }
	});
  $('#find_lists').keypress(function(e){
     if(e.which==13){
           show_lists();
         }
 });
});
