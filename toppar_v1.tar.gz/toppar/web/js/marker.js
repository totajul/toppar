function showMarkerPlot(ranges, markerDiv) {
    $("#markers").show();
    $("#spacefiller").show();
    var markerPlotDiv = $("#markerPlot");
    var labelsDiv = $("#marker_labels");
    var test = [];
    var markersArray = markerPlot.getSeries();

    try {
        markerPlot.flotplot = $.plot(markerPlotDiv, markersArray, getMarkerPlotOptions(labelsDiv, ranges.xaxis.from.toFixed(0), ranges.xaxis.to.toFixed(0), annot_cats.length + 1)); //, getComments(plot.markersArray, ranges)));
    } catch (e) {
        alert("ERROR when creating markerPlot " + e);
    }
    try {
        //	$.plot(maxrkerPlotDiv, markersArray.MAF, getMarkerPlotOptions(labelsDiv,ranges.xaxis.from.toFixed(0), ranges.xaxis.to.toFixed(0), annot_cats.length+1 )); //, getComments(plot.markersArray, ranges)));
    } catch (e) {
        alert("ERROR when creating markerPlot " + e);
    }
    bindMarkerPlotHover(markerPlotDiv, markersArray);
    bindMarkerPlotClick(markerPlotDiv, markersArray);
}

function change_marker_score(val) {
    if (currentScore != val) {
        currentScore = val;
        var markersArray = markerPlot.getSeries();
        $.each(markersArray, function(i, mo) {
            var test = 0;
            $.each(mo.data, function(j, dataEntry) {
                if (typeof(dataEntry[6]) == "undefined") {
                    dataEntry[1] = 0;
                } else {
                    dataEntry[1] = dataEntry[6][val];
                }
            });
        });
        showMarkerPlot(plots[0].ranges);
    }
}
