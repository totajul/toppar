/*annotation obtained from */
var genes;
var overviewGenePlot;

function addGenesPlot(plot, from, to) {
    $("#genes").empty();
    $("#genes").append(setGenePlotDiv());
    $('#noOfGenes').addClass('graphTxt');
    $('#genePlot').addClass('genePlot');
    $('#overviewGenePlot').addClass('overviewPlot');
    //add2ndGenePlot(plot,from,to);
    getGenes(plot, from, to);
}

function add2ndGenePlot(plot, from, to) {
    $("#genes2").empty();
    $("#genes2").append(setGenePlotDiv2());
    $('#genePlot2').addClass('genePlot2');
}

function setGenePlotDiv() {
    var html = '<hr><table><tr><td><div id="geneTxt" class="verticalTxt">Genes</div></td>';
    html += '<td><div id="genePlot"></div></td><td valign="top"><table><tr><td><div id="overviewGenePlot"></div> </td></tr><tr><td><div class="labelTxt" id="noOfGenes"></div></td></tr></table></td></table>';
    return html;
}



function changeAnnot(val) {
    $.each(annotMarkingsArray, function(i, obj) {
        if (obj.name == val) {
            annotMarkings = obj.markings;
            annotMax = obj.max;
            //addConsGenePlot2(plots[0]);
            return false; //break out of loop
        }
    });
}



function getGenes(plot, from, to) {
    var build = $("#build").val();
    var chr = plot.chr;
    genes = [];
    var geneNames = [];
    try {
        //get all the genes for from the specified build and chromosome
        var script = geneAnnot_cgi + "?chr=" + chr + "&build=" + build;
        console.log(script);
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonfile) {
                try {
                    $.getJSON(jsonfile, function(d) {
                        var gene;
                        for (var i = 0; i < d.data.length; i++) {
                            genes.push(new Gene(d.data[i]));
                            if (i == d.data.length - 1) {
                                addGenePlot(plot, from, to);
                                $('#noOfGenes').empty();
                                $('#noOfGenes').append("chr" + chr + ": " + genes.length + " genes");

                            }
                        }
                    });
                } catch (e) {
                    alert("error when reading jsonFile " + e);
                }
            }
        });
    } catch (err) {
        ("ERROR " + err);
    }
}

function addConsGenePlot(plot, from, to) {
    $("#genes2").show();
    var chr = plot.chr;
    var axes = plot.flotplot.getAxes();
    var from = axes.xaxis.min;
    var to = axes.xaxis.max;
    var genePlotDiv = $("#genePlot2");
    annotMarkings = getConsMarkings(genes, getChrEnd(chr));
    try {
        var genePlot = $.plot(genePlotDiv, annotMarkings, getGenePlotOptions2(from, to, annotMarkings));
    } catch (e) {
        alert("ERROR when creating genePlot " + e);
    }
    //bindGenePlotHover2(annotMarkings);
    //bindGenePlotClick2();
    genePlotDiv.bind("plotselected", function(event, ranges) {
        zoomToRange(ranges);
    });
    $("#overviewGenePlot").bind("plotselected", function(event, ranges) {
        genePlot.setSelection(ranges);
    });
}

function addConsGenePlot2(plot, from, to) {
    $("#genes2").show();
    var chr = plot.chr;
    var axes = plot.flotplot.getAxes();
    var from = axes.xaxis.min;
    var to = axes.xaxis.max;
    var genePlotDiv = $("#genePlot2");
    try {
        var genePlot = $.plot(genePlotDiv, annotMarkings, getGenePlotOptions2(from, to, annotMarkings));
        /*	overviewGenePlot=$.plot($("#overviewGenePlot"), geneMarkings, getGenePlotOverviewOptions(0, chrLength ,geneMarkings));
        	addStrandLabel(genePlot);  */
    } catch (e) {
        alert("ERROR when creating genePlot " + e);
    }
    bindGenePlotHover2(annotMarkings);
    bindGenePlotClick2();
    genePlotDiv.bind("plotselected", function(event, ranges) {
        zoomToRange(ranges);
    });
    $("#overviewGenePlot").bind("plotselected", function(event, ranges) {
        genePlot.setSelection(ranges);
    });
    //   if(from){
    //	zoomToRange({ xaxis : {from : from, to: to}, yaxis: {}});
    //   }
}


function addGenePlot(plot, from, to) {
    $("#genes").show();
    $("#overviewGenePlot").show();
    var chr = plot.chr;
    var axes = plot.flotplot.getAxes();
    var chrLength = axes.xaxis.max;
    var genePlotDiv = $("#genePlot");
    var geneMarkings = getGeneMarkings(genes, getChrEnd(chr));
    try {
        var genePlot = $.plot(genePlotDiv, geneMarkings, getGenePlotOptions(0, chrLength, geneMarkings));
        overviewGenePlot = $.plot($("#overviewGenePlot"), geneMarkings, getGenePlotOverviewOptions(0, chrLength, geneMarkings));
        addStrandLabel(genePlot);
    } catch (e) {
        alert("ERROR when creating genePlot " + e);
    }
    bindGenePlotHover();
    bindGenePlotClick();
    genePlotDiv.bind("plotselected", function(event, ranges) {
        zoomToRange(ranges);
    });
    $("#overviewGenePlot").bind("plotselected", function(event, ranges) {
        genePlot.setSelection(ranges);
    });
    if (from) {
        zoomToRange({
            xaxis: {
                from: from,
                to: to
            },
            yaxis: {}
        });
    }
}

function addStrandLabel(genePlot) {
    var o = genePlot.getPlotOffset();
    $("#genePlot").append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + (o.top) + 'px;color:#666;font-size:smaller">+1</div>');
    $("#genePlot").append('<div style="position:absolute;left:' + (o.left + 4) + 'px; bottom:' + (o.bottom) + 'px;color:#666;font-size:smaller">-1</div>');
}


function getGeneMarkings(genes, chrLength) {
    geneMarkings = [];
    exonMarkings = [];
    exprMarkings = [];
    consMarkings = [];
    overUnderMarkings = [];
    var gene;
    var lastToOnPlusStrand = 0;
    var lastToOnMinusStrand = 0;
    var y_from_plus = 6;
    var y_to_plus = 10;
    var y_from_minus = -10;
    var y_to_minus = -6;

    for (var i = 0; i < genes.length; i++) {
        gene = genes[i];
        var strand = gene.strand.replace(/ /g, "");
        var geneColor = "#FF9900";
        if (typeof(gene.disease) !== "undefined") {
            if (1 < gene.disease.length) {
		geneColor="#CD5C5C";
//#CD5C5C"; //#FF00FF";
		if( /\(k\)/.test(gene.disease)){ //is the association knowledge based?
		    geneColor="red";
		}
            }
        }
        if ((strand == "1") || (strand == "+")) {
            if (gene.bpStart < lastToOnPlusStrand) {
                y_from_plus = 12;
                y_to_plus = 16;
            } else {
                y_from_plus = 6;
                y_to_plus = 10;
            }
            geneMarkings.push({
                color: geneColor,
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: y_from_plus,
                    to: y_to_plus
                },
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            exonMarkings.push({
                color: '#000000',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: 7.5,
                    to: 8.5
                },
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            lastToOnPlusStrand = gene.bpEnd;
        } else {
            if (gene.bpStart < lastToOnMinusStrand) {
                y_from_minus = -16;
                y_to_minus = -12;
            } else {
                y_from_minus = -10;
                y_to_minus = -6;
            }
            geneMarkings.push({
                color: geneColor,
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: y_from_minus,
                    to: y_to_minus
                },
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            exonMarkings.push({
                color: '#000000',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: -8.5,
                    to: -7.5
                },
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            lastToOnMinusStrand = gene.bpEnd;
        }

    }
    exonMarkings.push({
        aboveData: true,
        color: '#646060',
        xaxis: {
            from: 0,
            to: chrLength
        },
        yaxis: {
            from: 0,
            to: 0
        }
    });
    geneMarkings.push({
        aboveData: true,
        color: '#646060',
        xaxis: {
            from: 0,
            to: chrLength
        },
        yaxis: {
            from: 0,
            to: 0
        }
    });
    return geneMarkings;
}

function getConsMarkings(genes, chrLength) {
    consMarkings = [];
    overUnderMarkings = [];
    exprMarkings = [];
    annotMarkings = [];
    var gene;
    var consMax = 0;
    var exprMax = 0;
    var overUnderMax = 120;

    for (var i = 0; i < genes.length; i++) {
        gene = genes[i];
        if (gene.lof_syn) {
            consMarkings.push({
                color: '#FF9900',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: gene.lof_syn,
                    to: (parseFloat(gene.lof_syn) + parseFloat(4))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(gene.lof_syn) > consMax) {
                consMax = parseFloat(gene.lof_syn);
            }
        }
        if (gene.evolTol) {
            consMarkings.push({
                color: '#D358F7',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: gene.evolTol,
                    to: (parseFloat(gene.evolTol) + parseFloat(4))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(gene.evolTol) > consMax) {
                consMax = parseFloat(gene.evolTol);
            }
        }
        if (gene.RVIS) {
            consMarkings.push({
                color: '#00FF00',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: gene.RVIS,
                    to: (parseFloat(gene.RVIS) + parseFloat(4))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(gene.RVIS) > consMax) {
                consMax = parseFloat(gene.RVIS);
            }
        }


        if (gene.expression) {
            var val = parseFloat(gene.expression);
            exprMarkings.push({
                color: '#15e1a5',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: val,
                    to: (val + parseFloat(600))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(val) > exprMax) {
                exprMax = val;
            }
        }

        if (gene.GSE30119) {
            var val = parseFloat(gene.GSE30119);
            exprMarkings.push({
                color: '#008ee0',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: val,
                    to: (val + parseFloat(600))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(val) > exprMax) {
                exprMax = val;
            }

        }
        if (gene.GSE50782) {
            var val = parseFloat(gene.GSE50782);
            exprMarkings.push({
                color: '#365998',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: val,
                    to: (val + parseFloat(600))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(val) > exprMax) {
                exprMax = val;
            }

        }
        if (gene.fpkm_RNAseq_mean_expr4kidney) {
            var val = parseFloat(gene.fpkm_RNAseq_mean_expr4kidney);
            exprMarkings.push({
                color: '#00dfff',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: val,
                    to: (val + parseFloat(600))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(val) > exprMax) {
                exprMax = val;
            }

        }
        if (gene.stuart_kim_cortex) {
            var val = parseFloat(gene.stuart_kim_cortex);
            exprMarkings.push({
                color: '#17ab39',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: val,
                    to: (val + parseFloat(600))
                },
                name: gene.name,
                ensId: gene.ensId
            });
            if (parseFloat(val) > exprMax) {
                exprMax = val;
            }

        }

        if (gene.over_exp_glomeruli) {
            if (gene.over_exp_glomeruli == "1") {
                overUnderMarkings.push({
                    color: '#990000',
                    xaxis: {
                        from: gene.bpStart,
                        to: gene.bpEnd
                    },
                    yaxis: {
                        from: 100,
                        to: 110
                    },
                    name: gene.name,
                    ensId: gene.ensId
                });
            }
        }
        if (gene.under_exp_glomeruli) {
            if (gene.under_exp_glomeruli == "1") {
                overUnderMarkings.push({
                    color: '#ffc0cb',
                    xaxis: {
                        from: gene.bpStart,
                        to: gene.bpEnd
                    },
                    yaxis: {
                        from: 40,
                        to: 50
                    },
                    name: gene.name,
                    ensId: gene.ensId
                });
            }

        }
        if (gene.over_exp_tubuloin) {
            if (gene.over_exp_tubuloin == "1") {
                overUnderMarkings.push({
                    color: '#3b5998',
                    xaxis: {
                        from: gene.bpStart,
                        to: gene.bpEnd
                    },
                    yaxis: {
                        from: 80,
                        to: 90
                    },
                    name: gene.name,
                    ensId: gene.ensId
                });
            }

        }
        if (gene.under_exp_tubuloin) {
            if (gene.under_exp_tubuloin == "1") {
                overUnderMarkings.push({
                    color: '#41c4dc',
                    xaxis: {
                        from: gene.bpStart,
                        to: gene.bpEnd
                    },
                    yaxis: {
                        from: 20,
                        to: 30
                    },
                    name: gene.name,
                    ensId: gene.ensId
                });
            }

        }
    }
    overUnderMarkings.push({
        aboveData: true,
        color: '#646060',
        xaxis: {
            from: 0,
            to: chrLength
        },
        yaxis: {
            from: 60,
            to: 60
        }
    });
    addEntry("cons", consMarkings, consMax);
    addEntry("expr", exprMarkings, exprMax);
    addEntry("glom", overUnderMarkings, overUnderMax);
    annotMarkings = consMarkings;
    annotMax = consMax;
    return annotMarkings;
}


function addEntry(name, markings, max) {
    annotMarkingsArray.push({
        name: name,
        markings: markings,
        max: max
    });
}




function addExonToMarkings(exon) {
    var strand = exon.strand.replace(/ /g, "");
    var y_from = -11;
    var y_to = -5;
    if ((strand == "1") || (strand == "+")) {
        y_from = 5;
        y_to = 11;
    }
    exonMarkings.push({
        color: "red",
        xaxis: {
            from: exon.bpStart,
            to: exon.bpEnd
        },
        yaxis: {
            from: y_from,
            to: y_to
        },
        name: exon.name
    });
}



function getDiseaseHref(diseaseURL, protein_id, disease) {
    var dis_short=disease;
    if(dis_short.length > 40){
	dis_short=disease.substring(0,40);
	dis_short+="...";
    }
    return "<a href=\"" + diseaseURL + "" + protein_id + "\"target=\"_blank\" title=\""+disease+"\">"+dis_short+"</a>";
    //   return "<a href=\"" + diseaseURL + "" + protein_id + "\"target=\"_blank\" \"title\"=\"disease\">" + dis_short + "</a>";
}

function getExpressionHref(expressionURL, protein_id) {
    return "<a href=\"" + expressionURL + "" + protein_id + "\"target=\"_blank\">" + protein_id + "</a>";
}

function getEnsemblHref(ensURL, ensId, id) {
    return "<a href=\"" + ensURL + "" + ensId + "\"target=\"_blank\">" + id + " </a>";
}

function getUCSCHref(ucscURL, chr, to, from) {
    var ucscURL = ucscURL + "" + chr + "%3A" + from + "-" + to;
    return "<a href=\"" + ucscURL + "\"target=\"_blank\">U</a>";
}

function getTairHref(tairURL, name) {
    var tair = tairURL + "" + name.replace("-TAIR-G", "") + "&sub_type=gene";
    return "<a href=\"" + tair + "\"target=\"_blank\" >T</a> ";
}

function getNascHref(nascURL, name) {
    return "<a href=\"" + nascURL + "" + name + "\"target=\"_blank\" >N</a>";
}

function getRgdHref(rgdURL, rgdId) {
    return "<a href=\"" + rgdURL + "" + rgdId + "\"target=\"_blank\" >R</a>";
}

function addAnnotation(from, to, chr) {
    var annot = $("#annotation");
    annot.empty();
    annot.show();
    var build = $("#build").val();
    var strand;
    var gene;
    var gene_names = [];
    annot.append("<hr><h2 class=\"text-primary\" style=\"color:#08519C\">Annotations on  chromosome " + chr + " between " + from + " and " + to + "</h2>");
    annot.append("Links to " + links + " databases are given when available<br>");
    var html = "<br><table border=\"0\" width=\"100%\" cellspacing=\"2\" cellpadding=\"2\" align=\"left\" class=\"table-condensed table-striped\"><tr><td><b>Gene_name</b></td><td><b>Ensembl_ID</b></td><td width=50><b>Info</b></td><td><b>Genomic_interval</b></td><td><b>Description</b></td><td><b>Disease</b></td><td><b>Ensembl_protein_ID</b></td>";

    for (var i = 0; i < genes.length; i++) {
        gene = genes[i];
        var hrefs = "";
        var dis_href = "";
        var expr_href = "";
        if (typeof(gene.disease) !== "undefined") {
            dis_href = getDiseaseHref(disease, gene.ensID_protein, gene.disease);
        }
        if (typeof(gene.ensID_protein) !== "undefined") {
            expr_href = getExpressionHref(expression, gene.ensID_protein);
        }
        if (((gene.bpStart > from) && (gene.bpStart < to)) || ((gene.bpStart < from) && (gene.bpEnd > to)) || ((gene.bpEnd > from) && (gene.bpEnd < to))) {
            gene_names.push(gene.name);
            hrefs += getEnsemblHref(ensembl, gene.ensId, "E");
            hrefs += getUCSCHref(ucsc, chr, gene.bpStart, gene.bpEnd);
            if (gene.strand == "1")
                strand = "+";
            else if (gene.strand == "-1")
                strand = "-";
            else
                strand = gene.strand.replace(/ /g, "");

            html += "<tr><td>" + gene.name + "</td><td>" + getEnsemblHref(ensembl, gene.ensId, gene.ensId) + "</td><td>[" + hrefs + "]</td><td>chr" + gene.chr + "(" + strand + "):" + gene.bpStart + "-" + gene.bpEnd + "</td><td>" + gene.desc + "</td><td>" + dis_href + "</td><td>" + expr_href + "</td></tr>";
        }
        if ((gene.bpStart > to) || (i == genes.length - 1)) {
            i = genes.lenght;
            html += "</table>";
            annot.append(html);
        }
    }
    return gene_names;
}
