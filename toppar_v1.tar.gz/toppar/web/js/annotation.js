/*annotation obtained from */
var genes;
var genes_current; //genes currently on display
var overviewGenePlot;
var tads;


function addGenesPlot(plot, from, to) {
    $("#genes").empty();
    $("#genes").append(setGenePlotDiv());
    $('#noOfGenes').addClass('graphTxt');
    $('#genePlot').addClass('genePlot');
    $('#overviewGenePlot').addClass('overviewPlot');
    getGenes(plot, from, to);
}
function addGenesGenomePlot() {
    $("#genesGenome").empty();
    $("#genesGenome").append(setGenesGenomePlotDiv());
    $('#noOfGenesGenome').addClass('graphTxt');
    $('#geneGenomePlot').addClass('genesGenomePlot');
    getGenesGenome();
}

function addTADs(plot, from, to) {
    $("#TADs").empty();
    $("#TADs").append(setTADsDiv());
    $('#TADPlot').addClass('TADPlot');
    getTADs(plot, from, to);
}

function setGenesGenomePlotDiv() {
    var html = '<table><tr><td><div id="geneTxt" class="verticalTxt">Genes</div></td>';
    html += '<td><div class="genesGenomePlot" id="genesGenomePlot"></div></td><td valign="top"><table><tr></tr><tr><td><div id="noOfGenesGenome"></div></td></tr></table></td></table>';
    return html;
}

function setGenePlotDiv() {
    var html = '<table><tr><td><div id="geneTxt" class="verticalTxt">Genes</div></td>';
    html += '<td><div id="genePlot"></div></td><td valign="top"><table><tr><td><div id="overviewGenePlot"></div> </td></tr><tr><td><div id="noOfGenes"></div></td></tr></table></td></table>';
    return html;
}

function setTADsDiv() {
    var html = '<hr><table><tr><td><div id="geneTxt" class="verticalTxt">TADs</div></td>';
    html += '<td><div id="TADPlot"></div></td><td valign="top"><table><tr><td><div id="overviewTADPlot"></div> </td></tr><tr><td><div id="noOfGenes"></div></td></tr></table></td></table>';
    return html;
}

function changeAnnot(val) {
    $.each(annotMarkingsArray, function(i, obj) {
        if (obj.name == val) {
            annotMarkings = obj.markings;
            annotMax = obj.max;
            //addConsGenePlot2(plots[0]);
            return false; //break out of loop
        }
    });
}

function getGenes(plot, from, to) {

    var build = $("#build").val();
    chr = plot.chr;
    genes = [];
    //get all the genes for the specified build and chromosome
        var script = get_gene_annot + "?chr=" + chr + "&build=" + build;
          try {
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonfile) {
                try {
                    $.getJSON(jsonfile, function(d) {
                        for (var i = 0; i < d.data.length; i++) {
                              genes.push(new Gene(d.data[i], chr));
                            if (i == d.data.length - 1) {
                                addGenePlot(plot, from, to);
                                var no_genes=parseInt(genes.length) - 1;
                                $('#noOfGenes').empty();
                                $('#noOfGenes').append("chr" + chr + ": " + no_genes + " genes");
                                $("#genes_annotation_region").show();
                                setGenesWithinInterval(from, to, plot.chr, mk_genes_DataTable);
                            }
                        }

                    });
                } catch (e) {  alert("error when reading jsonFile " + e);}
            }
        });
    } catch (err) {("ERROR " + err);}

}

function getTADs(plot, from, to) {
    var build = $("#build").val();
    chr = plot.chr;
    tads = [];
    try {  //get all the genes for the specified build and chromosome
        var script = get_TADs_cgi + "?chr=" + chr + "&build=" + build;
        $.ajax({
            type: "GET",
            url: script,
            success: function(jsonfile) {
                try {
                    $.getJSON(jsonfile, function(d) {
                        for (var i = 0; i < d.data.length; i++) {
                              tads.push(new TAD(d.data[i], chr));
                                if (i == d.data.length - 1) {
                                    addTADPlot(plot, from, to);
                            }
                        }
                    });
                } catch (e) {  alert("error when reading jsonFile " + e);}
            }
        });
    } catch (err) {("ERROR " + err);}
}


function addGenePlot(plot, from, to) {
    $("#genes").show();
    $("#overviewGenePlot").show();
    var axes = plot.flotplot.getAxes();
    var chrLength = axes.xaxis.max;
    var genePlotDiv = $("#genePlot");
    var geneMarkings = getGeneMarkings(genes, getChrEnd(plot.chr));
    try {
        var genePlot = $.plot(genePlotDiv, geneMarkings, getGenePlotOptions(0, chrLength, geneMarkings));
        overviewGenePlot = $.plot($("#overviewGenePlot"), geneMarkings, getGenePlotOverviewOptions(0, chrLength, geneMarkings));
        addStrandLabel(genePlot);
    } catch (e) {
        alert("ERROR when creating genePlot " + e);
    }
    bindGenePlotHover();
    bindGenePlotClick();
    genePlotDiv.bind("plotselected", function(event, ranges) {
        zoomToRange(ranges);
    });
    $("#overviewGenePlot").bind("plotselected", function(event, ranges) {
        genePlot.setSelection(ranges);
    });
    if (from) {
    //  function zoomToRange(ranges, plot, bp_pos, find_and_select_datapoint){
        zoomToRange({
            xaxis: {from: from,to: to},
            yaxis: {}
        });
    }
}

function addTADPlot(plot, from, to) {
    $("#TADs").show();
    $("#overviewTADPlot").show();
    var axes = plot.flotplot.getAxes();
    var chrLength = axes.xaxis.max;
    var tadPlotDiv = $("#TADPlot");
     var tadMarkings = getTADMarkings(tads, getChrEnd(plot.chr));
    try {
        var tadPlot = $.plot(tadPlotDiv, tadMarkings, getTADPlotOptions(from, to, tadMarkings));
    } catch (e) {
        alert("ERROR when creating genePlot " + e);
    }
    //  bindGenePlotHover();
    //  bindGenePlotClick();
        tadPlotDiv.bind("plotselected", function(event, ranges) {
        zoomToRange(ranges);
     });
    if (from) {
        zoomToRange({
            xaxis: {from: from,to: to},
            yaxis: {}
        });

}
}

function setGenesWithinInterval(from, to, chr, make_genes_DataTable){
  genes_current=[];
  for (var i = 0; i < genes.length; i++) {
      var gene = genes[i];
      if (((gene.bpStart >= from) && (gene.bpStart <= to)) || ((gene.bpStart <= from) && (gene.bpEnd >= to)) || ((gene.bpEnd >= from) && (gene.bpEnd <= to)))
          genes_current.push(gene);
      if ((gene.bpStart > to) || (i == genes.length - 1))
          i = genes.length;
  }
   make_genes_DataTable(from, to, chr);
}




function addStrandLabel(genePlot) {
    var o = genePlot.getPlotOffset();
    $("#genePlot").append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + (o.top) + 'px;color:#666;font-size:smaller">+1</div>');
    $("#genePlot").append('<div style="position:absolute;left:' + (o.left + 4) + 'px; bottom:' + (o.bottom) + 'px;color:#666;font-size:smaller">-1</div>');
}

function get_gene_color(gene){
    var geneColor = "#FF9900";
    if ((typeof(gene.disease) !== "undefined") && (1 < gene.disease.length)) {
        geneColor = "#CD5C5C";
        if(/\(k\)/.test(gene.disease))// color in red if the association is knowledge based
            geneColor="red";
    }
    return geneColor;
}

function getTADMarkings(tads, chrLength) {
  var tadMarkings=[];
    var tad;var tad_height=3; var y_from; var y_to;
    var y_start=[3, 6, 10, 14, 18];
    var j=0;
    for (var i = 0; i < tads.length; i++) {
      tad= tads[i];
      if( typeof(tad.bpStart) !== "undefined"  && typeof(tad.bpEnd) !== "undefined" ){
        var tadColor='#3bb300'
        y_from = y_start[j];
        y_to=parseInt(y_from+tad_height);
      tadMarkings.push({ color: tadColor,
                xaxis: { from: tad.bpStart,  to: tad.bpEnd},
                yaxis: {from: y_from,to: y_to},
            });
      j++;
      if(j === 5)
           j=0;
         }

   }
    return tadMarkings;
}

function getGeneMarkings(genes, chrLength) {
    geneMarkings = [];exonMarkings = []; overUnderMarkings = [];
    var gene;  var lastToOnPlusStrand = 0; var lastToOnMinusStrand = 0;
    var y_from_plus = 6;  var y_to_plus = 10;
    var y_from_minus = -10;  var y_to_minus = -6;

    for (var i = 0; i < genes.length; i++) {
      gene = genes[i];
       if( typeof(gene.strand) !== "undefined") {
            var strand = gene.strand.replace(/ /g, "");
            var geneColor = "#FF9900";
            if ((typeof(gene.disease) !== "undefined") && (1 < gene.disease.length)) {
                      geneColor = "#CD5C5C";
                      if(/\(k\)/.test(gene.disease))// color in red if the association is knowledge based
                          geneColor="red";
            }
            if ((strand == "1") || (strand == "+")) {
                if (gene.bpStart < lastToOnPlusStrand) {
                    y_from_plus = 12;y_to_plus = 16;
            } else {
                    y_from_plus = 6;y_to_plus = 10;
            }
            geneMarkings.push({
                color: geneColor,
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: y_from_plus,
                    to: y_to_plus
                },
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            exonMarkings.push({
                color: '#000000',
                xaxis: {
                    from: gene.bpStart,
                    to: gene.bpEnd
                },
                yaxis: {
                    from: 7.5,
                    to: 8.5
                },
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            lastToOnPlusStrand = gene.bpEnd;
           }
           else {  //if its the minus strand
              if (gene.bpStart < lastToOnMinusStrand) {
                y_from_minus = -16;  y_to_minus = -12;
            } else {
                y_from_minus = -10; y_to_minus = -6;
            }
            geneMarkings.push({
                color: geneColor,
                xaxis: {  from: gene.bpStart, to: gene.bpEnd},
                yaxis: { from: y_from_minus, to: y_to_minus},
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            exonMarkings.push({
                color: '#000000',
                xaxis: {from: gene.bpStart,to: gene.bpEnd},
                yaxis: {from: -8.5,to: -7.5},
                name: gene.name,
                ensId: gene.ensId,
                disease: gene.disease
            });
            lastToOnMinusStrand = gene.bpEnd;
        }
      }
    }
    exonMarkings.push({
        aboveData: true,
        color: '#646060',
        xaxis: {from: 0,to: chrLength},
        yaxis: {from: 0,to: 0}
    });
    geneMarkings.push({
        aboveData: true,
        color: '#646060',
        xaxis: {from: 0,to: chrLength},
        yaxis: {from: 0,to: 0}
    });
    return geneMarkings;
}

function addEntry(name, markings, max) {
    annotMarkingsArray.push({
        name: name,
        markings: markings,
        max: max
    });
}

function addExonToMarkings(exon) {

  if(typeof(exon.strand) !== "undefined"){
    var strand = exon.strand.replace(/ /g, "");
    var y_from = -11;
    var y_to = -5;
    if ((strand == "1") || (strand == "+")) {
        y_from = 5;
        y_to = 11;
    }
    var exonColor = "#FF9900";
    var disease="";
    if ((typeof(exon.disease) !== "undefined") && (1 < exon.disease.length)) {
          disease=exon.disease;
              exonColor = "#CD5C5C";
              if(/\(k\)/.test(exon.disease))// color in red if the association is knowledge based
                  exonColor="red";
    }
    exonMarkings.push({
        color: exonColor,
        xaxis: {
            from: exon.bpStart,
            to: exon.bpEnd
        },
        yaxis: {
            from: y_from,
            to: y_to
        },
        name: exon.name,
        disease: disease
    });
  }
}
