
function getRegionPlotOptions(plot, ranges) {
  var noColumns=1;
  if (plot.seriesArray.length > 34) {
      noColumns = Math.round(plot.seriesArray.length / 7);
  }
  var y_max=10;
  if(plot.maxScore > 0){
    if(parseFloat(plot.maxScore) < parseFloat(thresh))
           plot.maxScore=thresh;
    y_max=parseFloat(plot.maxScore) + parseFloat(plot.maxScore * 0.18);
  }
  var options = {
        xaxis: {
            tickDecimals: 0,
            min: ranges.xaxis.from,
            max: ranges.xaxis.to,
            tickFormatter: suffixFormatter
        },
     yaxis: {
            tickDecimals: 1,
            labelWidth: 20,
            max: y_max,
            min: 2,
            zoomRange : [plot.maxScore, plot.maxScore],
            panRange : [plot.maxScore, plot.maxScore]
        },
        selection: {
            mode: "x",
            minSize: 0.1
        },
      grid: {
          markings: getThrMarkings(),
          show: true,
          clickable: getDiff(ranges.xaxis.from, ranges.xaxis.to),
          autoHighlight: true,
          hoverable: getDiff(ranges.xaxis.from, ranges.xaxis.to),
          verticalLines:true,
          tickColor: '#DDDDDD',
          horizontalLines: true,
          outlineWidth:0.5
      },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        legend: {
            container: plot.labelsDiv,
            noColumns: noColumns
        },
    };
    return options;
}

function getThrMarkings(series) {
    var markings = [];
    var maxThr = 0;
    var thresholds = [];
    if (series.thresh) {
        if (series.thresh > maxThr)
            maxThr = series.thresh;
        thresholds.push(series.thresh);
    }
    for (var i = 0; i < thresholds.length; i++) {
        markings.push({
            color: '#D00000',
            yaxis: {
                from: thresholds[i],
                to: thresholds[i]
            },
            lineWidth: 0.8
        });
    }
    return {
        "markings": markings,
        "max": maxThr
    };
}

function getOverviewOptions(to) {
    var options = { //{series: {lines: {lineWidth: 1},shadowSize: 0},
        points: {
            radius: 0.2
        },
        xaxis: {
            max: to,
            min: 0,
            ticks: [],
            mode: "null"
        },
        yaxis: {
            ticks: [],
            autoscaleMargin: 0.1,
            min: 2
        },
        legend: {
            show: false
        },
        grid: {
            hoverable: false
        },
        selection: {
            mode: "x",
            minSize: 0
        }
    };
    //  options.series.points.radius=0.2;
    return options;
}

function getMarkerPlotOptions(labelsDiv, from, to) {
}

function getTADPlotOptions(from, to, markings) {
    var options = {
        xaxis: {
            min: from,
            max: to,
            tickDecimals: 0,
            //tickColor: "#FFFFFF",
            tickFormatter: suffixFormatter
        },
        selection: {
            mode: "x",
            minSize: 0.1
        },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        grid: {
            //tickColor: '#FFFFFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            markings: markings,
            verticalLines:true,
            tickColor: '#DDDDDD'
        },
        yaxis: {
            ticks: [],
            labelWidth: 20,
            labelHeight: null,
            min: 0,
            max: 23
        }
    };
    return options;
}

function getGenePlotOptions(from, to, markings) {
    var options = {
        xaxis: {
            min: from,
            max: to,
            tickDecimals: 0,
          //  tickColor: "#FFFFFF",
            tickFormatter: suffixFormatter
        },
        selection: {
            mode: "x",
            minSize: 0.1
        },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        grid: {
          //  tickColor: '#FFFFFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            markings: markings,
            verticalLines:true,
            tickColor: '#DDDDDD'
        },
        yaxis: {
            ticks: [],
            labelWidth: 20,
            labelHeight: null,
            min: -20,
            max: 20
        }
    };
    return options;
}
function getGenesGenomePlotOptions() {
    var options = {
        xaxis: {
          min: 0,
          max: 2874982691,
            tickDecimals: 0,
          //  tickColor: "#FFFFFF",
            tickFormatter: suffixFormatter
        },
        selection: {
            mode: "x",
            minSize: 0.1
        },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        grid: {
          //  tickColor: '#FFFFFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            verticalLines:true,
            tickColor: '#DDDDDD',
            markings: getChrMarkings()
        },
        yaxis: {
            ticks: [],
            labelWidth: 20,
            labelHeight: null,
            min: -20,
            max: 20
        }
    };
    return options;
}
function getGenePlotOverviewOptions(from, to, geneMarkings) {
    var options = {
        series: {
            lines: {
                lineWidth: 1
            },
            shadowSize: 0
        },
        xaxis: {
            min: 0,
            max: to,
            ticks: [],
            tickDecimals: null,
            tickFormatter: suffixFormatter
        },
        yaxis: {
            ticks: [],
            labelHeight: null,
            min: -20,
            max: 20
        },
        legend: {
            show: false
        },
        pan: {
            interactive: false
        },
        zoom: {
            interactive: false
        },
        grid: {
            tickColor: '#FFFFFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            markings: geneMarkings
        },
        selection: {
            mode: "x",
            minSize: 0
        }
    };
    return options;
}


function suffixFormatter(val, axis) {
    var range = axis.max - axis.min;
    if (range > 10000000)
        return (val / 1000000).toFixed(axis.tickDecimals) + " MBp";
    else if (range > 10000)
        return (val / 1000).toFixed(axis.tickDecimals) + " kBp";
    else
        return val.toFixed(axis.tickDecimals) + " Bp";
}

function getMultiPlotOptions(labelsDiv, seriesArray) {
    var thrMax = parseFloat(thresh) + 1.3;
    var maxScore = 0;
    var chrMarkings=getChrMarkings();
    var markings = chrMarkings.concat(getThrMarkings());
    var options = multiPlotOptions(labelsDiv, markings);
    $.each(genomePlots, function(j, plot) {
        if (maxScore < parseFloat(plot.maxScore))
            maxScore = plot.maxScore;
    });
    if (maxScore > 0)
        options.yaxis.max = parseFloat(maxScore) + parseFloat(maxScore * 0.18);
    //if the largest threshold value is bigger then the max Score, the maximum y-value on the grid has to be reset
    if ((thrMax > 0) && (maxScore < thrMax))
        options.yaxis.max = thrMax;
    return options;
}


function multiPlotOptions(labelsDiv, markings) {
    var to = getChrEnd(chr_names.length - 1);
    var noColumns=1;
    var options = {
        xaxis: {
            min: 0,
            max: to,
            ticks: 0
        },
        yaxis: {
            tickDecimals: 1
        },
    //    crosshair: {
    //        mode: "x",
    //        lineWidth: 0.5
    //    },
        grid: {
            markings: markings,
            clickable: true,
            hoverable: true,
            autoHighlight: false
        },
        legend: {
            container: labelsDiv,
            noColumns: noColumns
        },
        series: {
            lines: {
                lineWidth: 0.5
            }
        }
    };
    return options;
}

function getThrMarkings(){
  var markings=[ {color: '#D00000', yaxis:{ from: thresh, to:thresh}, lineWidth:0.8 }];
  return markings;

}

function getChrMarkings() {
    var markings = [];
    for (var i = 0; i < chr_names.length; i = i + 2) {
        markings.push({
            color: '#E8E8E8',
            xaxis: {
                from: getChrEnd(i),
                to: getChrEnd(i + 1)
            }
        });
    }
    return markings;
}
