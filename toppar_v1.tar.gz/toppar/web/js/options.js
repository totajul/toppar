function getSinglePlotOptions(labelsDiv, seriesArray, from, to) {
    var thrMarkings = [];
    var thrMax = 0;
    var noColumns = 1;
    if (seriesArray.length > 7) {
        noColumns = Math.round(seriesArray.length / 7);
    }
    for (var i = 0; i < seriesArray.length; i++) {
        var series = seriesArray[i];
        if (series) {
            if (series.thresh) {
                var thrData = getThrMarkings(series);
                thrMarkings = thrData.markings;
                thrMax = parseFloat(thrData.max) + 0.8;
                i = seriesArray.length; //leave the for-loop since we only need one
            }
        }
    }
    var maxScore = 0;
    $.each(seriesArray, function(j, series) {
        if (maxScore < parseFloat(series.maxScore)) {
            maxScore = series.maxScore;
        }
    });
    var options = singlePlotOptions(labelsDiv, thrMarkings, from, to, noColumns);
    //if the largest threshold value is bigger then the max Score, the maximum y-value on the grid has to be reset
    //add 15% to the top to give space for buttons
    if (maxScore > 0)
        options.yaxis.max = parseFloat(maxScore) + parseFloat(maxScore * 0.18);
    if ((thrMax > 0) && (maxScore < thrMax)) {
        options.yaxis.max = thrMax;
        options.yaxis.zoomRange = [thrMax, thrMax]; //dont move the y-axis
        options.yaxis.panRange = [thrMax, thrMax];
    } else {
        options.yaxis.zoomRange = [maxScore, maxScore]; //dont  move the y-axis
        options.yaxis.panRange = [maxScore, maxScore];
    }
    return options;
}

function getMarkerPlotOptions(labelsDiv, from, to) {
    var options = {
        xaxis: {
            tickDecimals: 0,
            min: from,
            max: to,
            tickFormatter: suffixFormatter
        },
        selection: {
            mode: "x"
        },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        grid: {
            tickColor: '#FFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            boderColor: {
                top: "#FFF"
            }
        },
        yaxis: {
            tickDecimals: null,
            labelWidth: 20
        },
        series: {
            lines: {
                show: false
            },
            points: {
                show: true,
                fill: 1,
                radius: 2
            }
        }, //, fill: true},
        legend: {
            container: labelsDiv
        }
    };
    return options;
}

function getGenePlotOptions(from, to, markings) {
    var options = {
        xaxis: {
            min: from,
            max: to,
            tickDecimals: 0,
            tickColor: "#FFFFFF",
            tickFormatter: suffixFormatter
        },
        selection: {
            mode: "x",
            minSize: 0.1
        },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        grid: {
            tickColor: '#FFFFFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            markings: markings
        },
        yaxis: {
            ticks: [],
            labelWidth: 20,
            labelHeight: null,
            min: -20,
            max: 20
        }
    };
    return options;
}

function getGenePlotOptions2(from, to, markings) {
    var options = {
        xaxis: {
            min: from,
            max: to,
            tickDecimals: 0,
            tickColor: "#FFFFFF",
            tickFormatter: suffixFormatter
        },
        selection: {
            mode: "x",
            minSize: 0.1
        },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        grid: {
            tickColor: '#FFFFFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            markings: markings
        },
        yaxis: {
            labelWidth: 20,
            labelHeight: null,
            min: 0,
            max: annotMax
        }
    };
    return options;
}

function getGenePlotOverviewOptions(from, to, geneMarkings) {
    var options = {
        series: {
            lines: {
                lineWidth: 1
            },
            shadowSize: 0
        },
        xaxis: {
            min: 0,
            max: to,
            ticks: [],
            tickDecimals: null,
            tickFormatter: suffixFormatter
        },
        yaxis: {
            ticks: [],
            labelHeight: null,
            min: -20,
            max: 20
        },
        legend: {
            show: false
        },
        pan: {
            interactive: false
        },
        zoom: {
            interactive: false
        },
        grid: {
            tickColor: '#FFFFFF',
            show: true,
            clickable: true,
            autoHighlight: true,
            hoverable: true,
            markings: geneMarkings
        },
        selection: {
            mode: "x",
            minSize: 0
        }
    };
    return options;
}

function singlePlotOptions(labelsDiv, thrMarkings, from, to, noColumns) {
    var options = {
        xaxis: {
            tickDecimals: 0,
            min: 0,
            tickFormatter: suffixFormatter
        },
        yaxis: {
            tickDecimals: 1,
            labelWidth: 20
        },
        selection: {
            mode: "x",
            minSize: 0.1
        },
        grid: {
            markings: thrMarkings
        },
        zoom: {
            interactive: false
        },
        pan: {
            interactive: false
        },
        // points: {fill: 1, radius:1},
        legend: {
            container: labelsDiv,
            noColumns: noColumns
        },
    };
    if (typeof(from) != "undefined") {
        options.xaxis.min = from;
        options.xaxis.max = to;
        options.grid.hoverable = getDiff(from, to);
        options.grid.clickable = getDiff(from, to);
    }
    return options;
}

function getExtendedOptions(ranges, axes, plot_type, yMin) {
    var options = {
        xaxis: {
            min: ranges.xaxis.from,
            max: ranges.xaxis.to
        },
        yaxis: {
            min: axes.yaxis.min,
            max: axes.yaxis.max
        },
        points: {
            radius: 1
        },
        grid: {
            hoverable: getDiff(ranges.xaxis.from, ranges.xaxis.to),
            clickable: getDiff(ranges.xaxis.from, ranges.xaxis.to)
        },
        //series: {points: {radius: 3,show : getDiff(ranges.xaxis.from,ranges.xaxis.to)} }
    };
    if (yMin) {
        //options.yaxis.min=yMin;
    }
    return options;
}

function getOverviewOptions(to) {
    var options = { //{series: {lines: {lineWidth: 1},shadowSize: 0},
        points: {
            radius: 0.2
        },
        xaxis: {
            max: to,
            min: 0,
            ticks: [],
            mode: "null"
        },
        yaxis: {
            ticks: [],
            autoscaleMargin: 0.1
        },
        legend: {
            show: false
        },
        grid: {
            hoverable: false
        },
        selection: {
            mode: "x",
            minSize: 0
        }
    };
    //  options.series.points.radius=0.2;
    return options;
}

function suffixFormatter(val, axis) {
    var range = axis.max - axis.min;
    if (range > 10000000)
        return (val / 1000000).toFixed(axis.tickDecimals) + " MBp";
    else if (range > 10000)
        return (val / 1000).toFixed(axis.tickDecimals) + " kBp";
    else
        return val.toFixed(axis.tickDecimals) + " Bp";
}

function getMultiPlotOptions(labelsDiv, seriesArray) {
    var thrMarkings = [];
    var thrMax = 0;
    var data = seriesArray[0].data;
    //for(var i=0; i<data.length; i++){
    if (seriesArray[0].thresh) {
        var thrData = getThrMarkings(seriesArray[0]);
        thrMarkings = thrData.markings;
        thrMax = parseFloat(thrData.max) + 1.3;
        //i=data.length;//leave the for-loop since we only need one
    }
    //}
    var maxScore = 0;
    var chrMarkings = getMarkings();
    var markings = chrMarkings;
    markings = chrMarkings.concat(thrMarkings);
    var options = multiPlotOptions(labelsDiv, markings);
    $.each(seriesArray, function(j, series) {
        if (maxScore < parseFloat(series.maxScore)) {
            maxScore = series.maxScore;
        }
    });
    if (maxScore > 0)
        options.yaxis.max = parseFloat(maxScore) + parseFloat(maxScore * 0.18);
    //if the largest threshold value is bigger then the max Score, the maximum y-value on the grid has to be reset
    if ((thrMax > 0) && (maxScore < thrMax))
        options.yaxis.max = thrMax;
    return options;
}

function getMultiPlotOptionsGenome(seriesArray) {
    var thrMarkings = [];
    var thrMax = 0;
    var chrMarkings = getMarkings();
    var markings = chrMarkings;
    markings = chrMarkings.concat(thrMarkings);
    var options = multiPlotOptions("", markings);
    return options;
}

function multiPlotOptions(labelsDiv, markings) {
    var to = getChrEnd(chr_names.length - 1);
    var options = {
        xaxis: {
            min: 0,
            max: to,
            ticks: 0
        },
        yaxis: {
            tickDecimals: 1
        },
        crosshair: {
            mode: "y",
            lineWidth: 0.5
        },
        grid: {
            markings: markings,
            clickable: true,
            hoverable: true,
            autoHighlight: false
        },
        legend: {
            container: labelsDiv,
            noColumns: 10
        },
        series: {
            lines: {
                lineWidth: 0.5
            }
        }
    };
    return options;
}

function getMarkings() {
    var markings = [];
    for (var i = 0; i < chr_names.length; i = i + 2) {
        markings.push({
            color: '#E8E8E8',
            xaxis: {
                from: getChrEnd(i),
                to: getChrEnd(i + 1)
            }
        });
    }
    return markings;
}

function getThrMarkings(series) {
    var markings = [];
    var maxThr = 0;
    var thresholds = [];
    if (series.thresh) {
        if (series.thresh > maxThr)
            maxThr = series.thresh;
        thresholds.push(series.thresh);
    }
    for (var i = 0; i < thresholds.length; i++) {
        markings.push({
            color: '#D00000',
            yaxis: {
                from: thresholds[i],
                to: thresholds[i]
            },
            lineWidth: 0.8
        });
    }
    return {
        "markings": markings,
        "max": maxThr
    };
}

1;
