var plots=[];
var genomePlots=[];
var geneMarkings=[];
var exonMarkings=[];
var chr;
var thresh="8.30103";
var evalue="5e-09";
var noGenesOnDisplay=1000;
var genesSeen=[];
var range_ld_calc=2000000; // 2MB - activate LD calculations
var range_interactive=20000000; //20 MB change the display of the points and make them interactive at this zoom in range
var ntiles=1000;
var gwas_data=[];


function show_region_btns(){
    $("#regionBtns_href").show();
    $("#show_tads").show();
    show_genome_region_spans();
    //hide genome components
    $("#select_ntiles").hide();
    $("#ntiles").hide();
}

function show_genome_btns(){
    $("#select_ntiles").show();
    $("#ntiles").show();
    show_genome_region_spans();
  //  $("#regionBtns_href").show();
  $("#regionBtns_href").hide();
    //hide region components
    $("#show_tads").hide();
    //$("#regionBtns_href").hide();
}

function show_genome_region_spans(){
  $("#onePlot_span").show();
  $("#y_max_span").show();
}

function getRegion(chr, from, to, bp_pos, find_and_select_datapoint){
    //emptyTxtBoxes();
    if(!chr){
      chr=$("#chromosomes").val(); //.replace(/chr/, '');
      if(/chr/.test(chr))
           chr=chr.val().replace(/chr/, '');
     if(!chr)
	     chr="1"; //use chromosome 1 as default if no value has been selected
     }
     if(!from){
       from=0;
       to=getChrLength(chr);
     }
    prepareRegionHolder();
    getPlotData(false, chr, from, to);
    if(find_and_select_datapoint && typeof(find_and_select_datapoint) == "function"){
        find_and_select_datapoint(chr,bp_pos);
      }
}

function prepareRegionHolder(){
  variantDetails={};
  gwas_data=[];
  //empty
  $("#regionPlots").empty();
  //$("#annotation").empty();
  $("#results_genome_tables").empty();
  $("#genes").empty();
  $("TADs").empty();
  $("#message").empty();
  $("#results_region_tables").empty();
  $("#gwascat_region_table").empty();
  $("#gwascat_region_label").empty();
  //hide
  $("#variantDetailsContainer").hide();
  $("#gwascat_region_table_div").hide();
//$("#results_region_tables").hide();
  $("#genes_region_table_div").hide();
  $("#genome").hide();
  //show
  $("#region").show();
  $("#regionPlots").show();
  $("#varImpact").show();
  //uncheck
  $("#high").prop('checked', false);
  $("#low").prop('checked', false);
  $("#moderate").prop('checked', false);
  $("#other").prop('checked', false);
  $('#results_region_table_cb').prop('checked', false);
  //check
  $("#radio_region").prop('checked' , true); //if we come from displayRegionForChr, this hasnt been checked manually
  //remove
  $("#tooltip").remove(); //remove any outstanding tooltips
  $(".snp_label").remove(); //remove outstanding marker laappendbels

  if(document.getElementById("genomePlots").childNodes.length > 0)
      $("#backToGenome").show();

}

function backToRegionView(){
  $("#genome").hide();
  $("#backToGenome").show();
  $("#region").show();
  $("#radio_region").is("checked" , true);
  show_region_btns();
  $("#tooltip").remove(); //remove any remaining tooltips
  $(".snp_label").remove();
  if(document.getElementById("genomePlots").childNodes.length > 0)
    $("#backToGenome").show();
}


function get_plotObj(condensed, pi, pn, chr){
  var plot=new Plot(pi, pn, condensed, chr);
  if(condensed){genomePlots.push(plot);}
  else{plots.push(plot)} //plots are stored in a global array
  return plot;
}




function showTADs(){
    if( $('#showTADs').prop('checked') ){
      if(typeof(plots[0]) !== "undefined"){
         addTADs(plots[0], plots[0].from, plots[0].to);
         bindSinglePlots(plots);
     }
   }
  else{
      $('#TADs').hide();
  }
}

function plotSinglePlot(plot){
    if($("#unit"+plot.phenoIndex).text() == '')
	  $("#unit"+plot.phenoIndex).append("logP");
    plot.labelsDiv=$("#labels"+plot.phenoIndex);
    //do the plotting
    var ranges={xaxis: {from : 0, to: getChrLength(plot.chr)}}; //, yaxis: {from: parseInt(yaxis.datamin), to: parseInt(yaxis.datamax)} };
    plot.options=getRegionPlotOptions(plot, ranges); //same for all series??
    plot.flotplot=$.plot( $("#"+plot.placeHolder), plot.seriesArray, plot.options);
    //make the points smaller for the overview plot
    plot.changeSeriesArrayRadius(0.2);
    var overview_serArray=[];
    //make a copy of the seriesArray for the overview plot and point data to the original data
    $.each(plot.seriesArray, function(i, series){
	      var s=series;
	      s.data=series.origData;
	      overview_serArray.push(s);
	});
    plot.overviewPlot = $.plot($("#overview"+plot.phenoIndex), overview_serArray , getOverviewOptions(getChrLength(plot.chr)));
    plot.changeSeriesArrayRadius(1);
    //add Buttons and Labels to the plot
    addZoomOutBtn(plot.placeHolder, plot.flotplot, plot.chr);
    addChrLabel(plot);
    addSignificanceThreshold(plot);
}


/*
  Buttons and labels displayed on plots
 */

function addChrLabel(plot){
  var o=plot.flotplot.getPlotOffset();
  var xc = plot.flotplot.getAxes().xaxis.p2c;
  $("#"+plot.placeHolder).append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + (o.top) + 'px;color:#666;font-size:smaller">'+plot.phenoType+' - chr'+plot.chr+'</div>');
}

function addSignificanceThreshold(plot){
  var plotDiv=$("#"+plot.placeHolder);
  var yc=(plot.flotplot).getAxes().yaxis.p2c;
  var o=(plot.flotplot).getPlotOffset();
  var y=yc(thresh)+o.top;
  plotDiv.append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + y + 'px;color:#D00000;font-size:10px">'+evalue+'</div>');
}

function addZoomOutBtn(plotDiv, plot, chr){
  $('<div class="button" style="right:24px;top:10px">zoom out</div>').appendTo($("#"+plotDiv)).click(function (e) {
	     e.preventDefault();
       var axes=plot.getAxes();
       var min=parseFloat(axes.xaxis.min);
	     var max=parseFloat(axes.xaxis.max);
       var zoomAmount=(max-min) * 0.75
       var from=min- zoomAmount;
	     var to=max+ zoomAmount;
	      zoomToRange({ xaxis : {from : from, to: to}, yaxis: {}});
	   });
  addArrow('left', 56, 30, plotDiv, plot);
  addArrow('right', 28, 30,  plotDiv, plot);
}

function addArrow(dir, right, top, plotDiv, plot) {
  var axes=plot.getAxes();
  var xaxis=axes.xaxis;
  var yaxis=axes.yaxis;
  var ranges;
  $('<img class="button" src="images/arrow-' + dir + '.gif" style="right:' + right + 'px;top:' + top + 'px">').appendTo($("#"+plotDiv)).click(function (e) {
	  e.preventDefault();
	  var min=parseInt(xaxis.datamin);
	  var max=parseInt(xaxis.datamax);
	  var panRange=parseInt((max-min)*0.15);
	  var x_from; var x_to;
	  if(dir == 'left'){
	    x_from= min - panRange;
	    x_to= max- panRange;
	  }
	  else{
	    x_from= min + panRange;
	    x_to= max + panRange;
	  }
	  ranges={xaxis :{from : x_from, to: x_to}, yaxis: {from: parseInt(yaxis.datamin), to: parseInt(yaxis.datamax)} };
	  zoomToRange(ranges, plot);
	  //  plot.pan(offset);
    });
}

function changeRadius(seriesArray, radius){
  $.each(seriesArray, function(i, series){
	   series.points.radius=radius;
	 });
}


function setSinglePlotDivs(plot){
  var pi=plot.phenoIndex;
  var html="";
  plot.placeHolder="mainPlot"+pi;
  plot.overviewPlaceHolder="overview"+pi;
  plot.markersPlaceHolder="marker"+pi;
  var plotDiv='<div id="mainPlot'+pi+'"></div>';
  var labels='<div id="labels'+pi+'"></div>';
  var overview='<div id="overview'+pi+'"></div>';
  var unitDiv='<div id="unit'+pi+'"></div>';
  var info='<div id="info'+pi+'"></div>';
  var gwasCheckBox='<div  class="checkbox" ><label><input id="gwasCB'+pi+'" onclick="plotGWASCatalog(\''+pi+'\')" type="checkbox">show GWAS catalog SNPs</label></div>';
  var gwasColorLabel='<label id="gwasColorLabel'+pi+'" class="graphTxt">Color GWAS snp/s by trait:</label>';
  var gwasLabelText='<div class="form-inline2"><input type="text"  placeholder="Ex: Ulcerative" id="gwasTermRegion'+pi+'" name="gwasTermRegion'+pi+'">';
  gwasLabelText+='<select class="form-control2" id="gwasColorSelectRegion'+pi+'"><option selected>red</option><option>purple</option><option>orange</option><option>lightblue</option><option>green</option><option>yellow</option><option>black</option></select><button type="submit" class="btn btn-smaller btn-info" onclick="gwasTermFilterRegion(\''+pi+'\')">Submit</button> </div>';
  var gwasDiv='<div id="gwasCheckbox'+pi+'">'+gwasCheckBox+'</div>';
  var ldCheckBox='<span class="graphTxt">Calculate LD for the selected marker/SNP:  &nbsp <button disabled type="submit" class="btn btn-info btn-smaller" id="ldBtn'+pi+'"  onclick="get_LD(\''+pi+'\')">Get LD</button>&nbsp</span>';
  ldCheckBox +='<span><button style="display:none" type="submit" class="btn btn-info btn-smaller" id="rmLDBtn'+pi+'" onclick="rm_LD(\''+pi+'\')">Rm LD</button></span>';
  var ldDiv='<br><hr class="reducedPadding2" style="border-top: dotted 1px;"><div id="ldCheckbox'+pi+'">'+ldCheckBox+'</div>';
  html+= '<table><tr><td>'+unitDiv+'</td><td>'+plotDiv+'</td>';
  html+='<td valign="top"><table cellspacing="0" padding="0"><tr><td>'+overview+'</td></tr><tr><td>'+labels+'</td></tr>';
    html+='<tr style="height:1px"><td style="height:1px"><hr class="reducedPadding2"></td></tr>';
    html+='<tr><td>'+info+'</td></tr><tr style="height:20px"></tr>';
    html+='<tr><td><hr class="reducedPadding2" style="border-top: dotted 1px;"> </td></tr>';
    html+='<tr><td>'+gwasDiv+'</td></tr>';
    html+='<tr><td><hr class="reducedPadding2" style="border-top: dotted 1px;"> </td></tr>';
    html+='<tr><td>'+gwasColorLabel+'</td></tr><tr><td>'+gwasLabelText+'</td></tr>'; //<tr><td>&nbsp&nbsp&nbsp</td><tr>
    html+='<tr><td>'+ldDiv+'</td></tr>';
    html+='</table></table>';
    return html;
}


function getCondensed_wtiles(plot){
  ntiles=$("#ntiles").val()
}

function addStyles(pi){
  //instead add style to all labels and all checkboxes??????
  $("#mainPlot"+pi).addClass('regionPlot');
  $("#markerPlot").addClass('markerPlot');
  $("#overview"+pi).addClass('overviewPlot');
  $("#unit"+pi).addClass('verticalTxt');
  //add class graphTxt to all labels
  //$('input[type=checkbox]').addClass('graphTxt');
  $('#info'+pi).addClass('graphTxt');
  $("#showAll"+pi).addClass('graphTxt');
  $("#markerCheckbox").addClass('graphTxt');
  $("#gwasCheckbox"+pi).addClass('graphTxt');
  $("#gwasColorSelect"+pi).addClass('graphTxt');
  $("#gwasColorLabel"+pi).addClass('graphTxt');
}

function showTooltip(x, y, contents) {
  $('<div id="tooltip">' + contents + '</div>').css( {
      position: 'absolute',
      display: 'none',
      top: y + 5,
      left: x + 5,
	      border: '1px solid #fdd',
	      padding: '6px',
	      'background-color': '#fee',
	      opacity: 0.90
  }).appendTo("body").show();
}

function showImpactType(id, show){
    var redraw=false;
    $.each(plots, function(i, plot){
	    $.each(plot.seriesArray, function(j, series){
		  // if(series.impact.match(/id/i)){
      if(series.impact === id){
        if(series.points.show !== show)
			    redraw=true;
			series.points.show=show;
		    }
		});
	    //if there was a change, redraw:
	    if(redraw){
		        plot.flotplot.setData(plot.seriesArray)
		        plot.flotplot.draw();
	    }
	});
}

function hideByImpact(id){
    if(document.getElementById(id).checked)
	         showImpactType(id, false);
    else
	      showImpactType(id, true);
}

function hideGeneTableDiv(id){
    if(document.getElementById(id).checked)
	         $('#genes_region_table_div').show();
    else
	       $('#genes_region_table_div').hide();
}

function hideResultsTableDiv(id){
    if(document.getElementById(id).checked){
	         $('#results_region_tables').show();
           //check whether the table has already been created:
            if($("#results_region_tables").html() === ""){
                mk_results_region_DataTable();
            }
         }
    else
	       $('#results_region_tables').hide();
}

function hideVariantDetailsDiv(id){
    if(document.getElementById(id).checked)
	         $('#variantDetailsContainer').show();
    else
	       $('#variantDetailsContainer').hide();
}

function hideGwascatTableDiv(id){
  if(document.getElementById(id).checked){
   $('#gwascat_region_table_div').show();
          if($("#gwascat_region_table").html() === ""){
	      mk_gwas_region_DataTable();
          }
   }
   else
        $('#gwascat_region_table_div').hide();
}

function hideSeries(labelDiv){
    var pi = labelDiv.substr(labelDiv.length - 1);
    var plot;
    if(labelDiv === "#marker_labels"){
	$.each(markerPlot.seriesArray, function(i, series){
		series.points.show=true;
	    });
	$(labelDiv+' input[type=checkbox]').each(function(){
		if($(this).prop('checked')){
		    var labelCh=$(this).attr('value');
		    $.each(markerPlot.seriesArray, function(i, series){
			    if(labelCh === series.label)
				        series.points.show=false;
			});
		}
            });
        markerPlot.flotplot.setData(markerPlot.seriesArray)
        markerPlot.flotplot.draw();
    }
    else{
	if($('#genomePlots').is(':visible'))
	    plot=genomePlots[pi];
	else
	    plot=plots[pi];
	$.each(plot.seriesArray, function(i, series){
		series.points.show=true;
		if(!(series.gwasCatalog))
		    hideShowChildren(plot, series.typeIndex, true);
		else
		    series.points.show=true;
});
	$('#'+labelDiv+' input[type=checkbox]').each(function(){
	    if($(this).prop('checked')){
		var labelCh=$(this).attr('value');
		$.each(plot.seriesArray, function(i, series){
			if(labelCh === series.label){
			    //   series.points.show=false;
			    if(!(series.gwasCatalog))
				hideShowChildren(plot, series.typeIndex, false);
			    else
				series.points.show=false;
			}
		    });
	    }
	    });
	    plot.flotplot.setData(plot.seriesArray)
	    plot.flotplot.draw();
    }
}

function hideShowChildren(plot, pi, show){
    $.each(plot.seriesArray, function(i, series){
	     if(series.typeIndex === pi){
		       if(document.getElementById(series.impact).checked)
		          series.points.show=false;
		        else
		          series.points.show=show;
	    }
    });
}
