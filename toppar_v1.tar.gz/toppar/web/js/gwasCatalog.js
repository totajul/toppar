
function plotGWASCatalog(phenoIndex){
    var plot=plots[phenoIndex];
    if($("#gwasCB"+phenoIndex).prop('checked'))
	         addGWASseries(plot);
    else
	     plot.rmGwasSeries();
    redrawPlot(plot);
}

function gwasTermFilterRegion(phenoIndex){
    var val=document.getElementById('gwasTermRegion'+phenoIndex).value;
    var color=$('#gwasColorSelectRegion'+phenoIndex+' :selected').text();
    var plot;
    var valTrimmed=val.trim();
    if(valTrimmed.length  < 1){
	      val=$('#gwasTerm'+phenoIndex).val();
	      val=document.getElementById('gwasTermRegion'+phenoIndex).value;
    }
    else{
	     if($('#genomePlots').is(':visible'))
	        plot=genomePlots[phenoIndex];
	    else
	     plot=plots[phenoIndex];
	var re=new  RegExp(val, 'i');
	var tmp=[];
	var gwasSeries;
	var gwas_series_present=0;
	var count=0;
	$.each(plot.seriesArray, function(i, series){
		if(series.gwasCatalog){
		    gwasSeries=series;
		    gwas_series_present=1;
		    var updated_d=[];
		    $.each(series.origData, function(j, dataEntry){
			    if(dataEntry[3].match(re))
				    tmp.push(dataEntry);
			    else
				      updated_d.push(dataEntry);
			});
		    gwasSeries.data=updated_d;
		    gwasSeries.origData=updated_d;
		}
	    });
	if(!(gwas_series_present))
	    alert("No GWAS catalog SNPs on the plot!");
	else{
	    if(tmp.length>0){
		//update labels of other gwas series
		updateGWASlabels(plot);
		var series=new Series(plot.seriesArray.length);
		series.addGwasCatData(tmp,color,val,gwasSeries);
		plot.addSeries(series);
		if($('#genomePlots').is(':visible')){
		    redrawGenomePlot(plot);
		}
		else{
		    redrawPlot(plot);
		}
	    //plot.addSeries(series);
	    //redrawPlot(plot);
	    //get all the GwasCatalog series, where gwasCatalog=true, set the label to: series.label="GWAS catalog: val"

	}
	else{
	    alert("Found nothing mathing the terms: "+val);
	}
	}
}
}

function gwasTermFilterGenome(phenoIndex){
    var val=document.getElementById('gwasTermGenome'+phenoIndex).value;
    var color=$('#gwasColorSelectGenome'+phenoIndex+' :selected').text();
    var plot;
    var valTrimmed=val.trim();
    if(valTrimmed.length  < 1){
	console.log("val is an emtpy string "+phenoIndex);
	val=$('#gwasTerm'+phenoIndex).val();

    }
    else{
	if($('#genomePlots').is(':visible')){
	    plot=genomePlots[phenoIndex];
	}
	else{
	    plot=plots[phenoIndex];
	}

	var re=new  RegExp(val, 'i');
	var tmp=[];
	var gwasSeries;
	var gwas_series_present=0;
	var count=0;
	$.each(plot.seriesArray, function(i, series){
	    if(series.gwasCatalog){
		      gwasSeries=series;
		      gwas_series_present=1;
		        var updated_d=[];
		          $.each(series.origData, function(j, dataEntry){
                  if(dataEntry[3].match(re)){
			                 tmp.push(dataEntry);
		            }

		    else{
			       updated_d.push(dataEntry);
		    }
		});
		gwasSeries.data=updated_d;
		gwasSeries.origData=updated_d;
	    }
	});
	if(!(gwas_series_present)){
	    alert("No GWAS catalog SNPs on the plot!");
	}
	else{
	if(tmp.length>0){
	    //update labels of other gwas series
	    updateGWASlabels(plot);
	    var series=new Series(plot.seriesArray.length);
	    series.addGwasCatData(tmp,color,val,gwasSeries);
	    plot.addSeries(series);
	    if($('#genomePlots').is(':visible')){
		      redrawGenomePlot(plot);
	    }
	    else{
		redrawPlot(plot);
	    }

	}
	else{
	    alert("Found nothing mathing the terms: "+val);
	}
	}
}
}




function  updateGWASlabels(plot){
    $.each(plot.seriesArray, function(i, series){
		if(series.gwasCatalog){
		       series.label="GWAS catalog : "+series.terms+"("+series.origData.length+")";
		}
    });
}

function reset_y_axis(){
    var new_max=$("#y_max").val();
    if($('#genomePlots').is(':visible')){
	$.each(genomePlots, function(i, plot){
		$.each(plot.seriesArray, function(j, series){
			series.maxScore=new_max;
		    });
		redrawGenomePlot(plot);
	    });
    }
    else{
	$.each(plots, function(i, plot){
		$.each(plot.seriesArray, function(j, series){
			series.maxScore=new_max;
		    });
		redrawPlot(plot);
	    });
    }
}

function plotGWASCatalogGenome(phenoIndex){
    var plot=genomePlots[phenoIndex];
    if($("#gwasGenomeCB"+phenoIndex).is(":checked")){
           addGWASGenome(plot);
          //addGWASGenome(plot, addGWASCatTable);
    }
    else{
	plot.rmGwasSeries();
	//redrawPlot(plot);
    }
    plotGenome(plot);
}
//
//function addGWASGenome(plot, callback){
function addGWASGenome(plot){ 
   var script=getGWASCatSnps_cgi;
    try{
	$.ajax({
		type: "GET",
		    url:script,
		    success : function(jsonfile){
		    console.log(jsonfile);
		    try{
			$.getJSON(jsonfile, function(d){
				var series=new Series(plot.seriesArray.length);
				series.addGwasData(d);
				//series.setGwasCatalog(true);
				initColAndDisplay(series);
				plot.addSeries(series);
				plotGenome(plot);
                                //callback(d);


			});
		}
		catch(err){
		    alert("Error when getting GWAS json "+err);
		}
	    }

	});
    }
    catch(err){alert("Error when trying to get GWAS data: "+err);
    }
}

function addGWASseries(plot){
    //get GWAS catalog data
    // var gwas_max=$("#gwas_max").val();
    //gwas_max=gwas_max.replace(/ /g,""); //remove all white spaces
    var script=getGWASCatSnps_cgi+"?chr="+plot.chr;
    try{
	$.ajax({
		type: "GET",
	            url:script,
		    success : function(jsonfile){
		    try{
		    $.getJSON(jsonfile, function(d){
			    // var lastTypeIndex=plot.seriesArray[plot.seriesArray.length-1].typeIndex;
			    var prevSeries=plot.seriesArray[plot.seriesArray.length-1];
			    var typeIndex=prevSeries.typeIndex+1;
			    var series=new Series(typeIndex, "circle", "unknown");
			     if(typeof(d) != "undefined"){
			    //series.addJsonData(d);
			    series.addGwasData(d);
			    //series.addGwasData(d);
			    //series.setGwasCatalog(true);
			    initColAndDisplay(series);
			    plot.addSeries(series);
			    redrawPlot(plot);

			}
			});
		}
		catch(err){
		    console.log("cant get json "+jsonFile);
		    alert("Error when getting GWAS json "+err);
		}
	    }

	});
    }
    catch(err){
	console.log("ERROR");
	alert("Error when trying to get GWAS data: "+err);
    }
}

function redrawGenomePlot(plot){
    plotGenome(plot);
}

function redrawPlot(plot){
    if(typeof(plot.ranges) != "undefined"){ //are we zoomed in?
	plotSinglePlot(plot);
    	zoomToRange(plot.ranges, plot);
       }
    else{
    	plotSinglePlot(plot);
    }
}


function initColAndDisplay(series){
    var radius=1;
    series.color="grey";   //#D3D3D3"; //#grey";  #"#FF0000";
    if(series.plot_type="point"){
	series.points={show:true, radius: radius};
	series.lines={show:false};
    }
}

function  addGWASCatTable(d){
     //gwascat_genome
     var annot = $("#gwascat_genome");
     //annot.empty();
     annot.show();
    // annot.append("<table id=gwasTable></table>");
     console.log("ADDING GWAS CAT TABLE");
console.log(d);

    annot.append("<h2 class=\"text-primary\" style=\"color:#08519C\">GWAS catalog table</h2>");
    var html = "<br><table class=\"stripe\" id=\"gwasTable\"><thead><th>1</th><th>col2</th><th>col3</th><th>Disease</th></thead><tbody>";
     	$.each(d.data, function(i, data){
            html+="<tr><td>"+data[0]+"</td><td>"+data[1].toFixed(2)+"</td><td>"+data[2]+"</td><td>"+data[3]+"</td></tr>";
      });
      html+="</tbody></table>";
      annot.append(html);

     $('#gwasTable').DataTable();
        //
    // annot.append("<hr><h2 class=\"text-primary\" style=\"color:#08519C\">Annotations on  chromosome " + chr + " between " + from + " and " + to + "</h2>");
    // annot.append("Links to " + links + " databases are given when available<br>");
  //   ..var html = "<br><table border=\"0\" width=\"100%\" cellspacing=\"2\" cellpadding=\"2\" align=\"left\" class=\"table-condensed table-striped\"><tr><td><b>Gene_name</b></td><td><b>Ensembl_ID</b></td><td width=50><b>Info</b></td><td><b>Genomic_interval</b></td><td><b>Description</b></td><td><b>Disease</b></td><td><b>Ensembl_protein_ID</b></td>";

}
