

function plotGWASCatalog(phenoIndex){
    var plot=plots[phenoIndex];
    if($("#gwasCB"+phenoIndex).prop('checked'))
	 getGWASseries(plot);
    else
	 plot.rmGwasSeries();
    redrawPlot(plot);
}

function gwasTermFilterRegion(phenoIndex){
    var val=document.getElementById('gwasTermRegion'+phenoIndex).value;
    var color=$('#gwasColorSelectRegion'+phenoIndex+' :selected').text();
    var plot;
    var valTrimmed=val.trim();
    if(valTrimmed.length  < 1){
	      val=$('#gwasTerm'+phenoIndex).val();
	      val=document.getElementById('gwasTermRegion'+phenoIndex).value;
    }
    else{
	     if($('#genomePlots').is(':visible'))
	        plot=genomePlots[phenoIndex];
	    else
	     plot=plots[phenoIndex];
	var re=new  RegExp(val, 'i');
	var tmp=[];
	var gwasSeries;
	var gwas_series_present=0;
	var count=0;
	$.each(plot.seriesArray, function(i, series){
		if(series.gwasCatalog){
		    gwasSeries=series;
		    gwas_series_present=1;
		    var updated_d=[];
		    $.each(series.origData, function(j, dataEntry){
            if(dataEntry.length > 1){
			           if(dataEntry[3].match(re))
				            tmp.push(dataEntry);
			          else
				          updated_d.push(dataEntry);
            }
			});
		    gwasSeries.data=updated_d;
		    gwasSeries.origData=updated_d;
		}
	    });
	if(!(gwas_series_present))
	    alert("No GWAS catalog SNPs on the plot!");
	else{
	    if(tmp.length>0){
		//update labels of other gwas series
		updateGWASlabels(plot);
		var series=new Series(plot.seriesArray.length);
		series.addGwasCatData(tmp,color,val,gwasSeries);
		plot.addSeries(series);
		if($('#genomePlots').is(':visible')){
		    redrawGenomePlot(plot);
		}
		else{
		    redrawPlot(plot);
		}
	    //plot.addSeries(series);
	    //redrawPlot(plot);
	    //get all the GwasCatalog series, where gwasCatalog=true, set the label to: series.label="GWAS catalog: val"

	}
	else{
	    alert("Found nothing mathing the terms: "+val);
	}
	}
}
}

function gwasTermFilterGenome(phenoIndex){
    var val=document.getElementById('gwasTermGenome'+phenoIndex).value;
    var color=$('#gwasColorSelectGenome'+phenoIndex+' :selected').text();
    var plot;
    var valTrimmed=val.trim();
    if(valTrimmed.length  < 1){
        val=$('#gwasTerm'+phenoIndex).val();
    }
    else{
	     if($('#genomePlots').is(':visible'))
	        plot=genomePlots[phenoIndex];
	     else
	        plot=plots[phenoIndex];
	    var re=new  RegExp(val, 'i');
	    var tmp=[];
	    var gwasSeries;
	    var gwas_series_present=0;
	    var count=0;

	 $.each(plot.seriesArray, function(i, series){
	    if(series.gwasCatalog){
		      gwasSeries=series;
		      gwas_series_present=1;
		        var updated_d=[];
		          $.each(series.origData, function(j, dataEntry){
                if(dataEntry.length > 1){
                   if(dataEntry[3].match(re)){
			                 tmp.push(dataEntry);
		                   }
                  else{
			                 updated_d.push(dataEntry);
		                   }
                }
		        });
            gwasSeries.data=updated_d;
            gwasSeries.origData=updated_d;
  }
});
if(!(gwas_series_present)){
    alert("No GWAS catalog SNPs on the plot!");
}
else{
  if(tmp.length>0){
       updateGWASlabels(plot);
       var series=new Series(plot.seriesArray.length+1);
        series.addGwasCatData(tmp,color,val,gwasSeries);
     plot.addSeries(series);
     if($('#genomePlots').is(':visible')){
          redrawGenomePlot(plot);
      }
    else{
          redrawPlot(plot);
     }
  }
  else{
	    alert("Found nothing mathing the terms: "+val);
	}
}
}
}

function  updateGWASlabels(plot){
    $.each(plot.seriesArray, function(i, series){
		if(series.gwasCatalog){
		       series.label="GWAS catalog : "+series.terms+"("+series.origData.length+")";
		}
    });
}

function reset_y_axis(){
    var new_max=$("#y_max").val();
    if($('#genomePlots').is(':visible')){
	$.each(genomePlots, function(i, plot){
		$.each(plot.seriesArray, function(j, series){
			  plot.maxScore=new_max;
		    });
		redrawGenomePlot(plot);
	    });
    }
    else{
	    $.each(plots, function(i, plot){
		        $.each(plot.seriesArray, function(j, series){
            plot.maxScore=new_max;
		    });
		redrawPlot(plot);
	    });
    }
}

function plotGWASCatalogGenome(phenoIndex){
    var plot=genomePlots[phenoIndex];
    var already_added=0;
    if($("#gwasGenomeCB"+phenoIndex).is(":checked")){
         //only add if its not already been added
          $.each(plot.seriesArray, function(i, series){
              if(series.gwasCatalog){
                already_added=1; //gwas series already added
              }
          });
          if (! (already_added)){
            addGWASGenome(plot);
        }
          //addGWASGenome(plot, addGWASCatTable);
    }
    else{
	      plot.rmGwasSeries();
        redrawGenomePlot(plot);
    }
}

//function addGWASGenome(plot, callback){
function addGWASGenome(plot){
   var script=getGWASCatSnps_cgi;
    try{
	$.ajax({
		type: "GET",
		    url:script,
		    success : function(jsonfile){
		    try{
			$.getJSON(jsonfile, function(d){
				var series=new Series(plot.seriesArray.length);
				series.addGwasData(d);
				initColAndDisplay(plot.phenoIndex, series);
				plot.addSeries(series);
        plotGenome(plot);
      //  callback(d);
			});
		}
		catch(err){
		    alert("Error when getting GWAS json "+err);
		}
	    }

	});
    }
    catch(err){alert("Error when trying to get GWAS data: "+err);
    }
}

function getGWASseries(plot, mk_gwas_DataTable){
    var script=getGWASCatSnps_cgi+"?chr="+plot.chr;
    if(!($.isEmptyObject(gwas_data)) && (typeof(gwas_data.data) !== "undefined")){
	if ($("#gwasCB"+plot.phenoIndex).prop('checked')){
         addGWASseries(plot, gwas_data);
      }
      if(typeof mk_gwas_DataTable === "function"){
          mk_gwas_DataTable(gwas_data);
        }
    }
    else{
      try{
        $.ajax({
          type: "GET",
          url:script,
          success : function(jsonfile){
            try{
              $.getJSON(jsonfile, function(d){
		      gwas_data=d;
                    if ($("#gwasCB"+plot.phenoIndex).prop('checked')){
                      addGWASseries(plot, d);
                    }
                    if(typeof mk_gwas_DataTable === "function"){
                        mk_gwas_DataTable(d);
                      }
                    });
                  }
                  catch(err){
            alert("Error when getting GWAS json "+err);
          }
        }
  });
    }
    catch(err){
      alert("Error when trying to get GWAS data: "+err);
    }
  }
}

/*function getGWASseries(plot){
//    if(gwas_data.length > 0){
//    }
    var script=getGWASCatSnps_cgi+"?chr="+plot.chr;
    try{
	     $.ajax({
		    type: "GET",
	            url:script,
		    success : function(jsonfile){
		    try{
		    $.getJSON(jsonfile, function(d){
		          	addGWASseries(plot, d);
		    });
		}
		catch(err){
		    console.log("cant get json "+jsonFile);
		    alert("Error when getting GWAS json "+err);
		}
	    }

	});
    }
    catch(err){
	console.log("ERROR");
	alert("Error when trying to get GWAS data: "+err);
    }
}
*/

function addGWASseries(plot, d){
    var prevSeries=plot.seriesArray[plot.seriesArray.length-1];
    var typeIndex=prevSeries.typeIndex+1;
    var series=new Series(typeIndex, "circle", "unknown");
    if(typeof(d) !== "undefined"){
      series.addGwasData(d);
      initColAndDisplay(plot.phenoIndex,series);
      plot.addSeries(series);
      redrawPlot(plot);
   }
}


function initColAndDisplay(pi,series){
    var radius=1;
    series.color="grey";   //#D3D3D3"; //#grey";  #"#FF0000";

    var show_points=true;
    if(series.plot_type="point"){
    // if (!($("#gwasCB"+pi).prop('checked'))){
    //        show_points=false;
    //  }
	     series.points={show:show_points, radius: radius};
	     series.lines={show:false};
    }
}

function redrawGenomePlot(plot){
    plotGenome(plot);
}

function redrawPlot(plot){
    if(typeof(plot.ranges) != "undefined"){ //are we zoomed in?
	      plotSinglePlot(plot);
    	  zoomToRange(plot.ranges, plot);
       }
    else{
    	plotSinglePlot(plot);
    }
}



function  addGWASCatTable(d){
     //gwascat_genome
     var annot = $("#gwascat_genome");
     //annot.empty();
     annot.show();
     var table_id="gwasTable";
     annot.append("<h2 class=\"text-primary\" style=\"color:#08519C\">GWAS catalog table</h2>");
     var html = "<br><table id=\""+table_id+"\"><thead><th>gPos</th><th>Pos</th><th>SNP</th><th>pval</th><th>Or_beta</th><th>log10(p)</th><th>Disease</th><th>Rep.gene</th><th>pid</th></thead><tbody>";
     var count=0;
     	$.each(d.data, function(i, data){
            if(typeof(data[11]) !== "undefined"){
              gene=data[4].split(",")
              html+="<tr><td>"+data[0]+"</td><td>"+data[11]+":"+data[12]+"</td><td>"+data[2]+"</td><td>"+data[9]+"</td><td>"+parseFloat(data[10]).toFixed(2)+"</td><td>"+parseFloat(data[1]).toFixed(2)+"</td><td>"+data[3]+"</td>";
              html+="<td>"+gene[0]+"</td><td>"+data[6]+"</td></tr>";
              count++;
            }
      });
      html+="</tbody></table>";
      annot.append(html);
     mk_dataTable(table_id);
}
