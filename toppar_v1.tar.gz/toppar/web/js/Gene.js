

function Gene(data, chr){
  this.chr=data[0];
  this.bpStart=parseInt(data[1]);
  this.bpEnd=parseInt(data[2]);
  this.name=data[3];
  this.desc=data[4];
  this.strand=data[5];
 this.diseaseTooltip="...";
 if(typeof(data[6] != "undefined"))
     this.ensId=data[6];
 //this.protein_id=data[8];
 this.disease="";
    if(chr >= 1){ //region view
      this.chr=chr;
      if((typeof(data[8]) != "undefined")){
        var disease_array=data[8].split(";");
        var uniq_dis=unique(disease_array);
        var disOnDisplay=[];
        var disTooltip=[];
        //to limit the number of diseases displayed in the dataTable to 3
        if(uniq_dis.length > 3){
                $.each(uniq_dis, function(i, dis){
                    if(i < 3)
                       disOnDisplay.push(dis);
                    else
                        disTooltip.push(dis);
                });
                this.disease=disOnDisplay.join(";")+"...";
                this.diseaseTooltip="..."+disTooltip.join(";");
        }else{
          this.disease=uniq_dis.join(";");
          this.diseaseTooltip=this.disease;
      }
      }
      this.protein_id=data[7];
      //this.desc_ens=data[9];
    }
    else{ //genome view
      this.disease=data[6];
      this.protein_id=data[7];
      this.desc_ens=data[8];
      this.chr=data[9];
      this.chrBpStart=data[10];
      this.chrBpEnd=data[11];
    }
}

function Exon(data, gene, disease){
    this.bpStart=data[1];
    this.bpEnd=data[2];
    this.name=data[0];
    this.strand=data[3];
    this.gene=gene;
    this.disease=disease;
}

function TAD(data, chr){
  this.chr=chr;
  this.bpStart=data[0];
  this.bpEnd=data[1];
  this.strand=data[2];
}
