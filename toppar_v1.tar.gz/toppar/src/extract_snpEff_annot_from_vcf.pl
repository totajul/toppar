#!/usr/bin/perl

use strict;

&exit_usage unless $ARGV[0];

my $vcf=$ARGV[0];
my $grep="grep";
if($vcf =~ /gz$/){$grep="zgrep";}

open(IN, "$grep -v \"#\" $vcf |  cut -f1-8 | ") or die "Cant open $vcf \n";
my ($ac, $af, $an, $dp, $mq, $mq0, $gq_mean, $qq_stddev);

print "CHROM\tBEG\tID\tALT_ID\tA1\tA2\tTYPE\tGENE\tIMPACT\n";

while(<IN>){
    chomp();
    my ($chr, $pos, $id, $ref, $alt, $qual, $filter, $info)=split("\t", $_);
    my ($type,$gene,$impact);
    if($info =~ /ANN=([^;]*).*/){
	my @anno=split("\\|", $1);
	$type=$anno[1];$impact=$anno[2];$gene=$anno[3];
    }
    elsif($info =~ /\./){
	$type=".";$gene=".";
    }
    else{
	print "The info string does not match ANN \nINFO: $info\n";
	exit;
    }
    print "$chr\t$pos\t$id\t$chr:${pos}_${ref}/${alt}\t$ref\t$alt\t$type\t$gene\t$impact\n";
}


sub exit_usage{
print <<EOF;

 Usage:  $0 vcf_file

EOF
exit;    
}
