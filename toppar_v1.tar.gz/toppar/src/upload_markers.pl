#!/usr/bin/perl

use strict;
use Cwd;
use Time::HiRes qw(gettimeofday);
require "shared_func.pl";

my %Opt;
my %config;
my $Bin;    
my $no_markers;

sub upload_markers{
    %Opt=%{&get_Opt()};
    %config=%{&get_config()};
    $Bin=&get_Bin();
    $Opt{fields_ref}=&str2hash($Opt{req_fields});
    my $cwd=cwd;
    my $opt_ref=&check_col_pos(\%Opt, $Opt{infile});
    my %markers=();
    my $markers_ref=&add_markers2($opt_ref,\%markers);
    my ($file, $timestamp)=&write_marker_file($markers_ref);
    &upload_marker_file($file, $timestamp);
    chdir($cwd);
}

sub write_marker_file{
    my $markers_ref=shift;
    my %markers=%{$markers_ref};
    my $strand="1";
    if(!(-e $Opt{outdir})){ system("mkdir $Opt{outdir}");}
    my $timestamp=&get_timestamp();
    my $base="markers.".$Opt{pop}.".".$Opt{build}.".".$timestamp.".sql";
    my $file=$Opt{outdir}.$base;
    open(OUT, ">$file") or die "Cant open $file for writing $! \n";
    print "Uploading ".scalar (keys %markers)."\n";
    my $genome_build=getset_genome_build_id($Opt{build});
    $no_markers=0;
    foreach my $chr (keys %markers){
	foreach my $beg (sort {$a <=> $b}  keys %{$markers{$chr}}){
	    foreach my $name (keys %{$markers{$chr}{$beg}}){
		print OUT "$name,$chr,$beg,$strand,$genome_build\n";
		$no_markers++;
	    }
	}
    }
    close(OUT);
    return ($file, $timestamp);
#    print "\nTotal number of markers uploaded to the database: [$no_markers]\n\n";
}

sub upload_marker_file{
    my ($file, $timestamp)=@_;
    my $tmp_table="marker_tmp".$timestamp;
    my $sql_tmp_table="drop table if exists $tmp_table; create table $tmp_table LIKE marker";
    &execute_sql($sql_tmp_table, "Tmp marker table created." , "Could not create tmp table $tmp_table.");
    my $loadfile=$Opt{outdir}."load_table_".$tmp_table.".sql";

    open(OUT, ">$loadfile") or die "Couldnt open $loadfile \n";
    print OUT "load data local infile '$file'\n";
    print OUT "into TABLE $tmp_table\n";
    print OUT "FIELDS TERMINATED BY ','\n";
    print OUT "LINES TERMINATED BY '\\n'\n";
    print OUT "(name, chromosome, bp_position, strand,genome_build_id)\n";
    close(OUT);

    my $cmd="-u $config{user} -p$config{password} $config{database} < $loadfile";
    #if not on MAC os add : --local-infile=1                                                                                                           
    my $os=$Config{osname};
    my $mysql=$config{mysql};
    if($os !~ /darwin/i){
        $mysql=$mysql." --local-infile=1";
    }
    $cmd=$mysql." ".$cmd;

    &execute_cmd($cmd, "Insert into TMP marker table completed.", "Could not insert data into tmp table.");
    my $sql="INSERT INTO marker (name, chromosome, bp_position, strand,genome_build_id) select name,chromosome,bp_position,strand,genome_build_id  from $tmp_table ON DUPLICATE KEY UPDATE bp_position=VALUES(bp_position)";
    print "SQL $sql \n";
    &execute_sql($sql, "Insert into marker table completed", "Could not insert data from temp marker table into the main marker table.");
    #clean-up
#    $sql="drop table $tmp_table";
#     print "$sql \n";
     &execute_sql($sql, "Tmp table dropped!", "Could not drop tmp table [$tmp_table].");
     &execute_cmd("rm $file", "The tmp file [$file] was successfully deleted!", "Could not delete $file \n");
    &rm_file($file);
    &rm_file($loadfile);
#print "\nTotal number of markers uploaded to the database: [$no_markers]\n\n"; 
}


sub add_markers2{
    my ($opt_ref,$markers_ref)=@_;
    my %Opt=%{$opt_ref};
    my $in=$Opt{infile};
    return &add_markers_by_columns($opt_ref, $in,$markers_ref);
}

1;

