#!/usr/bin/perl

use strict;
require "shared_func.pl";

sub upload_markers{
    my ($opt_ref, $conf_ref, $Bin)=@_;
    %Opt=%{$opt_ref};
    $Opt{fields_ref}=&str2hash($Opt{req_fields});
    my $opt_ref=&check_col_pos(\%Opt, $Opt{infile});
    my %markers=();
    my $markers_ref=&add_markers2($opt_ref,\%markers);
    &write_marker_files($opt_ref,$conf_ref, $Bin,$markers_ref);
}

sub write_marker_files{
    my ($opt_ref, $conf_ref,$Bin,$markers_ref)=@_;
    my %Opt=%{$opt_ref};
    my %config=%{$conf_ref};
    my %markers=%{$markers_ref};
    my $strand="1";
    if(!(-e $Opt{outdir})){ system("mkdir $Opt{outdir}");}
    my $marker_f=$Opt{outdir}."/markers.".$Opt{pop}.".".$Opt{build}.".sql";
    my $marker_mapping_f=$Opt{outdir}."/marker_mappings\.".$Opt{pop}.".".$Opt{build}.".sql";
    my $marker_map=$Opt{outdir}."/marker_map.".$Opt{pop}.".".$Opt{build}.".tsv";
    open(M_OUT, ">$marker_f") or die "Cant open $marker_f for writing \n";
    open(MM_OUT, ">$marker_mapping_f") or die "Cant open $marker_mapping_f for writing \n";
    open(MAP, ">$marker_map") or die "Cant open $marker_map for writing \n";
    print MAP "CHR\tPOS\tNAME\n";
    my $no_markers=0;
    foreach my $chr (keys %markers){
	foreach my $beg (keys %{$markers{$chr}}){
	    foreach my $name (keys %{$markers{$chr}{$beg}}){
		print MM_OUT "INSERT INTO marker_mapping (marker_id, chromosome, bp_position, strand) values  ((SELECT marker_id from marker where name=\"$name\"), $chr, $beg, $strand) ON DUPLICATE KEY UPDATE chromosome=\"$chr\",bp_position=$beg;\n"; 
		print M_OUT "INSERT INTO marker (name, genome_build_id) values (\"$name\", (SELECT genome_build_id from genome_build where name=\"$Opt{build}\")) ON DUPLICATE KEY UPDATE name=\"$name\";\n"; 
		print MAP "$chr\t$beg\t$name\n";
		$no_markers++;
	    }
	}
    }
    close(MM_OUT);close(M_OUT);close(MAP);
    my $sql_m="mysql -u $config{user} -p$config{password} $config{database} < $marker_f";
    my $sql_mm="mysql -u $config{user} -p$config{password} $config{database} < $marker_mapping_f";
    print "\nUploading MARKERS to the database...\n";
    &execute_command($sql_m);
    print "\nUploading MARKER MAPPINGS to the database\n"; 
    
    &execute_command($sql_mm);
    print "\nTotal number of markers uploaded to the database: [$no_markers]\n\n";
 
}



sub add_markers2{
    my ($opt_ref,$markers_ref)=@_;
    my %Opt=%{$opt_ref};
    my $in=$Opt{infile};
    return &add_markers_by_columns($opt_ref, $in,$markers_ref);
}

1;
#print "\nmarker file:\t\t[$marker_f]\nmarker mapping file:\t [$marker_mapping_f]\n\n";

