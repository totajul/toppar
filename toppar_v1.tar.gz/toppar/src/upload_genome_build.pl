#!/usr/bin/perl

use strict;
use Cwd;
require "shared_func.pl";

require "get_genes.pl"; 
require "get_exons.pl";

my %Opt;
my %config;
my $Bin;

sub upload_genome_build{
    my $build=shift;
    my %available_bundles=("GRCh38" => 1, "GRCh37" => 1, "NCBI36" =>1);
    if($available_bundles{$build}){
	my $genome_build_id=&getset_genome_build_id($build);
	my $build_dir=&get_resource_dir.$build."/";
	if(!(-e $build_dir)){
	    &get_resource_bundle($build);
	}
	#check whether the 3 files exist (genes, exons and chr lengths)
	my $genes=$build_dir."mart_human_genes_${build}.tsv";
	my $exons=$build_dir."mart_human_exons_${build}.tsv";
	my $chr_lengths=$build_dir."chr.lengths.${build}.tsv";
	if(&check_if_files_exist($genes, $exons, $chr_lengths)){
	    my $genefile=&read_and_rewrite_genes_file($genes, $genome_build_id);
	    &upload_gene_file($genefile);
	    my $genes2id=&get_gene_ids_from_db($genome_build_id);
	    my $exonfile=&read_and_rewrite_exons_file($exons, $genes2id);
	    print "exonfile $exonfile \n";
	    &upload_exon_file($exonfile);
	    &get_and_insert_chr_lengths($chr_lengths,$genome_build_id);
	}
    }
    else{
	print "\n*** There is no pre-made bundle for build: [$build]. *** \n\nBundles exist for these  builds: ".join(", ", (keys %available_bundles))."\n\nIf you want to upload a different build, use the [upload_genes_exons] function and provide with your own gene and exon annotation files \n\n";
	exit;
    }
}

sub get_and_insert_chr_lengths(){
    my ($chr_lengths_file, $genome_build_id)=@_;
    my %Opt=%{&get_Opt()};
    my %config=%{&get_config};
    my $genes_file;
    print "*** Inserting CHROMOSOME lenghts *** \n";
    my %chr_lengths=();
    open(IN, $chr_lengths_file) or die "Cant open file $chr_lengths_file\n";
    my $dupl_entries=0;
    while(<IN>){
        if($_ !~ /^#/){
            my ($chr, $chrLength, @rest)=split("\t", $_);
            $chrLength =~ s/,//g;
            $chr_lengths{$chr}=$chrLength;
            my $sql="INSERT INTO chromosome (name, genome_build_id, length) values (\"$chr\",$genome_build_id,\"$chrLength\");";
            my $cmd="echo '$sql' | ".&mysql();
            my @out=qx($cmd 2>&1);
            if( $out[0] =~ /Using a password on the command line interface can be insecure/){
                if($out[1] =~ /Duplicate entry/){
                    if(! $dupl_entries){
                        print "Duplicate entry. Chromosome length has already been inserted for chr $chr";
                        $dupl_entries=1;
                    }
                    else{ print ",$chr";
                    }
		}
                elsif ($out[1] =~ /\S+/){ # report the message:		    
		    print "The cmd:\n$cmd\n gives the following error: \n$out[1]; \n\n";exit;
                }
            }
        }
    }
    print "\n";
    if(! $dupl_entries){
        print "Success. Chromosome lengths were inserted.\n";
    }
    close(IN);
}


sub get_gene_ids_from_db{
    my $build_id=shift;
    my %ens_gene_id2db_id=();
    my $cmd="echo 'SELECT gene_id, ensembl_id from genes where genome_build_id=$build_id;' | ".&mysql();
    print "Getting gene ids from the database... \n";
    my $out=qx($cmd 2>&1);
    my @out=split("\n", $out);
    for (my $i=1; $i<$#out+1; $i++){
        my ($id, $ens_id)=split("\t", $out[$i]);
        $ens_gene_id2db_id{$ens_id}=$id;
    }
    return \%ens_gene_id2db_id;
}

sub check_if_files_exist{
    my ($genes, $exons, $chr_lengths)=@_;
    if(!(-e $genes)){
	print "Cant find the file [$genes]. Aborting! \n"; return 0;
    }
    if(!(-e $exons)){
        print "Cant find the file [$exons]. Aborting! \n"; return 0;
    }
    if(!(-e $chr_lengths)){
        print "Cant find the file [$chr_lengths]. Aborting! \n"; return 0;
    }   
    return 1;
}

1;
