#!/usr/bin/perl

use strict;

my %snps=();

my $infile=$ARGV[0];
#my $outfile="$infile.MAF";

&exit_usage unless $ARGV[0];

open(IN, $infile) or die "Cant open $infile \n";
my $h=<IN>;
while(<IN>){
    chomp();
    my ($chr, $beg, $marker_id, $alt_id, $type, $gene)=split("\t", $_);
    $snps{$marker_id}=$_;
}
close(IN);

my $g1000="~/Desktop/1000GENOMES-phase_3.vcf.gz";


open(IN, "zless $g1000 | ") or die "Couldnt open $g1000 \n";

print "CHR\tBEG\tMARKER_ID\tALT_ID\tA1\tA2\tTYPE\tGENE\tTSA\tMAF\tMAC\tEAS_AF\tAMR_AF\tAFR_AF\tEUR_AF\tSAS_AF\n";
while(<IN>){
    chomp();
    if($_ !~ /^#/){
	my ($chr, $pos, $id, $ref, $alt, $qual, $filt, $info)=split("\t", $_);
	if($snps{$id}){
	    my $maf="NA";my $mac="NA";my $eas_af="NA";my $amr_af="NA";my $afr_af="NA";my $eur_af="NA";my $sas_af="MAF";my $tsa="NA";
	    my @data;
	    if($info =~ /TSA=([^;]*);.*MAF=([^;]*);MAC=([^;]*);.*EAS_AF=([^;]*);AMR_AF=([^;]*);AFR_AF=([^;]*);EUR_AF=([^;]*);SAS_AF=([^;]*)/){
		$tsa=$1;$maf=$2;$mac=$3;$eas_af=$4;$amr_af=$5;$afr_af=$6;$eur_af=$7;$sas_af=$8;

	    }
	    elsif($info =~ /TSA=([^;]*);.*EAS_AF=([^;]*);AMR_AF=([^;]*);AFR_AF=([^;]*);EUR_AF=([^;]*);SAS_AF=([^;]*)/){
		$tsa=$1; $eas_af=$2; $amr_af=$3;$afr_af=$4;$eur_af=$5;$sas_af=$6; 
		
		    print $snps{$id}."\t$1\tNA\tNA\t$2\t$3\t$4\t$5\t$6\t$7\t$8";
	    }
	    push(@data, $tsa,$maf,$mac,$eas_af,$amr_af,$afr_af,$eur_af,$sas_af);
	    print $snps{$id}."\t".join("\t", @data)."\n";

	 
	}
    }
}


#open(OUT, ">$outfile") or die "Cant open $outfile for writing \n";
#print "CHR\tBEG\tMARKER_ID\tALT_ID\tTYPE\tGENE\tTSA\tMAF\tMAC\tEAS_AF\tAMR_AF\tAFR_AF\tEUR_AF\tSAS_AF\n";

#foreach my $snp (keys %snps){
 #   print "$snps{$snp}\n";
#}

#print "\n\nResults printed to outfile $outfile \n\n";

sub exit_usage{
    print <<EOF;

Usage: $0 [marker_infile]

Example: $0 ibd_markers_annot_ex.tsv
EOF
exit
}
