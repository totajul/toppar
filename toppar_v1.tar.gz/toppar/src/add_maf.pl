#!/usr/bin/perl

use strict;

my %snps=();

my $infile=$ARGV[0];
#my $outfile="$infile.MAF";

&exit_usage unless $ARGV[0];

open(IN, $infile) or die "Cant open $infile \n";
my $h=<IN>;
while(<IN>){
    chomp();
    my ($chr, $beg, $marker_id, $alt_id, $type, $gene, $impact)=split("\t", $_);
    $snps{$marker_id}=$_;
}
close(IN);

my $g1000="/Users/tota/repository/toppar_backup/annotation/1000GENOMES-phase_3.vcf.gz";
#../toppar_git/resources/1000GENOMES-phase_3.vcf.gz";

open(IN, "zless $g1000 | ") or die "Couldnt open $g1000 \n";

print "CHR\tBEG\tMARKER_ID\tALT_ID\tA1\tA2\tTYPE\tGENE\tIMPACT\tTSA\tMAF\tMAC\tEAS_AF\tAMR_AF\tAFR_AF\tEUR_AF\tSAS_AF\n";
while(<IN>){
    chomp();
    if($_ !~ /^#/){
	my ($chr, $pos, $id, $ref, $alt, $qual, $filt, $info)=split("\t", $_);
	if($snps{$id}){
	    my $maf="NA";my $mac="NA";my $eas_af="NA";my $amr_af="NA";my $afr_af="NA";my $eur_af="NA";my $sas_af="NA";my $tsa="NA";
	    $info.=";"; #add this so the last variable also  matches the REGEX below.
	    my @data;
	    if($info =~ /TSA=([^;]*);/){$tsa=$1;}
	    if($info =~ /MAF=([^;]*);/){$maf=$1;}
	    
	    if($info =~ /MAC=([^;]*);/){$mac=$1;}
	    if($info =~ /EAS_AF=([^;]*);/){$eas_af=$1;}
	    if($info =~ /AMR_AF=([^;]*);/){$amr_af=$1;}
	    if($info =~ /AFR_AF=([^;]*);/){$afr_af=$1;}
	    if($info =~ /EUR_AF=([^;]*);/){$eur_af=$1;}
	    if($info =~ /SAS_AF=([^;]*);/){$sas_af=$1;}    
	    push(@data, $tsa,$maf,$mac,$eas_af,$amr_af,$afr_af,$eur_af,$sas_af);
	    print $snps{$id}."\t".join("\t", @data)."\n";
	}
    }
}

sub exit_usage{
    print <<EOF;

Usage: $0 [marker_infile]

Example: $0 ibd_markers_annot_ex.tsv
EOF
exit
}
