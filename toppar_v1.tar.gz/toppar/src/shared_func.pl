#!/usr/bin/perl

use strict;
use Cwd;
use File::Basename;
use Time::HiRes qw(gettimeofday);
use Config;
#use Math::Round;

my %Opt=();
my %config=();
my $Bin; 

require "database_func.pl";

sub set_Opt(){
    my $opt_ref=shift;
    %Opt=%{$opt_ref};
}
sub get_Opt(){
    return \%Opt;
}
sub set_Bin(){
    my $bin=shift;
    $Bin=$bin;
}
sub get_Bin(){
   return $Bin;
}

sub set_config(){
    my $conf_ref=shift;
    %config=%{$conf_ref};
}
sub get_config(){
    return \%config;
}

sub check_col_pos{
    my ($opt_ref,$file)=@_;
    my %Opt=%{$opt_ref};   
    if($Opt{output_vcf}){
	$Opt{req_fields}.=",".$Opt{opt_fields};
    }
    if($Opt{desc_fields}){
	$Opt{req_fields}.=",".$Opt{desc_fields};
    }
    ### this line ruins it alll!!!!!!! 
    $Opt{fields_ref}=&str2hash($Opt{req_fields},\%Opt);
    my %fields=%{$Opt{fields_ref}};
    my $alt_col_names_ref=&set_alt_col_names();
    my %alt_col_names=%{$alt_col_names_ref};
    $file =~ s/^~/$ENV{HOME}/;    
    if (-e $file){
	my $cat="cat";
	if($Opt{infile}=~ /gz$/){$cat="zcat";}
	open(IN, "$cat $file | ") or die "Cant open infile $file \n";
	my $h=<IN>;
	$h =~ s/\#//; $h =~ s/\n//;
	my @cols=split("\t", $h);
	my %col_pos=();
      	for (my $i=0; $i<$#cols+1;$i++){$col_pos{$cols[$i]}=$i+1;}		
        #check whether required fields are in the file
	foreach my $f (keys %fields){
	    if($col_pos{$f} ){ 
		$fields{$f}=$col_pos{$f};
	    }
	}
	my $all_found=&check_fields(\%fields);
	#try with alternative column names 
	if(! ($all_found)){
	    foreach my $f (keys %fields){ 
		my $found=0;my $lookup=$f;
		foreach my $alt_col (keys %{$alt_col_names{$f}}){
		    if($col_pos{$alt_col}){ $fields{$f}=$col_pos{$alt_col};}
		}
	    }
	}
	$all_found=&check_fields(\%fields);	
	if(!($all_found)){
	    print "\nCant find the following columns: ";foreach my $fi (keys %fields){ if($fields{$fi} == "NA"){print "[$fi] ";}}
	    print "in file $file \n\n";
	    exit;
	}
    }
    $Opt{fields_ref}=\%fields;
    return \%Opt;
}
sub get_timestamp{
    return int(gettimeofday*1000);
    
}

sub check_fields{
    my $fields_ref=shift;
    my $all_found=1;
    my %fields=%{$fields_ref};
    foreach my $f (keys %fields){
	if($fields{$f} ==  "NA" ){
	    $all_found=0;
	}
    }
    return $all_found;
}
sub str2hash{
    my $cols=shift;
    my %c_hash=();
    my @tmp=split(",", $cols);
    foreach my $t (@tmp){
	$c_hash{$t}="NA";
    }
    return \%c_hash;
}


sub write_scanfile{
    my ($opt_ref, $file, $result_ref,$func)=@_;
    my %Opt=%{$opt_ref};
    my $base=basename($file);
    my $max_points_condensed=2000;
   if(!($Opt{outdir} =~ /\/$/)){
	$Opt{outdir}.="/";
    }
    my $outfile=$Opt{outdir}.$base; 
    $base =~ s/\.$Opt{sfx}//;
    $outfile =~ s/$Opt{sfx}/toppar/;
    my $condfile=$outfile."_cond";
    (my $label = $base) =~ s/_/\./g;
    my $header="genome_subscan_id,marker_id,score";
    if(!$Opt{pheno}){
	my @bits=split("_", $base);
	$Opt{pheno}=$bits[0];
    }
    my $genome_scan_id=&get_set_genomescan_id($Opt{pop}, $Opt{pheno}, $Opt{build});
    my $genome_subscan_id=&get_set_genome_subscan_id($genome_scan_id, $label, \%Opt);
    my $genome_build_id=&getset_genome_build_id($Opt{build});
    open(OUT, ">$outfile") or die "Cant open file ... [$outfile] for writing $! \n";
    open(COND, ">$condfile") or die "Cant open $condfile for writing $! \n";
    if($func =~ /single/){ $header.=",description"; }
    print OUT $header."\n";
    my %results=%{$result_ref};
    my $no_of_markers=keys %results;
    my $interval=int(($no_of_markers/$max_points_condensed)+0.5);

#round($no_of_markers/$max_points_condensed)*2; #Round to nearest integer and multiply by 2 since we want 2 datapoints per interval (min and max)
    my $interval_count=0; my $min=100; my $max=0; my $max_id; my $min_id;
    foreach my $name (keys %results){
	my $score=$results{$name}{log10};
	my $res=$genome_subscan_id.",".$name.",".$score;
	if($func =~ /single/){$res.=",".$results{$name}{desc};}
	print OUT $res."\n";
	if($score > $max){
	    $max=$score; $max_id=$name;
	}
	if($score < $min){
	    $min=$score; $min_id=$name;
	}
	$interval_count++;
	if($interval_count == $interval){
	    #my $SEL_CHR="SELECT DISTINCT chromosome from marker where marker_id=(SELECT DISTINCT marker_id from marker where name=\"$min_id\" AND genome_build_id=$genome_build_id)";
	    #my $SEL_POS="SELECT DISTINCT bp_position from marker where marker_id=(SELECT DISTINCT marker_id from marker where name=\"$min_id\" AND genome_build_id=$genome_build_id)";
	    #print COND "insert into condensed (genome_subscan_id, chromosome, bp_position, score) values ($genome_subscan_id, ($SEL_CHR), ($SEL_POS), $min) on duplicate key update score=values(score);\n";

	    my $SEL_CHR="SELECT DISTINCT chromosome from marker where marker_id=(SELECT DISTINCT marker_id from marker where name=\"$max_id\" AND genome_build_id=$genome_build_id)";
            my $SEL_POS="SELECT DISTINCT bp_position from marker where marker_id=(SELECT DISTINCT marker_id from marker where name=\"$max_id\" AND genome_build_id=$genome_build_id)";
            print COND "insert into condensed (genome_subscan_id, chromosome, bp_position, score) values ($genome_subscan_id, ($SEL_CHR), ($SEL_POS), $max) on duplicate key update score=values(score);\n";
	    
            #reset 
	    $interval_count=0;
	    $max=0; $max_id="";
	    $min=100; $min_id="";
	}
    }
    close(OUT);close(COND);
    return ($outfile, $condfile);
}


#upload scan files
sub upload_scanfile{
    my $file=shift;
    my $base=basename($file);
    my $file=$Opt{outdir}.$base;
    my $timestamp=&get_timestamp();
    
    my $tmp_table="genome_subscan_results_tmp".$timestamp;
    my $sql="drop table if exists $tmp_table; create table $tmp_table (genome_subscan_id int(11),marker_id varchar(100),score float,description varchar(200))ENGINE=innodb DEFAULT CHARSET=latin1";
 
    &execute_sql($sql, "Tmp table created." , "Could not create tmp table $tmp_table.");

    my $loadfile=$Opt{outdir}."load_table_".$tmp_table.".sql";

    open(OUT, ">$loadfile") or die "Couldnt open $loadfile \n";
    print OUT "load data local infile '$file'\n";
    print OUT "into TABLE $tmp_table\n";
    print OUT "FIELDS TERMINATED BY ','\n";
    print OUT "LINES TERMINATED BY '\\n'\n";
    print OUT "IGNORE 1 LINES\n";
    close(OUT);

    my $cmd="-u $config{user} -p$config{password} $config{database} < $loadfile";
    
    #if not on MAC os add : --local-infile=1
    my $os=$Config{osname};
     my $mysql=$config{mysql};
    if($os !~ /darwin/i){
	$mysql=$mysql." --local-infile=1";
    }
    $cmd=$mysql." ".$cmd;
   
    &execute_cmd($cmd, "Insertion of data complete.", "Could not insert data into tmp table.");
  
    my $updatefile=$Opt{outdir}."update_table_".$tmp_table.".sql";
    
    open(OUT, ">$updatefile") or die "couldnt open $updatefile \n";
    print OUT "UPDATE $tmp_table, marker\n";
    print OUT "SET $tmp_table.marker_id=marker.marker_id\n";
    print OUT "WHERE $tmp_table.marker_id=marker.name\n";
    close(OUT);

    
    $cmd="-u $config{user} -p$config{password} $config{database} < $updatefile";
    $cmd=$mysql." ".$cmd;  
    &execute_cmd($cmd, "Marker names converted to marker_ids.", "Something went wrong when trying to map marker names to marker ids");
    
  
    $sql="ALTER TABLE $tmp_table MODIFY marker_id int(11)";  
    &execute_sql($sql, "Altered table", "Could not convert marker_ids to integers. Did you perhaps forget to upload the markers?");
    

    $sql="INSERT INTO genome_subscan_results (genome_subscan_id, marker_id, score, description) SELECT genome_subscan_id, marker_id, score, description from $tmp_table";
    &execute_sql($sql, "Insert complete", "Could not insert data from temp table into the main table.");
   
    $sql="drop table $tmp_table";
    &execute_sql($sql, "Tmp table dropped!", "Could not drop tmp table [$tmp_table].");
    &rm_file($updatefile);
    &rm_file($loadfile);
}


sub set_alt_col_names{
    my %alt_col_names=();
    $alt_col_names{"A1"}{"REF"}=1;
    $alt_col_names{"A2"}{"ALT"}=1;
    $alt_col_names{"A1"}{"A1_effect"}=1;
    $alt_col_names{"A2"}{"A2_other"}=1;
    $alt_col_names{"CHROM"}{"CHR"}=1;
    $alt_col_names{"CHROM"}{"CHROMOSOME"}=1;
    $alt_col_names{"BEG"}{"BEGIN"}=1;
    $alt_col_names{"BEG"}{"BP"}=1;
    $alt_col_names{"BEG"}{"POS"}=1;
    $alt_col_names{"MARKER_ID"}{"NAME"}=1;
    $alt_col_names{"MARKER_ID"}{"MARKER"}=1;
    $alt_col_names{"MARKER_ID"}{"ID"}=1;
    $alt_col_names{"MARKER_ID"}{"SNP"}=1;
    $alt_col_names{"PVALUE"}{"PVAL"}=1;
    return \%alt_col_names;
}

sub add_markers_by_columns{
    my ($opt_ref, $f,$markers_ref)=@_;
    my %markers=%{$markers_ref};
    my $opt_ref=&check_col_pos(\%Opt, $f);
    my ($cut, $data_pos)=&get_ordered_col_index($opt_ref);
    my %data_pos=%{$data_pos};
    my $cat="cat";if($f =~ /gz$/){$cat="zcat";}
    open(IN, "$cat $f | $cut |") or die "Cant open file $f\n";
    (my $h= <IN>) =~ s/\#//;
    while(<IN>){
	chomp();
	my @data =split(" ",$_);
	my $chrom=$data[$data_pos{CHROM}];
	if($chrom =~ /X/){
	    $chrom="23";
	}
	my $beg=$data[$data_pos{BEG}];
	my $marker_id=$data[$data_pos{MARKER_ID}];
	my $ref="NA";
	my $alt="NA";
	if(($data[$data_pos{A1}]) && ($data[$data_pos{A1}] !~ /(I|D)/)){$ref=$data[$data_pos{A1}];}
	if(($data[$data_pos{A2}]) && ($data[$data_pos{A2}] !~ /(I|D)/)){$alt=$data[$data_pos{A2}];}
	my $name;
	if($marker_id =~ /\d+:\d+_\S+.*_(rs\S+)/){
                $name=$1;
	}
	elsif($marker_id =~ /(.+):(\d+)_\S+/){
	    $name="$1_$2";
	}
	else{
	    $name=$marker_id;
	}
	if($beg =~ /\d+/){
	    $markers{$chrom}{$beg}{$name}{ALT}=$alt;
	    $markers{$chrom}{$beg}{$name}{REF}=$ref;
	}
    }
    return \%markers;   
}

sub get_ordered_col_index{
    my $opt_ref=shift;
    my %Opt=%{$opt_ref};
    my %fields=%{$Opt{fields_ref}};
    #get ordered col indeces
    my $cut="cut -f ";
    my %data_pos=();
    my $i=0;
    foreach my $col (sort {$fields{$a} <=> $fields{$b}} keys %fields){
	$cut.=$fields{$col}.",";
        $data_pos{$col}=$i;
        $i++;
    }$cut =~ s/,$//;
    return ($cut,\%data_pos);
}


sub rm_file{
    my ($file)=@_;
    my $cmd="rm ".$file;
    my $out=qx($cmd 2>&1);
    if($out =~ /ERROR/){
        print "Could not remove file $file. \nERROR: $out \n";

    }
    #else{#print "\nSuccess! $file was removed\n\n";}
}

sub get_resource_bundle{
    my $build=shift;
    my $resource_dir=&get_resource_dir();
    if(!( -e $resource_dir)){
        `mkdir -p $resource_dir`;
    }
    my $wget="wget $config{toppar_git_url}/resources/${build}.tar.gz  -P $resource_dir";
    print "\n\n*** Getting the resource bundle for genome build [${build}] *** \n\n";
    print "$wget\n";
    my $out_wget=qx($wget 2>&1); #handle error here                                                                                                                                                   
    print "Untar the bundle: \n";
    my $untar="tar -zxvf $resource_dir/${build}.tar.gz -C $resource_dir";
    print "$untar\n";
    my $out_untar=qx($untar 2>&1);
}

sub get_resource_dir{
    my %config=%{&get_config()};
    my $resource_dir= $config{resource_dir};
#if($resource_dir =~ /toppar_home/){
	#$resource_dir =~ s/toppar_home/$Bin/;
    #}
    $resource_dir =~ s/\/\//\//g;
    if($resource_dir !~ /\/$/){
	$resource_dir.="/";
    }
    return $resource_dir;
}

1;
#print "\nmarker file:\t\t[$marker_f]\nmarker mapping file:\t [$marker_mapping_f]\n\n";

