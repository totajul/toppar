#!/usr/bin/perl

use strict;
use Cwd;
use File::Basename;

sub check_col_pos{
    my ($opt_ref,$file)=@_;
    my %Opt=%{$opt_ref};
   
    if($Opt{output_vcf}){
	$Opt{req_fields}.=",".$Opt{opt_fields};
    }
    if($Opt{desc_fields}){
	$Opt{req_fields}.=",".$Opt{desc_fields};
    }
    ### this line ruins it alll!!!!!!! 
    $Opt{fields_ref}=&str2hash($Opt{req_fields},\%Opt);
    my %fields=%{$Opt{fields_ref}};
    my $alt_col_names_ref=&set_alt_col_names();
    my %alt_col_names=%{$alt_col_names_ref};
    $file =~ s/^~/$ENV{HOME}/;    
    if (-e $file){
	my $cat="cat";
	if($Opt{infile}=~ /gz$/){$cat="zcat";}
	open(IN, "$cat $file | ") or die "Cant open infile $file \n";
	my $h=<IN>;
	$h =~ s/\#//; $h =~ s/\n//;
	my @cols=split("\t", $h);
	my %col_pos=();
      	for (my $i=0; $i<$#cols+1;$i++){$col_pos{$cols[$i]}=$i+1;}		
        #check whether required fields are in the file
	foreach my $f (keys %fields){
	    if($col_pos{$f} ){ 
		$fields{$f}=$col_pos{$f};
	    }
	}
	my $all_found=&check_fields(\%fields);
	#try with alternative column names 
	if(! ($all_found)){
	    foreach my $f (keys %fields){ 
		my $found=0;my $lookup=$f;
		foreach my $alt_col (keys %{$alt_col_names{$f}}){
		    if($col_pos{$alt_col}){ $fields{$f}=$col_pos{$alt_col};}
		}
	    }
	}
	$all_found=&check_fields(\%fields);	
	if(!($all_found)){
	    print "\nCant find the following columns: ";foreach my $fi (keys %fields){ if($fields{$fi} == "NA"){print "[$fi] ";}}
	    print "in file $file \n\n";
	    exit;
	}
    }
    $Opt{fields_ref}=\%fields;
    return \%Opt;
}

sub check_fields{
    my $fields_ref=shift;
    my $all_found=1;
    my %fields=%{$fields_ref};
    foreach my $f (keys %fields){
	if($fields{$f} ==  "NA" ){
	    $all_found=0;
	}
    }
    return $all_found;
}
sub str2hash{
    my $cols=shift;
    my %c_hash=();
    my @tmp=split(",", $cols);
    foreach my $t (@tmp){
	$c_hash{$t}="NA";
    }
    return \%c_hash;
}


sub write_scanfile{
    my ($opt_ref, $file, $result_ref,$func)=@_;
    my %Opt=%{$opt_ref};
    my $outfile=$Opt{outdir}."/".basename($file); 
    $outfile =~ s/$Opt{sfx}/gscan/;
    my $header="locus\tpval";
    open(OUT, ">$outfile") or die "Cant open file [$outfile] for writing \n";
    if($func =~ /single/){ $header.="\tdescription"; }
    print OUT $header."\n";
    my %results=%{$result_ref};
    foreach my $name (keys %results){
	my $res=$name."\t".$results{$name}{pval};
	if($func =~ /single/){$res.="\t".$results{$name}{desc};}
	print OUT $res."\n";
    }
    close(OUT);
    return $outfile;
}
#upload scan files
sub upload_scanfiles{
    my ($files_ref, $opt_ref, $conf_ref, $Bin)=@_;
    my @files=@{$files_ref};
    my %config=%{$conf_ref};
    my %Opt=%{$opt_ref};
    foreach my $f (@files){
	my $base=basename($f);
	$base =~ s/\.$Opt{sfx}//;
	$base =~ s/\.gscan//;
	my @bits=split("_", $base);
	`module load R/3.0`;
	my $r_cmd="Rscript $Bin/src/pval2log10.R $f";
	print "$r_cmd\n";
	`$r_cmd`;
	my $file_log10="$f.log10";
	if(-e $file_log10){`rm $f`;};
	my $label = join(".", @bits);
        my $file_label=$f.".label";
	my $sed_cmd="sed 's/log10/$label/' $file_log10 > $file_label";
	print "$sed_cmd \n";
	`$sed_cmd`;
	chdir($Bin."/upload/");
	my $cmd;
	if($Opt{pheno}){
	    $cmd="sh $Bin/upload/upload.sh db=$config{database} pop=$Opt{pop} gscan=$file_label build=$Opt{build} pheno=$Opt{pheno} labels=$label";
	}
	else{
	    (my $pheno = $base ) =~ s/([^_]*)_.*/$1/;
	    $cmd="sh $Bin/upload/upload.sh db=$config{database} pop=$Opt{pop} gscan=$file_label build=$Opt{build} pheno=$pheno labels=$label";
	}
	my @filter_headers=@{$Opt{filter_headers}};
	for (my $i=1; $i< $#filter_headers+2; $i++){
	    $cmd.= " f${i}=$bits[$i]";
	}
	$cmd.=" thresh=$Opt{thresh} evalue=$Opt{evalue}";
	print "$cmd \n";   
	system($cmd);
    }
}


sub set_alt_col_names{
    my %alt_col_names=();
    $alt_col_names{"A1"}{"REF"}=1;
    $alt_col_names{"A2"}{"ALT"}=1;
    $alt_col_names{"A1"}{"A1_effect"}=1;
    $alt_col_names{"A2"}{"A2_other"}=1;
    $alt_col_names{"CHROM"}{"CHR"}=1;
    $alt_col_names{"CHROM"}{"CHROMOSOME"}=1;
    $alt_col_names{"BEG"}{"BEGIN"}=1;
    $alt_col_names{"BEG"}{"BP"}=1;
    $alt_col_names{"BEG"}{"POS"}=1;
    $alt_col_names{"MARKER_ID"}{"NAME"}=1;
    $alt_col_names{"MARKER_ID"}{"MARKER"}=1;
    $alt_col_names{"MARKER_ID"}{"ID"}=1;
    $alt_col_names{"MARKER_ID"}{"SNP"}=1;
    $alt_col_names{"PVALUE"}{"PVAL"}=1;
    return \%alt_col_names;
}

sub add_markers_by_columns{
    my ($opt_ref, $f,$markers_ref)=@_;
    my %markers=%{$markers_ref};
    my $opt_ref=&check_col_pos(\%Opt, $f);
    my ($cut, $data_pos)=&get_ordered_col_index($opt_ref);
    my %data_pos=%{$data_pos};
    my $cat="cat";if($f =~ /gz$/){$cat="zcat";}
    open(IN, "$cat $f | $cut |") or die "Cant open file $f\n";
    (my $h= <IN>) =~ s/\#//;
    while(<IN>){
	chomp();
	my @data =split(" ",$_);
	my $chrom=$data[$data_pos{CHROM}];
	if($chrom =~ /X/){
	    $chrom="23";
	}
	my $beg=$data[$data_pos{BEG}];
	my $marker_id=$data[$data_pos{MARKER_ID}];
	my $ref="NA";
	my $alt="NA";
	if(($data[$data_pos{A1}]) && ($data[$data_pos{A1}] !~ /(I|D)/)){$ref=$data[$data_pos{A1}];}
	if(($data[$data_pos{A2}]) && ($data[$data_pos{A2}] !~ /(I|D)/)){$alt=$data[$data_pos{A2}];}
	my $name;
	if($marker_id =~ /\d+:\d+_\S+.*_(rs\S+)/){
                $name=$1;
	}
	elsif($marker_id =~ /(.+):(\d+)_\S+/){
	    $name="$1_$2";
	}
	else{
	    $name=$marker_id;
	}
	if($beg =~ /\d+/){
	    $markers{$chrom}{$beg}{$name}{ALT}=$alt;
	    $markers{$chrom}{$beg}{$name}{REF}=$ref;
	}
    }
    return \%markers;   
}

sub get_ordered_col_index{
    my $opt_ref=shift;
    my %Opt=%{$opt_ref};
    my %fields=%{$Opt{fields_ref}};
    #get ordered col indeces
    my $cut="cut -f ";
    my %data_pos=();
    my $i=0;
    foreach my $col (sort {$fields{$a} <=> $fields{$b}} keys %fields){
	$cut.=$fields{$col}.",";
        $data_pos{$col}=$i;
        $i++;
    }$cut =~ s/,$//;
    return ($cut,\%data_pos);
}

sub getset_genome_build_id{
    my ($conf_ref, $build)=@_;
    my %config=%{$conf_ref};    
    my $genome_build_id=&get_genome_build_id($conf_ref, $build);
    if($genome_build_id !~ /\d+/){
	print "\nCant find the genome_build_id for build $build. Do you want me to add it to the database? (yes/no)\n";
	my $answer=<STDIN>;chomp($answer);
	if($answer =~ /(y|yes)/i){
	    my $mysql="mysql -u $config{user} -p$config{password} $config{database}";
	    my $cmd="echo 'INSERT INTO genome_build (name) values (\"$build\");' | $mysql";
	    my $out=qx($cmd 2>&1);
	    if($out =~ /\[Warning\] Using a password/){
		print "Success. Genome build [$build] was added to the database [$config{database}]\n";
	    } 
	}
	else{   
	    print "Aborting without doing anything! \n"; exit;
	}
	$genome_build_id=&get_genome_build_id($conf_ref, $build);
    }
    return $genome_build_id;
}

sub get_genome_build_id{
    my ($conf_ref, $build)=@_;
    my %config=%{$conf_ref};
    my $mysql="mysql -u $config{user} -p$config{password} $config{database}";
    my $cmd="echo 'SELECT genome_build_id from genome_build where name=\"$build\";' | $mysql";
    my $out=qx($cmd 2>&1);
    my @out=split("\n", $out);
    my $genome_build_id;
    for(my $i=0; $i<$#out+1; $i++){
        if ($out[$i] =~ /genome_build_id/){
            $genome_build_id=$out[$i+1];
        }
    }
    return $genome_build_id;
}

sub execute_command{
    my ($cmd,$msg)=@_;
    my $out=qx($cmd 2>&1);
    if($out =~ /ERROR/){
	print "\nGot the following error:\n\n$out\n\nwhen trying to execute the command: \n$cmd\n\n"; 
	print "Make sure your MySQL username and password are correct in  etc/config.txt\n\n";
    }else{print "\nSuccess! $msg\n\n";}
}

sub get_resource_bundle{
    my ($opt_ref, $conf_ref, $Bin)=@_;
    my %Opt=%{$opt_ref};
    my %config=%{$conf_ref};
    my $resource_dir=&get_resource_dir($conf_ref,  $Bin);
    if(!( -e $resource_dir)){
        `mkdir -p $resource_dir`;
    }
    my $wget="wget $config{toppar_git_url}/resources/$Opt{build}.tar.gz  -P $resource_dir";
    print "\n\n*** Getting the resource bundle for genome build [$Opt{build}] *** \n\n";
    print "$wget\n";
    my $out_wget=qx($wget 2>&1); #handle error here                                                                                                                                                   
    print "Untar the bundle: \n";
    my $untar="tar -zxvf $resource_dir/$Opt{build}.tar.gz -C $resource_dir";
    print "$untar\n";
    my $out_untar=qx($untar 2>&1);
}

sub get_resource_dir{
    my ($conf_ref, $Bin)=@_;
    my %config=%{$conf_ref};
    my $resource_dir= $config{resource_dir};
#if($resource_dir =~ /toppar_home/){
	#$resource_dir =~ s/toppar_home/$Bin/;
    #}
    $resource_dir =~ s/\/\//\//g;
    return $resource_dir;
}

1;
#print "\nmarker file:\t\t[$marker_f]\nmarker mapping file:\t [$marker_mapping_f]\n\n";

