#!/usr/bin/perl

use strict;
use Cwd;

my $cwd=cwd;
my $ld_dir="/Users/tota/repository/locuszoom/data/1000G/genotypes/2017-04-10/EUR";

my @chr=(1..22);


chdir($ld_dir);

my @outfiles=();

foreach my $chr (@chr){
    my $outfile="chr${chr}.ld";
    my $cmd="plink --bfile chr${chr} --r2 --out chr${chr}";
    print "$cmd\n";
    my $out=qx($cmd 2>&1);
    print "OUTPUT: $out \n";
    push(@outfiles, $outfile);
}

my $cat_cmd="cat ".join(" ", @outfiles)." > EUR_genotypes_100417_LD.txt";
print "$cat_cmd \n";
my $out2=qx($cat_cmd 2>&1);
print "OUTPUT: $out2 \n";

#/Users/tota/repository/locuszoom/data/1000G/genotypes/2017-04-10/EUR/format_LD_file.pl

chdir($cwd);

