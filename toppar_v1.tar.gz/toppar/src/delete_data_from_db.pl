#!/usr/bin/perl 

use strict;

require "shared_func.pl";

my %Opt;
my %config;
my $Bin;
use strict;

sub delete_data{
    my ($opt_ref, $conf_ref, $Bin)=@_;
    %Opt=%{&get_Opt()};
    %config=%{&get_config()};
    $Bin=&get_Bin();
    my ($sql, @output);
    my $sql_bind=" AND gs.genome_scan_id=gss.genome_scan_id and gs.population_id=(select population_id from population where name=\"$Opt{pop}\") and gs.genome_build_id=(SELECT genome_build_id from genome_build where name=\"$Opt{build}\")";

    if($Opt{label}){
	my $genome_scan_id=&get_genomescan_id($Opt{pop}, $Opt{pheno}, $Opt{build});
	my $genome_subscan_id=&get_genome_subscan_id($genome_scan_id, $Opt{label});	
	&clean_up($genome_subscan_id, $genome_scan_id);
    }
    elsif( $Opt{f1} || $Opt{f2} || $Opt{f3} ){
	my $filter="gss.f1=\"$Opt{f1}\" ";
	if($Opt{f2}){ $filter="gss.f2=\"$Opt{f2}\" ";}
	if($Opt{f3}){ $filter="gss.f3=\"$Opt{f3}\" ";}
	$sql="SELECT gss.genome_subscan_id, gs.genome_scan_id FROM genome_subscan gss, genome_scan gs WHERE ".$filter.$sql_bind;
	@output=@{&submit_cmd($sql)};
	for(my $i=2; $i<$#output+1; $i++){
	    my ($gsubscan_id, $gscan_id)=split("\t", $output[$i]); $gscan_id=~ s/\n//;
	    &clean_up($gsubscan_id, $gscan_id);
	}
    }
    elsif($Opt{pheno}){
	$sql="SELECT gss.genome_subscan_id, gs.genome_scan_id FROM genome_subscan gss, genome_scan gs WHERE gs.phenotype_id=(SELECT phenotype_id from phenotype where name=\"$Opt{pheno}\")".$sql_bind;
	@output=@{&submit_cmd($sql)};
	for(my $i=2; $i<$#output+1; $i++){
	    my ($gsubscan_id, $gscan_id)=split("\t", $output[$i]); $gscan_id=~ s/\n//;
	    &clean_up($gsubscan_id, $gscan_id);
	}	
    }
    elsif($Opt{pop}){
	$sql="SELECT gss.genome_subscan_id, gs.genome_scan_id FROM genome_subscan gss, genome_scan gs WHERE gs.population_id=(SELECT population_id from population where name=\"$Opt{pop}\")".$sql_bind;
	@output=@{&submit_cmd($sql)};
	for(my $i=2; $i<$#output+1; $i++){
	    my ($gsubscan_id, $gscan_id)=split("\t", $output[$i]); $gscan_id=~ s/\n//;
	    &clean_up($gsubscan_id, $gscan_id);
	}
    }
}

sub clean_up{
    my ($gsubscan_id, $gscan_id)=@_; 
    my ($sql, @output);
    if($gsubscan_id =~ /\d+/){
	#delete the genome subscan_results
	$sql="delete from genome_subscan_results where genome_subscan_id=$gsubscan_id"; 
	&execute_sql($sql, "Deleted genome_subscan_results for genome_subscan_id [$gsubscan_id]", "Something went wrong when trying to delete genome_subscan_results for genome_subscan_id [$gsubscan_id].");
        #delete from genome_subscan
	$sql="delete from genome_subscan where genome_subscan_id=$gsubscan_id";
	&execute_sql($sql, "Deleted genome_subscan for genome_subscan_id [$gsubscan_id]", "Something went wrong when trying to delete genome_subscan for genome_subscan_id [$gsubscan_id]");
	$sql="delete from condensed where genome_subscan_id=$gsubscan_id";
        &execute_sql($sql, "Deleted condensed data for genome_subscan_id [$gsubscan_id]", "Something went wrong when trying to delete condensed for genome_subscan_id [$gsubscan_id]");
    }
    else{
	print "No matching genome subscan found. Perhaps you have already deleted it? \n\n";
    }
    if($gscan_id =~ /\d+/){
	#delete the genome_scan, if there are no other genome_subscans with the genome_scan_id
	$sql="select genome_scan_id from genome_subscan_where genome_scan_id=$gscan_id";
	@output=@{&submit_cmd($sql)};

	if($output[1] =~ /Empty set/){
	    #first get the phenotype and population ids since they may have to be deleted too
	    $sql="SELECT phenotype_id, population_id from genome_scan where genome_scan_id=$gscan_id";
	    @output=@{&submit_cmd($sql)};
	    my ($phenotype_id, $pop_id)=split("\t", $output[2]);
	    #delete the genome_scan
	    $sql="delete from genome_scan where genome_scan_id=$gscan_id";
	    $sql="select genome_scan_id from genome_scan where phenotype_id=$phenotype_id";
	    @output=@{&submit_cmd($sql)};
	    if($output[1] =~ /Empty set/){
		$sql="delete FROM phenotype where phenotype_id=$phenotype_id";
		&execute_sql($sql);
	    }
	    $sql="select genome_scan_id from genome_scan where population_id=$pop_id";
	    @output=@{&submit_cmd($sql)};
	    if($output[1] =~ /Empty set/){
		$sql="delete FROM population where population_id=$pop_id";
		&execute_sql($sql, "Deleted the population $Opt{pop} from the database", "Could not delete the population $Opt{pop} from the database.");
	    }
	}
	else{#there is other  data, dont delete 
	    #print "There is other data \n";
	}
    }
}

sub submit_cmd{
    my $sql=shift;
    my $mysql_connect="mysql -u $config{user} -p$config{password} $config{database}";
    my $cmd="echo '$sql;' | $mysql_connect"; 
    my @output=qx($cmd 2>&1);
    return \@output;
}


1;
