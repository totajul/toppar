#!/usr/bin/perl

use strict;
use Cwd;
use Time::HiRes qw(gettimeofday);

require "shared_func.pl";

my %markers=();
my %Opt=();
my $Bin;

sub mk_markers{
    %Opt=%{&get_Opt()};
    my $cwd=cwd;
    $Bin=&get_Bin();
    
    if($Opt{indir}){
	chdir($Opt{indir});
	my @files=<*.$Opt{sfx}>;
	my %snps=();
	if(!($#files > 0)){
	    print "\nThere are no files with the file suffix [$Opt{sfx}] in the directory [$Opt{indir}]. \nChange the infile suffix using the --sfx argument\n\n";
	    exit;
	}
	else{
	    print "\nAdding markers from  [".(scalar @files)."] files:\n"; foreach my $f (@files){print "\t$f\n";}
	    my $markers_ref=&add_markers(\%Opt, \@files);
	    &print_outfile(\%Opt, $markers_ref);
	}
	chdir($cwd);
    }
    elsif($Opt{infile}){
	my @files;
	#make sure file exists
	if(-e $Opt{infile}){
	    push(@files, $Opt{infile});
	    my $markers_ref=&add_markers(\%Opt,\@files);
	    &print_outfile(\%Opt, $markers_ref);
	}
	else{
	    print "Cant find the file: $Opt{infile}\n";
	    print "Aborting without doing anything! \n";
	}
}
}    

sub add_markers{
    my ($opt_ref, $files_ref)=@_;
    my %markers=();
    my $markers_ref=\%markers;
    foreach my $f (@{$files_ref}){
	$markers_ref=&add_markers_by_columns($opt_ref,$f,$markers_ref);
    }
    return $markers_ref;
}

sub print_outfile{
    my ($Opt_ref, $markers_ref)=@_;
    my %markers=%{$markers_ref};
    my %Opt=%{$Opt_ref};
    (my $outfile = $Opt{outdir}) =~ s/(\S+)\/$/$1/;
    if($Opt{outfile}){
	$outfile.="/".$Opt{outfile};
    }
    else{
	my $sfx="tsv";
	if($Opt{output_vcf}){
	    $sfx="vcf";
	}
	my $timestamp=int(gettimeofday*1000);
	$outfile.="/markers_".$timestamp.".".$sfx;
    }
    if(!(-e $Opt{outdir})){ system("mkdir $Opt{outdir}");}
    open(OUT, ">$outfile") or die "Coldnt open $outfile \n";
    if($Opt{output_vcf}){
	print OUT "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n"; #VCF header}
    }
    else{print OUT "CHROM\tBEG\tMARKER_ID\n"; 
    }
    foreach my $chr (keys %markers){
	foreach my $bp (keys %{$markers{$chr}}){
	    if($bp =~ /\d+/){
		foreach my $snp (keys %{$markers{$chr}{$bp}}){
		    my $ref=$markers{$chr}{$bp}{$snp}{REF};
		    my $alt=$markers{$chr}{$bp}{$snp}{ALT};
		    if($Opt{output_vcf}){
			print OUT "$chr\t$bp\t$snp\t$ref\t$alt\t.\t.\t.\n";
		    }
		    else{
			print OUT "$chr\t$bp\t$snp\n";
		    }
		}
	    }
	}
    }
    print "\nDone! A marker file containing [".&count_markers(\%markers)."] markers was created: \n";
    print "\nOUTFILE:$outfile\n\n";
    
}

sub count_markers{
    my $m=shift;
    my $i=0;
    my %markers=%{$m};
    foreach my $chr (keys %markers){
	foreach my $bp (keys %{$markers{$chr}}){
	    foreach my $snp (keys %{$markers{$chr}{$bp}}){
		$i++;
	    }
	}
    }
    return $i;
}

1;
