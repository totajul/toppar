#!/usr/bin/perl 

use strict;

require "shared_func.pl";

my %Opt;
my %config;
my $Bin;

sub upload_gene_based_test_results{
    my $files_ref=@_;
    %Opt=%{&get_Opt()};
    %config=%{&get_config()};
    $Bin=&get_Bin();
    $Opt{fields_ref}=&str2hash($Opt{req_fields});
    my $groups_ref=&get_groups_from_gfile($Opt{groupfile});
    my @scan_files;
    my $marker_rsId_map=&get_rsId_map(\%Opt);
    my $func="group";
    foreach my $f (@{$files_ref}){
	my $opt_ref=&check_col_pos(\%Opt, $f);
	my $results_ref=&get_group_data($opt_ref, $f,$groups_ref,$marker_rsId_map);
	push(@scan_files,  &write_scanfile($opt_ref, $f, $results_ref,$func));
    }
    &upload_scanfiles(\@scan_files, \%Opt, \%config, $Bin);
}   

sub get_rsId_map{
    my $opt_ref=shift;
    my %Opt=%{$opt_ref};
    my %marker_map=();
    my $map_file=$Opt{outdir}."/marker_map.$Opt{pop}.$Opt{build}.tsv";
    if(-e $map_file){
	open(IN, $map_file) or die "Cant open $map_file for reading \n";
	my $h=<IN>;
	while(<IN>){
	    chomp();
	    my ($chr, $pos, $name)=split("\t", $_);
	    my $marker=$chr."_".$pos;
	    $marker_map{$marker}=$name;
	}
    }
    else{
	print "Map file [$map_file] does not exist!\n";
    }
    return \%marker_map;
}

sub get_group_data{
    my ($opt_ref, $file,$groups_ref,$marker_map_ref)=@_;
    my %Opt=%{$opt_ref};
    my %marker_map=%{$marker_map_ref};
    my %fields=%{$Opt{fields_ref}};
    my %groups=%{$groups_ref};
     #get ordered col indeces
    my $cut="cut -f ";
    my %data_pos=();
    my $i=0;
    my %results=();
    foreach my $col (sort {$fields{$a} <=> $fields{$b}} keys %fields){
	$cut.=$fields{$col}.",";
	$data_pos{$col}=$i;
	$i++;
    }$cut =~ s/,$//;
    my $cat="cat";
    if($file =~ /gz$/){$cat="zcat";}
    open(IN, "$cat $file | $cut |") or die "couldnt open $file\n";
    (my $h= <IN>) =~ s/\#//;    
    print "\nReading $file...\n";
    while(<IN>){
	chomp();
	my @data=split(" ",$_);
	my $marker_id=$data[$data_pos{MARKER_ID}];
	my $pvalue=$data[$data_pos{PVALUE}];
	my $gene;
	if ($marker_id =~ /.*:\d+-\d+_(.*)/){
	    $gene=$1;
	}
	else{print "Id [$marker_id] in [$file]  does not match pattern \n";    exit;}
	if($groups{$gene}){
	    my @vars=split(" ", $groups{$gene});
	    foreach my $v (@vars){
		my ($pos,$nt)=split("_",$v);
		$pos =~ s/:/_/;
		if($marker_map{$pos}){
		    $pos=$marker_map{$pos};
		}
		$results{$pos}{pval}=$pvalue;
	    }
	}
	else{
	    print "Gene $gene not found in $Opt{groupfile} in $file\n";exit;
	}
    }
    close(IN);
    print "Read [".scalar (keys %results)."] lines. \n";
    return \%results;
}

sub get_groups_from_gfile{
    my $file=shift;
    my %groups;
    open(GRP, $file) or die "Couldnt open $file\n";
    while(<GRP>){
	my ($g, $vars)=split("\t", $_);
	$groups{$g}=$vars;
    }close(GRP);	
    return \%groups;
}
1;
