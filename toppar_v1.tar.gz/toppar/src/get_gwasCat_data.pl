#!/usr/bin/perl

use strict;
my %config=();
my %Opt=();
my %chr_length=();
my %gwas=();
my $maxLog10=300; # max log10 p-value (on the y-axis on the plot)

sub get_gwasCat_data{
    my ($opt_ref, $conf_ref, $Bin, $chr_length_ref, $update_resource)=@_;
    %config=%{$conf_ref};
    %Opt=%{$opt_ref};
    %chr_length=%{$chr_length_ref};
    my $cmd="wget ".$config{gwascat}." -P ".$config{json_dir};
    my $gwascat_file=$config{json_dir}."/full";

    if((-e $gwascat_file) && !($update_resource)){
	print "I'm using the existing GWAS catalog file: [$gwascat_file]. I you want to run with an updated version of this file, either delete it and rerun or issue the update command: \n\n\tperl toppar_db  update_ext_data --update_gwascat\n\n";
	
    }
    else{
	`rm $gwascat_file`;
	 print "Getting gwascat data...\n$cmd\n";
	`$cmd`;
    }
    &read_gwas_data($gwascat_file);
    &output_as_json();
}

sub output_as_json{
    $config{json_dir} =~ s/\/$//;
    my $json_gwas_cond=$config{json_dir}."/gwascatalog_all.json";
    open(COND, ">$json_gwas_cond") or die "Couldnt open $json_gwas_cond for writing \n";
    my ($maxScore_cond, @cond_data, $pval_mlog);
    my $acc_chr_length=0;
    foreach my $chr (sort {$a <=> $b} keys %gwas){
	if(! ($chr_length{$chr})){
	    $chr_length{$chr}=&getChr_length($chr);
	}
	my @data;
	my $json_gwas_chr=$config{json_dir}."/gwascatalog_${chr}.json";
	open(JSON_CHR, ">$json_gwas_chr") or die "Couldnt open $json_gwas_chr for writing \n";
	my $maxScore=0;
	foreach my $pos (sort {$a <=> $b} keys %{$gwas{$chr}}){
	    foreach my $snp (sort {$a <=> $b} keys %{$gwas{$chr}{$pos}}){
		$pval_mlog=$gwas{$chr}{$pos}{$snp}{pval_mlog};
		if(($pval_mlog =~ /\d+/) && ($pval_mlog > 0) && ($pval_mlog < $maxLog10)){ #limit the maximum value 
		    if($pval_mlog > $maxScore){$maxScore=$pval_mlog;}
		    if($pval_mlog > $maxScore_cond){$maxScore_cond=$pval_mlog;}
		    push(@data, "[$pos, $pval_mlog, \"$snp\", $gwas{$chr}{$pos}{$snp}{info}]");
		    if($gwas{$chr}{$pos}{pval_mlog} > $maxScore){$maxScore=$gwas{$chr};}
		    my $cond_pos=$pos+$acc_chr_length;
		    push(@cond_data, "[$cond_pos, $pval_mlog, \"$snp\", $gwas{$chr}{$pos}{$snp}{info}]");
		}
	    }
	}
	$acc_chr_length+=$chr_length{$chr};
	print JSON_CHR"{\"label\":\"gwas catalog SNPs\",\n \"plot_type\":\"point\",\n\"unit\":\"log10\",\n\"maxScore\": $maxScore,\n \"data\": [".join(",", @data)."]}";
	close(ON_CHR);
    }
    print COND "{\"label\":\"gwas catalog SNPs\",\n \"plot_type\":\"point\",\n\"unit\":\"log10\",\n\"maxScore\": $maxScore_cond,\n \"data\": [".join(",", @cond_data)."]}";
    close(COND);
}

sub read_gwas_data{
    my $file=shift;
    #the gwas catalog file is called full, create json files for each chromosome and put them in the $config{json_dir} directory
    open(IN, "cut -f2,6,8,12,13,14,21,22,28,29 $file |") or die "Couldnt open $file\n";
    my @h=split("\t", <IN>);
    my @exp_header=("PUBMEDID","LINK","DISEASE/TRAIT","CHR_ID","CHR_POS","REPORTED GENE(S)","STRONGEST SNP-RISK ALLELE","SNPS","VALUE","PVALUE_MLOG");
    #make sure the file header is still what we exepect it to be
    my $identical=&compare_arrays(\@h, \@exp_header);
    if($identical){
	while(<IN>){
	    chomp();
	    my $line=$_;
	    my ($pid, $pid_link,$disease, $chr, $pos, $reported_gene, $strongest_snp_risk_allele, $snp, $pval, $pval_mlog)=split("\t", $line);
	    #  my $info="\"pid\":\"$pid\", \"pid_link\"=\"$pid_link\", \"pval\":\"$pval\",\"disease\":\"$disease\"";
	    #fix this: put the info into the data object and add the link later
	    my $info="\"$disease : $pval <a href=".$pid_link." target=_blank>$pid</a>\",\"$pid\"";
	    if($chr =~ /\d+/){
		if($chr =~ /;/){ #because there are chromosomes like 10;10;10 in the gwascatalog file
		    #multi
		    my @m_chr=split(";", $chr);
		    my @m_pos=split(";", $pos);
		    my @m_snp=split(";", $snp);
		    for(my $i=0; $i<$#m_chr+1; $i++){
			$gwas{$m_chr[$i]}{$m_pos[$i]}{$m_snp[$i]}{pval_mlog}=$pval_mlog;
			$gwas{$m_chr[$i]}{$m_pos[$i]}{$m_snp[$i]}{info}=$info;
		    }
		}
		elsif($chr =~ /x/) { #some are like 10 x 12 #skip these for now
		}
		else{
		    $gwas{$chr}{$pos}{$snp}{pval_mlog}=$pval_mlog;
		    $gwas{$chr}{$pos}{$snp}{info}=$info;
		}
		
	    }
	} close(IN);
    }
    else{
	print "\nIt looks like there has been a change in columns or column order in the GWAS catalog file since last version. Please check this and re-adjust the script to pick the right columns.\n";
	print "\nThe command cut -f2,6,8,12,13,14,21,22,28,29 gwas_cat_file previously returned these columns: [".join(",",@exp_header)."], but now the same command returns the following: [".join(",", @h)."\n";
	print "\***Exiting without updating!***\n";
	exit;
    }
}

sub getChr_length{
    my $chr=shift;
    my $chr_length;
    my $mysql_connect="mysql -u $config{user} -p$config{password} $config{database}";
    my $sql="select length from chromosome where genome_build_id=(SELECT genome_build_id from genome_build where name=\"$Opt{build}\") and name=\"${chr}\"";
    my $cmd="echo '$sql;' | $mysql_connect";
    my @output=qx($cmd 2>&1);
    if($output[1] =~ /Empty set/){
	print "SQL query [$sql] returned an empty string. Upload the chromosome lengths for the build and try again! \n\n";exit;
    }
    else{($chr_length=$output[2]) =~ s/\n//;
    }return $chr_length;
}

sub compare_arrays{
    my ($array_ref1, $array_ref2)=@_;
    my $identical=1;
    my @array1=@{$array_ref1}; my @array2=@{$array_ref2};
    for (my $i=0; $i< $#array1+1; $i++){
	if($array1[$i] != $array2[$i]){
	    $identical=0;
	}
    }
    return $identical;
}

1;
