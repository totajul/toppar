#!/usr/bin/perl

use strict;
use Cwd;
use File::Basename;
use Time::HiRes qw(gettimeofday);


sub getset_genome_build_id{
    my $name=shift;
    my $genome_build_id=&get_id_for_name($name, "genome_build_id", "genome_build");
    if($genome_build_id !~ /\d+/){
	print "\nCant find the genome_build_id for build $name. Do you want me to add it to the database? (yes/no)\n";
	my $answer=<STDIN>;chomp($answer);
	if($answer =~ /(y|yes)/i){
	    my $cmd="echo 'INSERT INTO genome_build (name) values (\"$name\");' | ".&mysql();
	    my $out=qx($cmd 2>&1);
	    if($out =~ /\[Warning\] Using a password/){
		print "Success. Genome build [$name] was added to the database!\n";
	    } 
	}
	else{   
	    print "Aborting without doing anything! \n"; exit;
	}
	$genome_build_id=&get_id_for_name($name, "genome_build_id", "genome_build");
    }
    return $genome_build_id;
}

sub mysql{
    my %config=%{&get_config()};
    return "$config{mysql} -u $config{user} -p$config{password} $config{database}";
}

sub get_id_for_name{
    my ($name, $col, $table)=@_;
    my $cmd="echo 'SELECT ".$col." from ".$table." where name=\"$name\";' | ".&mysql();
    my $out=qx($cmd 2>&1);
    my @out=split("\n", $out);
    my $id;
    for(my $i=0; $i<$#out+1; $i++){
        if ($out[$i] =~ /$col/){$id=$out[$i+1];}
    }
    return $id;
}

sub insert_name{
    my ($name, $table)=@_;
    my $cmd="echo 'INSERT INTO ".$table." (name) values (\"$name\");' | ".&mysql();
    my $out=qx($cmd 2>&1);
    if($out =~ /\[Warning\] Using a password/){
	print "Success. $name  was added to $table in the database!\n";
    }
}

sub get_set_id{
    my ($name, $col, $table)=@_;
    my $id=&get_id_for_name($name, $col, $table);
    if($id !~ /\d+/){
        &insert_name($name, $table);
        $id=&get_id_for_name($name, $col, $table);
    }
    return $id;
}

sub get_genomescan_id{
    my ($pop, $pheno, $build)=@_;
    my $col="genome_scan_id";
    my $pop_id=&get_set_id($pop, "population_id", "population");
    my $pheno_id=&get_set_id($pheno, "phenotype_id", "phenotype");
    my $build_id=&get_set_id($build, "genome_build_id", "genome_build");   
    my $cmd="echo 'SELECT genome_scan_id from genome_scan where phenotype_id=$pheno_id and population_id=$pop_id and genome_build_id=$build_id;' | ".&mysql();
    my $out=qx($cmd 2>&1);
    my @out=split("\n", $out);
    my $id;
    for(my $i=0; $i<$#out+1; $i++){
        if ($out[$i] =~ /$col/){$id=$out[$i+1];}
    }
    return $id;

}

sub insert_genomescan{
    my ($pop, $pheno, $build)=@_;
    my $pop_id=&get_set_id($pop, "population_id", "population");
    my $pheno_id=&get_set_id($pheno, "phenotype_id", "phenotype");
    my $build_id=&get_set_id($build, "genome_build_id", "genome_build");
    my $cmd="echo 'INSERT INTO genome_scan (population_id, phenotype_id, genome_build_id) values ($pop_id, $pheno_id, $build_id);' | ".&mysql();
    my $out=qx($cmd 2>&1);
    if($out =~ /ERROR/){
	print "Something went wrong when inserting the genomescan \n";exit;
    }
    elsif($out =~ /\[Warning\] Using a password/){
        print "Success. Genome_scan  was added to  the database!\n";
    }
}

sub get_set_genomescan_id{
    my ($pop, $pheno, $build)=@_;
    my $genomescan_id=&get_genomescan_id($pop, $pheno, $build);    
   if($genomescan_id !~ /\d+/){
	&insert_genomescan($pop, $pheno, $build);
	$genomescan_id=&get_genomescan_id($pop, $pheno, $build);
    }
    return $genomescan_id;
}

sub get_genome_subscan_id{
    my ($genome_scan_id, $label)=@_;
    my $col="genome_subscan_id";
    my $cmd="echo 'SELECT genome_subscan_id from genome_subscan where genome_scan_id=$genome_scan_id and label=\"$label\";' | ".&mysql();
    my $out=qx($cmd 2>&1);
    my @out=split("\n", $out);
    my $id;
    for(my $i=0; $i<$#out+1; $i++){
        if ($out[$i] =~ /$col/){$id=$out[$i+1];}
    }
    return $id;
}

sub insert_genome_subscan{
    my($genome_scan_id, $label)=@_;
    my @filters=split("\\.", $label);
    my $type="point";
    my $cmd="echo 'INSERT INTO genome_subscan (genome_scan_id, plot_type, label, f1,f2,f3) values ($genome_scan_id, \"$type\", \"$label\", \"$filters[1]\", \"$filters[2]\", \"$filters[3]\");' | ".&mysql();
    my $out=qx($cmd 2>&1);
    if($out =~ /ERROR/){
	print "Something went wrong when inserting genome_subscan $cmd \n";
    }
    elsif($out =~ /\[Warning\] Using a password/){
        print "Success. Genome_subscan  was added to the database!\n";
    }
}

sub get_set_genome_subscan_id{
    my ($genome_scan_id, $label, $opt_ref)=@_;
    my %Opt=%{$opt_ref};
    my $genome_subscan_id=&get_genome_subscan_id($genome_scan_id, $label);
    if($genome_subscan_id !~ /\d+/){
	&insert_genome_subscan($genome_scan_id, $label);
        $genome_subscan_id=&get_genome_subscan_id($genome_scan_id, $label);
    }
    else{
	print "The genome subscan [$genome_subscan_id]  with label $label already exists. You can delete it by executing the following command: \n";
	print "\nperl toppar_db delete --pop=$Opt{pop} --pheno=$Opt{pheno} --build=$Opt{build} --label=$label\n\n";
	exit;
    }
    return $genome_subscan_id;
}


sub execute_cmd{
    my ($cmd,$msg, $error_msg)=@_;
    my $out=qx($cmd 2>&1);
    if($out =~ /ERROR/){
	chomp($out);
	print "\nGot the following error:\n\n[$out]\n\nwhen trying to execute the command: \n\n[$cmd]\n";
	print "\n*** $error_msg *** \n\n";
	exit;
    }
    else{print "\nDone! $msg\n";}
}

sub execute_sql{
    my ($sql,$msg, $error_msg)=@_;
    my $cmd="echo '".$sql.";' | ".&mysql();
    $error_msg.="\nMake sure your MySQL username and password are correct in  etc/config.txt\n\n";
    &execute_cmd($cmd, $msg, $error_msg);
}

1;
