#!/usr/bin/perl

use strict;
use Cwd;

sub get_genes{
    my ($opt_ref, $conf_ref, $Bin)=@_;
    my $file=&get_gene_file($opt_ref, $conf_ref, $Bin);
    print "\n*** Inserting GENE annotation *** \n";
    my $genes_ref=&read_gene_file($file);
    return $genes_ref;
}

sub get_gene_file{
    my ($opt_ref, $conf_ref, $Bin)=@_;
    %Opt=%{$opt_ref};
    my %config=%{$conf_ref};
    #check if resource dir exists, if not create it
    my $resource_dir = &get_resource_dir($conf_ref, $Bin);
    my $genes_file=$resource_dir."/$Opt{build}/mart_human_genes_$Opt{build}.tsv";
    if($Opt{genes}){
	if( -e $Opt{genes}){
	    $genes_file=$Opt{genes};
	}
	else{
	    print "Cant find the file [$Opt{genes}]. Aborting! \n";exit;
	}
    }
    else{
	#get the resource bundle
	if( ! -e $genes_file){
	    #get the resource bundle for the build
	    &get_resource_bundle($opt_ref, $conf_ref,$Bin);
	}
    }
    return $genes_file;
}


sub read_gene_file{
    my $file=shift;
    my %genes=();
    my %chrs=();
    my @chr=(1..22);
    push(@chr, "X","Y");
    
    foreach my $c (@chr){$chrs{$c}=1;}
    my $cat="cat";
    if($file =~ /.gz/){
	$cat="zcat";
    }
    print "\nReading $file...\n";
    open(IN, "$cat $file | ") or die "Couldnt open  $file for reading \n";
    <IN>; #ignore the header line
    while(<IN>){
	chomp($_);
	my ($name,$ens_id,$chr,$start,$end,$strand,$desc,$exon_id)=split("\t", $_);
	if($chrs{$chr}){
	    $genes{$name}{ens_id}=$ens_id;
	    $genes{$name}{chr}=$chr;
	    $genes{$name}{start}=$start;
	    $genes{$name}{end}=$end;
	    $genes{$name}{strand}=$strand;
	    if($desc =~ /(.*)\s+\[Source.*/){
		$desc=$1;
	    }
	    my $str_length=length($desc);
	    if($str_length>200){
		my @tmp=split(";", $desc);
		$desc=$tmp[0];
		
	    }
	    $desc =~ s/,/ /g; #using , as the field separator in mysql LOAD DATA LOCAL
	    $genes{$name}{desc}="".$desc;
	    $genes{$name}{exons}{$exon_id}=1;
	}
    }
    return \%genes;
}


sub upload_genes_disease{
    my ($conf_ref, $genome_build_id, $genes_ref, $disease_assoc_ref)=@_;
    my %config=%{$conf_ref};
    my %genes=%{$genes_ref};
    my %disease_assoc=%{$disease_assoc_ref};
   
    my $outfile=$config{json_dir}."/genes.sql";
    open (OUT, ">$outfile") or die "Couldnt open $outfile for writing \n";
    my %seen_genes=(); #to prevent both CKAP2 and Ckap2 from being added as different genes
    
    foreach my $g (keys %genes){
	my $tmp=lc $g;
	if(!($seen_genes{$tmp})){
	    my $disease="";
	    my $ensprot_id="";
	    if($disease_assoc{$g}){
		my $sep="";
		foreach my $prot (keys %{$disease_assoc{$g}}){
		    $disease.=$sep.$disease_assoc{$g}{$prot};
		    $ensprot_id.=$sep.$prot;
		    $sep=";";
		}
		if(length($disease)>200){
                    my $tmp=$disease;$disease=substr $tmp,0,200;$disease.="...";
		}
		if(length($ensprot_id)>100){
                    my $tmp=$ensprot_id;$ensprot_id=substr $tmp,0,100;$ensprot_id.="...";
                }
	    }
	    my $entry=qq($g,$genes{$g}{ens_id},$ensprot_id,$genes{$g}{chr},$genes{$g}{strand},$genes{$g}{start},$genes{$g}{end},$genome_build_id,$genes{$g}{desc},$disease,);
	    print OUT "$entry\n";
	}
	$seen_genes{$tmp}=1;	         
    }
    close(OUT);
    print "Inserting genes into the database....\n";
    (my $loadfile=$outfile)=~ s/genes/genes_load/;
    open(OUT, ">$loadfile") or die "Couldnt open $loadfile for writing \n";
    print OUT "CREATE TEMPORARY TABLE genes_tmp LIKE genes;\n";
    print OUT "LOAD DATA LOCAL INFILE '$outfile' INTO TABLE genes_tmp \nFIELDS TERMINATED BY ','\nLINES TERMINATED BY '\\n'\n(name,ensembl_id,ensembl_protein_id,chromosome,strand,start_bp,end_bp,genome_build_id,description,disease,external_id);\n";
    print OUT "SHOW COLUMNS FROM genes;\nINSERT INTO genes\nSELECT * FROM genes_tmp \nON DUPLICATE KEY UPDATE name=VALUES(name),disease=VALUES(disease),ensembl_protein_id=VALUES(ensembl_protein_id);\n";
    print OUT "DROP TEMPORARY TABLE genes_tmp;\n";
    my $cmd="mysql -u $config{user} -p$config{password} $config{database} < $loadfile";
    execute_command($cmd, "Insertion of genes complete.");
    #cleanup
    `rm $outfile`;
    `rm $loadfile`;
}

1;
