
args=commandArgs(trailingOnly=TRUE)
file=args[1];

out=paste(file, ".log10", sep="")
print(file)
d=read.table(file, as.is=T, header=TRUE)
print(out)
d$log10=-log10(d$pval);

write.table(file=out,quote=FALSE, d, row.names=FALSE, sep="\t") 
