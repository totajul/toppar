#!/usr/bin/perl

use strict;
use File::Basename;
my %config=();
my %Opt=();
my %genes=();

sub get_disease_assoc{
    my $genes_dis_ref=&read_disease_assoc();
    my $disease_file=&write_disease_assoc_file($genes_dis_ref);
    &upload_disease_assoc_file($disease_file);
}

sub upload_disease_assoc_file{
    my $file=shift;
    print "\nInserting disease associations into the database....\n";
    (my $loadfile=$file)=~ s/disease/disease_load/;
    my %config=%{&get_config()};
    open(OUT, ">$loadfile") or die "Couldnt open $loadfile for writing \n";
    print OUT "CREATE TEMPORARY TABLE disease_tmp LIKE disease;\n";
    print OUT "LOAD DATA LOCAL INFILE '$file' INTO TABLE disease_tmp \nFIELDS TERMINATED BY ','\nLINES TERMINATED BY '\\n'\n(gene_name,ensembl_protein_id,disease);\n";
    print OUT "SHOW COLUMNS FROM disease;\nINSERT INTO disease\nSELECT * FROM disease_tmp \nON DUPLICATE KEY UPDATE disease=VALUES(disease);\n";
    print OUT "DROP TEMPORARY TABLE disease_tmp;\n";

    my $cmd="-u $config{user} -p$config{password} $config{database} < $loadfile";
    #if not on MAC os add : --local-infile=1
    my $os=$Config{osname};
    my $mysql="mysql";
    if($os !~ /darwin/i){
        $mysql=$mysql." --local-infile=1";
    }
    my $cmd=$mysql." ".$cmd;
    print "$cmd\n";
    execute_cmd($cmd, "\nInsertion of disease associations complete.\n");
    #cleanup
    `rm $file`;
    `rm $loadfile`;

}
sub write_disease_assoc_file{
    my $genes_dis_ref=shift;
    my %genes_disease=%{$genes_dis_ref};
    my %config=%{&get_config()};
    my $outfile=$config{json_dir}."/disease.sql";
    open(OUT, ">$outfile") or die "Couldnt open $outfile for writing \n";
    foreach my $gene (keys %genes_disease){
	foreach my $protein_id (keys %{$genes_disease{$gene}}){
	    my $line=qq($gene, $protein_id, $genes_disease{$gene}{$protein_id});
	    print OUT $line."\n";
	}
    }
    close(OUT);
    return $outfile;
}

sub read_disease_assoc{
    %config=%{&get_config()};
    %Opt=%{&get_Opt()};
    my $build=$Opt{build};
    my $cmd_knowl="wget ".$config{disease_knowledge}." -P ".$config{json_dir};
    my $cmd_txtm="wget ".$config{disease_textmining}." -P ".$config{json_dir};
    my $dis_knowl=$config{json_dir}."/".basename($config{disease_knowledge});
    my $dis_txtm=$config{json_dir}."/".basename($config{disease_textmining});  
    
    if(-e $dis_knowl){
      print "\nI'm using the existing disease knowledge file: [$dis_knowl]. I you want to upload it again, delete the file [$dis_knowl] and rerun the command! \n";
    }
    else{
	`rm $dis_knowl`;
	print "$cmd_knowl\n"; `$cmd_knowl`;
    }
    if(-e $dis_txtm){
	print "\nI'm using the existing disease textmining file: [$dis_txtm]. I you want to upload it again, delete the file [rm $dis_txtm] and rerun the command! \n";
    }
    else{
	`rm $dis_txtm`;
	print "$cmd_txtm\n"; `$cmd_txtm`;
    }
    
    &get_genes_d($dis_knowl,"k");
    &get_genes_d($dis_txtm, "t");   
    return \%genes;   
}

sub get_genes_d{
    my ($file,$type)=@_;
    open(IN, $file) or die "Couldnt open $file \n";
    while(<IN>){
	my ($prot, $gene, $lab, $disease, @rest)=split("\t", $_);
	if($disease !~ /^ICD10/){
	    if($genes{$gene}{$prot}){
		my $already_seen=$genes{$gene}{$prot};
		if($already_seen !~ /$disease/){
		    $genes{$gene}{$prot}.="; $disease($type)";
		}
	    }
	    else{
		$genes{$gene}{$prot}=$disease."($type)";
	    }
	}
    }
    close(IN);
}


1;
