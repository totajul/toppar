#!/usr/bin/perl

use strict;
use File::Basename;
my %config=();
my %Opt=();
my %genes=();

sub get_disease_assoc{
    my ($opt_ref, $conf_ref, $Bin, $update)=@_;
    %config=%{$conf_ref};
    %Opt=%{$opt_ref};
    my $build=$Opt{build};
    my $cmd_knowl="wget ".$config{disease_knowledge}." -P ".$config{json_dir};
    my $cmd_txtm="wget ".$config{disease_textmining}." -P ".$config{json_dir};
    my $dis_knowl=$config{json_dir}."/".basename($config{disease_knowledge});
    my $dis_txtm=$config{json_dir}."/".basename($config{disease_textmining});  
    
    if((-e $dis_knowl) && !($update)){
      print "I'm using the existing disease knowledge file: [$dis_knowl]. I you want to get an  updated version of this file, either delete it and rerun or issue the update command: \n\n\tperl toppar_db update_ext_data --update_disease_assoc\n\n";
    }
    else{
	`rm $dis_knowl`;
	print "$cmd_knowl\n"; `$cmd_knowl`;
    }
    if((-e $dis_txtm) && !($update)){
	print "I'm using the existing disease textmining file: [$dis_txtm]. I you want to get an  updated version of this file, either delete it and rerun or issue the update command: \n\n\tperl toppar_db update_ext_data --update_disease_assoc\n\n";
    }
    else{
	`rm $dis_txtm`;
	print "$cmd_txtm\n"; `$cmd_txtm`;
    }
    
    &get_genes_d($dis_knowl,"k");
    &get_genes_d($dis_txtm, "t");   
    return \%genes;   
}

sub tmp{
    # Upload disease associations only.
    print "Getting the gene ids for ".scalar (keys %genes)." genes and writing the SQL update statements. This will take a few minutes.... \n";
    my $update_outfile="update_genes.sql";
    open(OUT, ">$update_outfile") or die "couldnt open $update_outfile for writing \n"; 
    my $build;
    foreach my $gene (keys %genes){
	my $gene_id=&get_gene_id_from_db($gene, $build);
	if($gene_id != /NA/){
	    foreach my $protein (keys %{$genes{$gene}}){
		my $disease=$genes{$gene}{$protein};
		if(length($disease)>200){
		    my $tmp=$disease;
		    $disease=substr $tmp,0,200;
		    $disease.="..."; 
	}
		print OUT "UPDATE genes SET ensembl_protein_id=\"$protein\", disease=\"$disease\" WHERE gene_id=$gene_id;\n";
	    }
	}
    }
    my $upd_cmd="mysql -u $config{user} -p$config{password} $config{database} < $update_outfile\n";
    print "$upd_cmd \n";
    print "Updating the gene association data... \n";
    `$upd_cmd`;
    print "Removing the SQL update file..\n";
    my $rm_cmd="rm $update_outfile \n";
    `$upd_cmd`;
    print "Done! \n";
    #run command, and delete outfile
 }

sub get_gene_id_from_db{
    my ($gene, $build)=@_;
    my $gene_id="NA";
    my $SELECT="SELECT gene_id from genes where name=\"$gene\" and genome_build_id=(SELECT genome_build_id from genome_build where name=\"$build\")";
    my $mysql_connect="mysql -u $config{user} -p$config{password} $config{database}";
    my $cmd="echo '$SELECT;' | $mysql_connect";
    my @output=qx($cmd 2>&1);
    if($output[1] =~ /Empty set/){
	$gene_id="NA";
    }
    else{($gene_id=$output[2]) =~ s/\n//;}
    return $gene_id;
    }

sub get_genes_d{
    my ($file,$type)=@_;
    open(IN, $file) or die "Couldnt open $file \n";
    while(<IN>){
	my ($prot, $gene, $lab, $disease, @rest)=split("\t", $_);
	if($disease !~ /^ICD10/){
	    if($genes{$gene}{$prot}){
		my $already_seen=$genes{$gene}{$prot};
		if($already_seen !~ /$disease/){
		    $genes{$gene}{$prot}.="; $disease($type)";
		}
	    }
	    else{
		$genes{$gene}{$prot}=$disease."($type)";
	    }
	}
    }
    close(IN);
}


1;
