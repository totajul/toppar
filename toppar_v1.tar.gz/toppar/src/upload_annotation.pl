#!/usr/bin/perl

use strict;
require "shared_func.pl";

my %Opt;
my %config;
my $Bin;

sub upload_annotation{
    %Opt=%{&get_Opt()};
    %config=%{&get_config()};
    $Bin=&get_Bin();
    my $fields=$Opt{req_fields};
    if($Opt{desc_fields}){$fields.=",".$Opt{desc_fields};}
    if($Opt{scores}){$fields.=",".$Opt{scores};}
    $Opt{req_fields}=$fields;
    my $opt_ref=&check_col_pos(\%Opt, $Opt{infile});
    %Opt=%{$opt_ref};
    my $sql_file=&mk_sql_file(\%Opt);
    my $cmd="mysql -u $config{user} -p$config{password} $config{database} < $sql_file";
    print "$cmd\n";
    my $out=qx($cmd 2>&1); print "Done!\n";
    &rm_file($sql_file);
}


sub mk_sql_file{
    my ($opt_ref)=@_;
    my %Opt=%{$opt_ref};
    my %fields=%{$Opt{fields_ref}};
    my %markers=();
    my $in=$Opt{infile};
    #get ordered col indeces
    if(!(-e $Opt{outdir})){ system("mkdir $Opt{outdir}");}
    my $outfile=$Opt{outdir}."/".basename($in).".sql";
    my %scores=%{&str2hash($Opt{scores})};
    my %desc_fields=%{&str2hash($Opt{desc_fields})};    
    my ($cut, $data_pos_ref)=&get_ordered_col_index(\%Opt);
    my %data_pos=%{$data_pos_ref};
    my $cat="cat";
    print "\n*** Reading $Opt{infile} ***\n";
    if($in =~ /gz$/){$cat="zcat";}
    open(IN, "$cat $in | $cut |") or die "couldnt open $in\n";
    (my $h= <IN>) =~ s/\#//;    
    open(OUT, ">$outfile") or die "Cant open $outfile \n";
    while(<IN>){
	chomp();
	my @data =split(" ",$_);
	my $id=$data[$data_pos{MARKER_ID}];
	my $chrom=$data[$data_pos{CHROM}];
	my $beg=$data[$data_pos{BEG}];
	my $type=$data[$data_pos{TYPE}];
	my $maf=$data[$data_pos{MAF}];
	my $impact=$data[$data_pos{IMPACT}];
	if(($maf =~ /NA/)||($maf =~ /^$/)){
	    $maf=0;
	}
	my ($scores_str,$descf);
	foreach my $key (keys %data_pos){	
	    if($scores{$key}){
		my $score;
		if($data[$data_pos{$key}] =~ /^(\.|)$/){
		    $score="NA";
		}
		else{
		    $score=$data[$data_pos{$key}];
		    if(($score > 0) && ($score < 1)){
			$score=sprintf "%.4f", $data[$data_pos{$key}];#rounded to 4 decimals  
			$score =~ s/0$//;
		    }
		}
		$scores_str.="$key:$score;";
	    }
	    if($desc_fields{$key}){
		$descf.="$key:$data[$data_pos{$key}];";
	    }
	}
	$scores_str =~ s/;$//;
	$descf =~ s/;$//;
	my $sql_cmd="UPDATE marker SET maf=\"$maf\",annot=\"$type\",scores=\"$scores_str\",description=\"$descf\",impact=\"$impact\"  WHERE name=\"$id\" AND genome_build_id=(select genome_build_id from genome_build where name=\"$Opt{build}\");";
	print OUT $sql_cmd."\n";
    }
    close(OUT);close(IN);
    print "Finished reading file. \n";
    return $outfile;
}

1;
#print "\nmarker file:\t\t[$marker_f]\nmarker mapping file:\t [$marker_mapping_f]\n\n";

