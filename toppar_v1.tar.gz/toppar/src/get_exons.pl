#!/usr/bin/perl

use strict;
use Cwd;
require "shared_func.pl";

sub get_and_upload_exons{
    my ($opt_ref, $conf_ref, $Bin, $genome_build_id, $genes_ref)=@_;
    print "*** Inserting EXON annotation *** \n\n";
    my $file=&get_exon_file($opt_ref, $conf_ref, $Bin);
    my $exons_ref=&read_exons_file($file);
    my $genes_ref=get_gene_ids($opt_ref, $conf_ref, $genome_build_id, $genes_ref);
    &upload_exons($opt_ref, $conf_ref, $exons_ref, $genes_ref);
}

sub get_exon_file{
    my ($opt_ref, $conf_ref, $Bin)=@_;
    %Opt=%{$opt_ref};
    my %config=%{$conf_ref};
    #check if resource dir exists, if not, create it
    my $resource_dir=&get_resource_dir($conf_ref, $Bin);
    my $exons_file=$resource_dir."/$Opt{build}/mart_human_exons_$Opt{build}.tsv";
    if($Opt{exons}){
        if( -e $Opt{exons}){
            $exons_file=$Opt{exons};
        }
        else{print "Cant find the file [$Opt{exons}]. Aborting! \n";exit;}
    }
    else{ 
	if( ! -e $exons_file){
	    &get_resource_bundle($opt_ref, $conf_ref, $Bin);
	}
    }
    return $exons_file;
}


sub get_gene_ids{
    my ($opt_ref, $conf_ref,$genome_build_id, $genes_ref)=@_;
    %Opt=%{$opt_ref};
    my %genes=%{$genes_ref};
    my %config=%{$conf_ref};
    my %gene_ids=();
    if(!($genome_build_id)){
	$genome_build_id=get_genome_build_id($conf_ref, $Opt{build});
    }
    my $cmd="echo \"select gene_id,name from genes where genome_build_id=$genome_build_id\" | mysql -u $config{user} -p$config{password} $config{database}";
    print "Getting gene ids from the database... \n";
    my $out=qx($cmd 2>&1);
    my @out=split("\n", $out);
    for (my $i=1; $i<$#out+1; $i++){
	my ($id, $name)=split("\t", $out[$i]);
	$genes{$name}{gene_id}=$id;
    }
    return \%genes;
}

sub read_exons_file{
    my $file=shift;
    my %exons=();
    my $cat="cat";
    if($file =~ /.gz/){$cat="zcat";}
    print "Reading $file...\n";
    open(IN, "$cat $file | ") or die "Couldnt open $file for reading \n";
    <IN>;
    while(<IN>){
	chomp();
	my ($exon_id,$start, $end)=split("\t", $_);
	$exons{$exon_id}{start}=$start;
	$exons{$exon_id}{end}=$end;
    }close(IN);
    return \%exons;
}


sub upload_exons{
    my ($opt_ref, $conf_ref, $exons_ref, $genes_ref, $genes_id_ref)=@_;
    my %config=%{$conf_ref};
    my %Opt=%{$opt_ref};
    my %genes=%{$genes_ref};
    my %exons=%{$exons_ref};
    my $outfile=$config{json_dir}."/exons.sql";
    open (OUT, ">$outfile") or die "Couldnt open $outfile for writing \n";
    foreach my $gene (keys %genes){
	foreach my $exon (keys %{$genes{$gene}{exons}}){
	    my $entry=qq($genes{$gene}{gene_id},$exon,$exons{$exon}{start},$exons{$exon}{end},$genes{$gene}{chr});
	    print OUT "$entry\n";
	}
    }
    close(OUT);
    (my $loadfile=$outfile)=~ s/exons/exons_load/;
    open(OUT, ">$loadfile") or die "Couldnt open $loadfile for writing \n";
    print OUT "CREATE TEMPORARY TABLE exons_tmp LIKE exons;\n";
    print OUT "LOAD DATA LOCAL INFILE '$outfile' INTO TABLE exons_tmp\nFIELDS TERMINATED BY ','\nLINES TERMINATED BY '\\n'\n(gene_id, ensembl_id,start_bp,end_bp,chr);";
    print OUT "SHOW COLUMNS FROM exons;\nINSERT INTO exons\nSELECT * FROM exons_tmp \nON DUPLICATE KEY UPDATE ensembl_id=VALUES(ensembl_id);\n";
    print OUT "DROP TEMPORARY TABLE exons_tmp;\n";
    my $cmd="mysql -u $config{user} -p$config{password} $config{database} < $loadfile";
    print "\nInserting exons into the database... \n";
    
    my $os=$Config{osname};
    my $mysql="mysql";
    if($os !~ /darwin/i){
	$mysql=$mysql." --local-file=1";
    }
    my $cmd=$mysql." ".$cmd;
    print "$cmd\n";
    execute_command($cmd, "Insertion of exons complete.");
    #cleanup
    `rm $outfile`;
    `rm $loadfile`;
}

1;

