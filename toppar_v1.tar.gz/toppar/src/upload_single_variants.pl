#!/usr/bin/perl 

use strict;
#require "shared_func.pl";

my %Opt;
my %config;
my $Bin;

sub upload_single_variant_test_results{
    my $files_ref=shift;
    %Opt=%{&get_Opt()};
    %config=%{&get_config()};
    $Bin=&get_Bin();
    my $func="single";
    my $fields_hash_ref=&str2hash($Opt{req_fields}.",".$Opt{desc_fields});
    $Opt{fields_ref}=$fields_hash_ref; 
    my @scan_files;
    foreach my $f (@{$files_ref}) {
	$Opt{infile}=$f;
	my $opt_ref=&check_col_pos(\%Opt, $f);
	my $results_ref=&get_data($opt_ref, $f);
	my ($scanfile, $condfile)=&write_scanfile($opt_ref, $f, $results_ref, $func);
	&upload_scanfile($scanfile);
	my $cmd=&mysql()." < $condfile";
	&execute_cmd($cmd, "Insertion of condensed data for $f is complete.", "Could not insert condensed data for $f.");
        &rm_file($scanfile);
	&rm_file($condfile);
    }
}

sub get_data{
    my ($opt_ref, $file)=@_;
    my %Opt=%{$opt_ref};
    my %fields=%{$Opt{fields_ref}};
    #get ordered col indeces
    my $cut="cut -f ";
    my %data_pos=();
    my $i=0;

    foreach my $col (sort {$fields{$a} <=> $fields{$b}} keys %fields){
	$cut.=$fields{$col}.",";
	$data_pos{$col}=$i;
	$i++;
    }$cut =~ s/,$//;
    my $cat="cat";
    if($file =~ /gz$/){$cat="zcat";}
    open(IN, "$cat $file | $cut |") or die "couldnt open $file\n";
    (my $h= <IN>) =~ s/\#//;    
    my @desc=split(",", $Opt{desc_fields});
    my %desc_h=();
    my %results=();

    foreach my $d (@desc){$desc_h{$d}=1;};
       while(<IN>){
	chomp();
	my $name;my $descr;
	my @data=split(" ",$_);
	my $marker_id=$data[$data_pos{MARKER_ID}];
	my $pvalue=$data[$data_pos{PVALUE}];
	my $log10=0;
	if($pvalue > 0 ){
	    $log10=-(log($pvalue)/log(10));
	}
	my $refalt;
	 
	if($marker_id =~ /.*_(\S+)_(rs\S+)/){
	    $refalt=$1;$name=$2;
	}
	elsif($marker_id =~ /(\S+):(\d+)_(.*)/){
	    $name=$1."_".$2;$refalt=$3;
	}
	else{
	    $name=$marker_id;
	}
	foreach my $field (keys %fields){
	    if($desc_h{$field}){
		if(length($data[$data_pos{$field}]) > 0){
		    $descr.="$field:".$data[$data_pos{$field}].";";
		}
	    }
	}
	#$descr.="RefAlt:$refalt<BR>P:$pvalue";
	$descr.="P:$pvalue";
	$results{$name}{pval}=$pvalue;
	$results{$name}{desc}=$descr;
	$results{$name}{log10}=$log10;
    }
    return \%results;
}


	
1;
