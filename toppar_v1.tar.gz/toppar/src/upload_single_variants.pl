#!/usr/bin/perl 

use strict;
require "shared_func.pl";

sub upload_single_variant_test_results{
    my ($opt_ref, $conf_ref, $Bin, $files_ref)=@_;
    my %Opt=%{$opt_ref};
    my $func="single";
    my $fields_hash_ref=&str2hash($Opt{req_fields}.",".$Opt{desc_fields});
    $Opt{fields_ref}=$fields_hash_ref; 
    my @scan_files;
    foreach my $f (@{$files_ref}) {
	$Opt{infile}=$f;
	my $opt_ref=&check_col_pos(\%Opt, $f);
	my $results_ref=&get_data($opt_ref, $f);
	push(@scan_files,  &write_scanfile($opt_ref, $f, $results_ref,$func));
    }
    &upload_scanfiles(\@scan_files, \%Opt, $conf_ref, $Bin);
}

sub get_data{
    my ($opt_ref, $file)=@_;
    my %Opt=%{$opt_ref};
    my %fields=%{$Opt{fields_ref}};
    #get ordered col indeces
    my $cut="cut -f ";
    my %data_pos=();
    my $i=0;

    foreach my $col (sort {$fields{$a} <=> $fields{$b}} keys %fields){
	$cut.=$fields{$col}.",";
	$data_pos{$col}=$i;
	$i++;
    }$cut =~ s/,$//;
    my $cat="cat";
    if($file =~ /gz$/){$cat="zcat";}
    open(IN, "$cat $file | $cut |") or die "couldnt open $file\n";
    (my $h= <IN>) =~ s/\#//;    
    my @desc=split(",", $Opt{desc_fields});
    my %desc_h=();
    my %results=();

    foreach my $d (@desc){$desc_h{$d}=1;};
       while(<IN>){
	chomp();
	my $name;my $descr;
	my @data=split(" ",$_);
	my $marker_id=$data[$data_pos{MARKER_ID}];
	my $pvalue=$data[$data_pos{PVALUE}];
	my $refalt;
	if($marker_id =~ /.*_(\S+)_(rs\S+)/){
	    $refalt=$1;$name=$2;
	}
	elsif($marker_id =~ /(\S+):(\d+)_(.*)/){
	    $name=$1."_".$2;$refalt=$3;
	}
	else{
	    $name=$marker_id;
	}
	foreach my $field (keys %fields){
	    if($desc_h{$field}){
		if(length($data[$data_pos{$field}]) > 0){
		    $descr.="$field:".$data[$data_pos{$field}]."<BR>";
		}
	    }
	}
	#$descr.="RefAlt:$refalt<BR>P:$pvalue";
	$descr.="P:$pvalue";
	$results{$name}{pval}=$pvalue;
	$results{$name}{desc}=$descr;
    }
    return \%results;
}


	
1;
