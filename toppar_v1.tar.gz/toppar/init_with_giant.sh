#!/bin/sh

echo "*** Configure and create the toppar_01 database ***" > toppar.log
date >> toppar.log
perl toppar_db config
perl toppar_db create_db

date >> toppar.log
echo "*** Uploading human genome build GRCh38 ****"; echo; 
perl toppar_db upload_genome_build --build=GRCh38
echo "Finished uploading genome build " >> toppar.log
date >> toppar.log

echo "*** Getting disease associations ****"; echo;
perl toppar_db get_disease_assoc
echo "Finished uploading disease associations" >> toppar.log
date >> toppar.log

echo "*** Getting gwascat data ****"; echo;
perl toppar_db get_gwascat
echo "Got gwascat data " >> toppar.log
date >> toppar.log

echo "Getting reduced giant data " > toppar.log
date >> toppar.log
echo "*** Getting reduced GIANT data ****"; echo;
wget https://github.com/totajul/toppar/raw/master/resources/giant_reduced_hg38.tar.gz .
tar -zxvf giant_reduced_hg38.tar.gz
rm giant_reduced_hg38.tar.gz
echo "Got Giant data " >> toppar.log
#date >> toppar.log

echo "*** Initiating the GIANT population  ****"; echo;
perl toppar_db init_pop --pop=GIANT --build=GRCh38 --filters=ethnicity,sex,test

echo "Making markers file" >> toppar.log
echo >> toppar.log
echo "*** Making the markers file ****"; echo;
perl toppar_db mk_markers --indir=giant_reduced_hg38/  --sfx=txt --outfile=giant_markers.tsv

echo "STARTING MARKER UPLOAD" >> toppar.log
date >> toppar.log
echo "*** Uploading the markers to the database  ****"; echo;
perl toppar_db upload_markers --infile=toppar_out/giant_markers.tsv --build=GRCh38 --pop=GIANT
rm toppar_out/giant_markers.tsv

echo "FINISHED MARKER UPLOAD" >> toppar.log
date >> toppar.log

echo "STARTING UPLOAD OF TEST RESULTS" >> toppar.log
echo date >> toppar.log

echo "*** Uploading association test results ****"; echo;
perl toppar_db single --indir=giant_reduced_hg38/ --pop=GIANT --build=GRCh38 --sfx=txt --desc=A1,A2,FreqA1.Hapmap,b,se,N


echo "*** starting  marker annotation ***"; >> toppar.log

wget https://github.com/totajul/toppar/raw/master/resources/giant_markers_GRCh38.86_snpEff.tsv.tar.gz -P resources
tar -zxvf resources/giant_markers_GRCh38.86_snpEff.tsv.tar.gz  -C resources
#perl toppar_db annot --infile=resources/giant_markers_annot_type_maf.tsv --build=GRCh37 --scores=MAC,EAS_AF,AMR_AF,AFR_AF,EUR_AF,SAS_AF --desc=A1,A2,TSA
perl toppar_db annot --infile=resources/giant_markers_GRCh38.86_snpEff.tsv --build=GRCh38 --desc=TYPE,IMPACT
echo "*** finished uploading marker annotation ***"; >> toppar.log 
date >> toppar.log

echo "FINISHED UPLOADING TEST RESULTS" >> toppar.log
date >> toppar.log

#Get the EUR 1000G genotype file for LD calculations
#wget https://github.com/totajul/toppar/raw/master/resources/genotypes/EUR.tar.gz -P resources/genotypes
#tar -zxvf resources/genotypes/EUR.tar.gz  -C resources/genotypes