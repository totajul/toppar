#!/bin/sh

# This script can be used to upload subsets of Inflammatory Bowel Disease (IBD), Crohn's and UC (Ulcerative colitis) data, originally downloaded from the International Inflammatory Bowel Disease Genetics Consortium (IIBDGC), (https://www.ibdgenetics.org).

echo "*** Getting reduced IBD data ****"; echo;
wget https://github.com/totajul/toppar/raw/master/resources/IIBD_hg38.tar.gz .
tar -zxvf IIBD_hg38.tar.gz -C resources
rm IIBD_hg38.tar.gz

perl toppar_db init_pop --pop=IBD --build=GRCh38 --filters=ethnicity,sex,test

perl toppar_db mk_markers --indir=resources/IIBD_hg38/  --sfx=txt --outfile=ibd_markers.tsv

perl toppar_db upload_markers --infile=toppar_out/ibd_markers.tsv --build=GRCh38 --pop=IBD

perl toppar_db single --indir=resources/IIBD_hg38 --pop=IBD --build=GRCh38 --sfx=txt --desc=A1,A2,FRQ_A_5956,FRQ_U_14927,INFO,OR,SE

rm toppar_out/ibd_markers.tsv
