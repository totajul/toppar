#!/bin/sh

echo "*** Getting reduced GLGC data ****"; echo;

wget https://github.com/totajul/toppar/raw/master/resources/GLGC_hg38.tar.gz .
tar -zxvf GLGC_hg38.tar.gz -C resources
rm GLGC_hg38.tar.gz

perl toppar_db init_pop --pop=GLGC --build=GRCh38 --filters=ethnicity,sex,test

perl toppar_db mk_markers --indir=resources/GLGC_hg38/  --sfx=txt --outfile=glgc_markers.tsv

perl toppar_db upload_markers --infile=toppar_out/glgc_markers.tsv --build=GRCh38 --pop=GLGC

rm toppar_out/glgc_markers.tsv

perl toppar_db single --indir=resources/GLGC_hg38 --pop=GLGC --build=GRCh38 --sfx=txt --desc=A1,A2,Freq.A1.1000G.EUR,beta,se,N,PVALUE

