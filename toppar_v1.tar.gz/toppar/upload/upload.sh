#!/bin/bash

java -Xmx16G -classpath "bin/:etc/:lib/ibatis.jar:lib/mysql.jar:lib/seq.jar:lib/toppar_load.jar" load.Main $*
