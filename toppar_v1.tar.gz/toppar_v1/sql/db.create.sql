
CREATE DATABASE IF NOT EXISTS toppar_01;

use toppar_01;
--
-- Tables
--
DROP TABLE IF EXISTS phenotype;
CREATE TABLE phenotype (
  phenotype_id int(11) NOT NULL auto_increment,
  name varchar(100) NOT NULL default '',
  description text,
  public_name varchar(100) default NULL,
  PRIMARY KEY  (phenotype_id),
  UNIQUE KEY xname (name)
) ENGINE=innodb DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS chromosome;
CREATE TABLE chromosome (
  chromosome_id int(11) NOT NULL auto_increment,
  name varchar(100) NOT NULL,
  genome_build_id int(11) NOT NULL,
  length int(11) NOT NULL,
  PRIMARY KEY  (chromosome_id),
  UNIQUE KEY xchromosome (name, genome_build_id)
) ENGINE=innodb DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS genome_build;
CREATE TABLE genome_build (
  genome_build_id int(11) NOT NULL auto_increment,
  name varchar(100) NOT NULL default '',
  date date default NULL,
  species varchar(100) default NULL,
  comments varchar(100) default NULL,
  PRIMARY KEY  (genome_build_id),
  UNIQUE KEY xname (name)
) ENGINE=innodb  DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS genome_scan;
CREATE TABLE genome_scan (
  genome_scan_id int(11) NOT NULL auto_increment,
  phenotype_id int(11) NOT NULL default '0',
  population_id int(11) NOT NULL default '0',
  genome_build_id int(11) NOT NULL default '0',
  comments text,
  PRIMARY KEY  (genome_scan_id,population_id),
  UNIQUE KEY (genome_build_id,population_id,phenotype_id)
) ENGINE=innodb DEFAULT CHARSET=latin1;


--
-- Table structure for table genome_subscan
--

DROP TABLE IF EXISTS genome_subscan;
CREATE TABLE genome_subscan (
  genome_subscan_id int(11) NOT NULL auto_increment,
  genome_scan_id int(11) NOT NULL,
  plot_type varchar(30) NOT NULL default 'point',
  label varchar(64) NOT NULL,
  unit varchar(20) default NULL,
  thresh float default NULL,
  evalue varchar(11) default NULL,
  f1 varchar(30) default NULL,
  f2 varchar(30) default NULL,
  f3 varchar(30) default NULL,
  PRIMARY KEY  (genome_subscan_id),
  UNIQUE KEY xgenome_subscan (genome_scan_id, label)
) ENGINE=innodb DEFAULT CHARSET=latin1;

--
-- Table structure for table genome_subscan_results
--

DROP TABLE IF EXISTS genome_subscan_results;
CREATE TABLE genome_subscan_results (
  result_id int(11) NOT NULL auto_increment,
  genome_subscan_id int(11) NOT NULL default '0',
  marker_id int(11) NOT NULL default '0',
  score float NOT NULL default '0',
  description varchar(200) default NULL,
  PRIMARY KEY  (result_id),
  UNIQUE KEY (genome_subscan_id, marker_id),
  KEY xgenome_subscan (genome_subscan_id),
  KEY xmarker1 (marker_id)
) ENGINE=innodb DEFAULT CHARSET=latin1;

--
-- Table structure for table marker
--

DROP TABLE IF EXISTS marker;
CREATE TABLE marker (
  marker_id int(11) NOT NULL auto_increment,
  name varchar(100) NOT NULL default '',
  genome_build_id int(11) NOT NULL default '0',
  maf float NOT NULL default '0',
  annot varchar(100) default NULL,
  description varchar(300) default NULL,
  scores varchar(300) default NULL,
  PRIMARY KEY  (marker_id),
  UNIQUE KEY xmarker_name (name,genome_build_id)
) ENGINE=innodb  DEFAULT CHARSET=latin1;

--
-- Table structure for table marker_mapping
--

DROP TABLE IF EXISTS marker_mapping;
CREATE TABLE marker_mapping (
  marker_mapping_id int(11) NOT NULL auto_increment,
  marker_id int(11) NOT NULL default '0',
  chromosome varchar(10) NOT NULL default '',
  bp_position int(11) NOT NULL default '0',
  strand int(1) NOT NULL default '1',
  PRIMARY KEY  (marker_mapping_id),
  UNIQUE KEY (marker_id,chromosome,bp_position),
  KEY xbp_position (bp_position)
) ENGINE=innodb DEFAULT CHARSET=latin1;


--
-- Table structure for table population
--

DROP TABLE IF EXISTS population;
CREATE TABLE population (
  population_id int(11) NOT NULL auto_increment,
  name varchar(100) NOT NULL default '',
  f1h varchar(100) NOT NULL default '',
  f2h varchar(100) NOT NULL default '',
  f3h varchar(100) NOT NULL default '',
  PRIMARY KEY  (population_id),
  UNIQUE KEY xname (name)
) ENGINE=innodb DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS condensed_basic;
CREATE TABLE condensed_basic(
 genome_subscan_id int(11) NOT NULL default '0',
 chromosome varchar(10) NOT NULL default '',
 bp_position int(11) NOT NULL default '0',
 score float default NULL,
 UNIQUE KEY (genome_subscan_id, chromosome, bp_position)
)ENGINE innodb DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS condensed_genome_subscan;
CREATE TABLE condensed_genome_subscan(
  genome_subscan_id int(11) NOT NULL default '0',
  genome_build_id int(11) NOT NULL default '0',
  width int(11)	NOT NULL default '0',
  density float default NULL,
  UNIQUE KEY (genome_subscan_id, genome_build_id,width)
) ENGINE=innodb DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS condensed_genome_subscan_results;
CREATE TABLE condensed_genome_subscan_results(
  genome_subscan_id int(11) NOT NULL default '0',
  genome_build_id int(11) NOT NULL default '0',
  chromosome varchar(10) NOT NULL default '',
  width int(11)	NOT NULL default '0',
  start int(11) NOT NULL default '0',
  count int (11) NOT NULL default '0',
  min float NOT NULL default '0',
  max float NOT NULL default '0',	
  UNIQUE KEY (genome_subscan_id, genome_build_id,chromosome,width,start)
) ENGINE=innodb DEFAULT CHARSET=latin1;
   
DROP TABLE IF EXISTS genes;
CREATE TABLE genes(
        gene_id int(11) NOT NULL auto_increment,
	name varchar(100) default '',
	ensembl_id varchar(100) NOT NULL default '',
	ensembl_protein_id varchar(100) default '',
	chromosome varchar(30) NOT NULL default '',
	strand varchar(3) default '',
	start_bp int(11) NOT NULL default '0',
	end_bp int(11) NOT NULL default '0',
	genome_build_id int(11) default '0',
	description varchar(200) default '',
	disease varchar(200) default '',
	external_id varchar(30) default '',
        PRIMARY KEY  (gene_id),	    
        UNIQUE KEY (gene_id, ensembl_id,chromosome, start_bp, end_bp) 	
)	ENGINE=innodb DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS proteins;
CREATE TABLE proteins(
       protein_id int(11) NOT NULL auto_increment,
       gene_id int(11) NOT NULL default '0',
       ensembl_id varchar(100) NOT NULL default '',
       disease varchar(300) default '',
       PRIMARY KEY (protein_id),     
       UNIQUE KEY (protein_id, gene_id)
)      ENGINE=innodb DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS exons;
CREATE TABLE exons(
       exon_id int(11) NOT NULL auto_increment,
       gene_id int(11) NOT NULL  default '0',
	ensembl_id varchar(100) NOT NULL default '',
        start_bp int(11) NOT NULL default '0',
	end_bp int(11) NOT NULL default '0',
	chr varchar(10) NOT NULL default '0',
	PRIMARY KEY  (exon_id),	     
	UNIQUE KEY (exon_id,start_bp, end_bp) 	
)	ENGINE=innodb DEFAULT CHARSET=latin1;

