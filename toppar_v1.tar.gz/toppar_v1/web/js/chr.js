
function getChrArray(){
  return chr_names;
}

function getChr(index){
  return chr_names[index];
}

function getChrLength(chr){
  return chr_lengths[getChrIndex(chr)];
}

function getChrEnd(index){ 
  return chr_ends[index];
} 

function getNoOfChr(){
  return chr_names.length;
}


function getChrIndex(chr){
  var index;
  $.each(chr_names, function(i, name){
	   if(chr == name)
	     index=i;
	 });
  return index;
}

function setChrEnds(){
  chr_ends=[];
  var sum=0;
  $.each(chr_lengths, function(i, chrLength){
	   sum=sum+parseInt(chrLength);
	   chr_ends.push(sum);
	 });
}
