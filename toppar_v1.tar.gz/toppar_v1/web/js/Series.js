
function Plot(phenoIndex, chr, condensed, from, to, phenoType){
  this.phenoIndex=phenoIndex;
  this.phenoType=phenoType;
  this.seriesArray=[];
  // this.gwasData;
  this.markersArray=[];
  this.chr=chr;
  this.from=from;
  this.to=to;
  this.condensed=condensed;
  this.ranges;
  this.placeHolder; 
  this.overviewPlaceHolder;
  this.markersPlaceHolder;
  this.flotplot;
  this.overviewPlot;
  this.markerPlot;
  this.labelsDiv;
  this.noData=[];//an array to store the scan_types that have no data
}

Plot.prototype.setRanges=function(ranges){
  this.ranges=ranges;
}

    Plot.prototype.getSeries=function(){
	return this.seriesArray;
    }
	Plot.prototype.addSeries=function(series){
	    this.seriesArray.push(series);
	}

Plot.prototype.rmGwasSeries=function(){
    var seriesArrayTmp=[];
    var seriesArrayTmp=Array.from(this.seriesArray);
    $.each (this.seriesArray, function(i, series){
	if(typeof(series) != "undefined"){
	    if(series.gwasCatalog){
		var noGwasElements=(seriesArrayTmp.length)-i;
		seriesArrayTmp.splice(i, noGwasElements);
	    }
	}
	});
    this.seriesArray=Array.from(seriesArrayTmp);
}
    
Plot.prototype.rmSeries=function(){
    this.seriesArray.pop();
}

Plot.prototype.addNoData=function(phenotype){
  this.noData.push(phenotype);
}
Plot.prototype.addMarkers=function(markers){
    this.seriesArray=markers;
}
    
	 
function Markers(typeIndex){
    this.data=[];
    this.typeIndex=typeIndex;
    this.color="#FF0000";
    this.plot_type="point";
}
Markers.prototype.addJsonData=function(json){
    this.data=json.data;
}


function Series(typeIndex){
  this.data=[];
  this.origData=[];
  this.chunks={};
  this.typeIndex=typeIndex;
  this.color;
  this.trait_loci=[]; //In plot instead??
  this.file=[];
  this.label;
  this.maxScore;
  this.plot_type;
  this.unit;
  this.json=[];
  this.pointsOnDisplay;
  this.pointsWithinInterval;
  this.origDataWithinInterval;
  this.fullData;
  this.thresh;
  this.evalue;
  this.show=true;
  this.gwasCatalog=false;
  this.terms=" ";
}

Series.prototype.setGwasCatalog=function(val,first){
    this.gwasCatalog=val;
}

Series.prototype.addJsonData=function(json){
  this.origData=json.data; //.sort();
  this.data=json.data;
  this.file=json.file;
  this.label=json.label+" ("+this.origData.length+")";
  this.maxScore=json.maxScore;
  this.plot_type=json.plot_type;
  this.unit=json.unit;
  this.trait_loci=json.trait_loci;
  this.thresh=json.thresh;
  this.evalue=json.evalue;
  this.show=true;
}

Series.prototype.setNoOfPoints=function(points){
  this.noOfPoints=points;
}

Series.prototype.addGwasCatData=function(data, color,terms, gwasSeries){
    this.data=data;
    this.origData=data;
    this.terms=terms;
    this.label="GWAS catalog : "+terms+"("+this.data.length+")";
    this.color=color;
    this.gwasCatalog=true;
    this.points={show: true, radius : 1, fillColor:color}; 
    this.lines={show:false};
    this.maxScore=gwasSeries.maxScore;
    this.plot_type=gwasSeries.plot_type;
    this.unit=gwasSeries.unit;
    this.thresh=gwasSeries.thresh;
    this.evalue=gwasSeries.evalue;
    this.file=undefined;
    this.trait_loci=undefined;
}
  
Series.prototype.setIntervalPoints=function(points){
    this.pointsWithinInterval=points;
}
Series.prototype.getIntervalPoints=function(){
      return this.pointsWithinInterval;
}

      Series.prototype.getPercentage=function(){
	var result=((this.pointsOnDisplay/this.pointsWithinInterval)*100).toFixed(2);
	return result;
  }

Series.prototype.setData=function(data){
  this.data=data;
}
  Series.prototype.setColor=function(color){
    this.color=color;
  }
    
    Series.prototype.getChunk=function(jsonFile){
      if(this.chunks[jsonFile])
	return this.chunks[jsonFile];
      else
	return "null";
    }

    Series.prototype.addToData=function(dataChunk){
      this.data=this.data.concat(data);
      this.data.sort();
    }
      
      Series.prototype.addChunk=function(file,data){
	this.chunks[file]=new Chunk(file,data);

	//	this.chunks.push(new Chunk(file, data));
	// this.data=this.data.concat(data);
	//this.data.sort();
      }
	
	
	function Chunk(jsonFile, data){
	  this.data=data;
	  this.jsonFile=jsonFile;
	}
