
function showMarkerPlot(ranges,markerDiv){
    $("#markers").show(); 
    $("#spacefiller").show();
    var markerPlotDiv=$("#markerPlot");
    var labelsDiv=$("#marker_labels");
    var test=[];    
    var markersArray=markerPlot.getSeries();
    console.log("labelsDIV ");
    console.log(labelsDiv);
    //make sure checkbox stay checked
    //$(labelsDiv+' input[type=checkbox]').each(function(){
    //	var labelCh=$(this).attr('value');
    //	$.each(markerPlot.seriesArray, function(i, series){
    //		if(labelCh === series.label){
    //		    if (series.points.show == false){
    //	/		$(this).prop("checked", true);
    //		    }
    //		}
    //	    });
    //});    

    try{
	markerPlot.flotplot=$.plot(markerPlotDiv, markersArray, getMarkerPlotOptions(labelsDiv,ranges.xaxis.from.toFixed(0), ranges.xaxis.to.toFixed(0), annot_cats.length+1 )); //, getComments(plot.markersArray, ranges)));
    }
    catch(e){alert("ERROR when creating markerPlot "+e);
    }   
    try{
	//	$.plot(maxrkerPlotDiv, markersArray.MAF, getMarkerPlotOptions(labelsDiv,ranges.xaxis.from.toFixed(0), ranges.xaxis.to.toFixed(0), annot_cats.length+1 )); //, getComments(plot.markersArray, ranges)));
    }
    catch(e){alert("ERROR when creating markerPlot "+e);
    }   
    bindMarkerPlotHover(markerPlotDiv, markersArray); 
    bindMarkerPlotClick(markerPlotDiv, markersArray);
}

function change_marker_score(val){
    if(currentScore != val){
	console.log("We are diffferent and need changing "+currentScore+ " and "+val);
	currentScore=val;
	var markersArray=markerPlot.getSeries();
	$.each(markersArray, function(i, mo){
	    var test=0;
	    $.each(mo.data, function(j, dataEntry){
		if(typeof(dataEntry[6]) == "undefined"){
		    dataEntry[1]=0;
		}else{
		    dataEntry[1]=dataEntry[6][val];
		}
	    });
	});
	console.log(plots[0]);
	showMarkerPlot(plots[0].ranges);
    }
}

function getComments(plot, ranges){
    var markersArray=plot.markersArray;
    var phenoIndex=plot.phenoIndex;
    var cmts=[];
    var y_from=9; var y_to=14;
    var count=2;
    var c;var test=0;
    //$("#marker"+phenoIndex).height(150);
    //$("#spacefiller").height(50);
    $.each(markersArray, function(j, series){
	    $.each(series.data, function(i,data){ 
		    var pos=data[0];
		    var name=data[2];
		    var casecount=data[3];
		    var controlcount=data[4];
		    var annot=data[5].split(" ");
		    var type=annot[0];
		    var algo5=annot[1];
		    var ref_alt=annot[2];
		    var x_from=ranges.xaxis.from.toFixed(0); 
		    var x_to=ranges.xaxis.to.toFixed(0); 
		    if((pos > x_from) && (pos < x_to)){
			var answer=count % 2;
			var y_pos=10;
			var n="{position: \'top\'}";
			if(test){
			    y_pos=18;
			    test=0;
			}
			if (answer != 0){
			    y_pos=-16;
			    test=1;
			}		
			if($("#annot"+phenoIndex).is(":checked")){
			    cmts.push({x: pos, y: y_pos, contents: type});
			}
			else if ($("#genocounts"+phenoIndex).is(":checked")){
			    var comment=casecount+"<BR>"+controlcount;
			    cmts.push({x: pos, y: y_pos, contents: comment}); //, notch: n});
			}
			else if($("#5algo"+phenoIndex).is(":checked")){
			    cmts.push({x: pos, y: y_pos, contents: algo5});
			}
			count=count+1;
		    }
		    
		});
	});
    	return cmts;
}

function getAnnotColor(type){
    var cat2="#FF0000";
    var cat1="#FFB6C1";
    var cat3="#708090";
    var cat4="#COCOCO";
    if((type == "FRAME_SHIFT")||(type =="NON_SYNONYMOUS_START")||(type == "START_LOST") || (type == "STOP_GAINED")||(type =="STOP_LOST")){
	return cat1;
    }
    else if((type == "CODON_CHANGE_PLUS_CODON_DELETION" )||(type == "CODON_CHANGE_PLUS_CODON_INSERTION")||(type == "CODON_DELETION")||(type == "CODON_INSERTION" )||(type =="NON_SYNONYMOUS_CODING")){
	return cat2;
    }
    else if(("START_GAINED" == type)||("SYNONYMOUS_CODING" == type)||("SYNONYMOUS_STOP" == type)||("UTR_3_PRIME" == type)||("UTR_5_PRIME" == type)){
	return cat3;
    }
    else{  //"DOWNSTREAM": cat4,"EXON": cat4,"INTERGENIC":  cat4,"INTRON": cat4,"UPSTREAM": cat4,
	return cat4;
    }
}





