

function Gene(data){
  this.name=data[0];
  this.ensId=data[1];
  this.chr=data[2];
  this.bpStart=data[3];
  this.bpEnd=data[4];
  this.strand=data[5];  
  this.desc=data[6];
  this.ensID_protein=data[7];
  this.disease=data[8];
}

function Exon(data){
    this.name=data[0];
    this.bpStart=data[1];
    this.bpEnd=data[2];
    this.strand=data[3];
}
