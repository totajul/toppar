#!/usr/bin/perl -w

use strict;
require "gscandb.pl";
my $db;
use File::Basename;

sub GetCondensedScan{
  my ($url,$outfile,$genome_subscan_id, $genome_build_id, $label, $pheno, $build, $genome_scan_id, $chr, $scanCount, $startResId, $database)=@_;
 
  open(TMP, ">/tmp/condense_debug3.txt") or die "Couldnt open condense_debug.txt\n";
  print TMP "In GetCondensedScan ".localtime()."\n"; 
 
  my $SEL_COND="SELECT genome_subscan_id from condensed_basic WHERE genome_subscan_id=\"$genome_subscan_id\" limit 1";
  my $dbh= gscandb_connect($database);
  my $msg;
  $db=$database;

  my @chromosomes;
  my $GET_CHR="SELECT name from chromosome where genome_build_id=\"$genome_build_id\" and name NOT LIKE \"%random\" and name NOT LIKE \"Y\" and name NOT LIKE \"M\"";
  my $ary_ref=$dbh->selectall_arrayref($GET_CHR);

  my $x_chr=0;
  if(@$ary_ref >0){
    foreach my $row (@$ary_ref){
      if(@$row[0] eq "X"){
	$x_chr=1;
      }
      else{
	push(@chromosomes, @$row[0]);
      }
    }
  }  
 
  @chromosomes=sort{$a <=> $b} @chromosomes;
  if($x_chr){
    push(@chromosomes, "X");
  }
  if($dbh){
    print TMP "genome subscan id: ".$genome_subscan_id."\n";
    my $s1=$dbh->prepare($SEL_COND);
    $s1->execute();
    my @data=$s1->fetchrow_array();
    print TMP "@data \n";
    print TMP "SEL_COND \n$SEL_COND\n";
   
#   if(!$data[0]){ #Build the condensed scan if it doesnt already exist
 #     my $cmd="sh /data/www/gscandb/upload/gscanLoad.sh condense genome_subscan_id=$genome_subscan_id build=$build db=$database";
  #    print TMP "$cmd\n";
   #   system($cmd);
    #  print TMP "error: $?\n, $!\n";
    #}
    print TMP "ABOUT TO CREATE JSON \n";
    my $success=createJSON($dbh, $outfile, $genome_scan_id, $genome_subscan_id, $genome_build_id, $label, \@chromosomes, $scanCount, $startResId); 
    if($success){
      return $url;}
    else{
      return "NULL";}
  }
}

 #example: genome_subscan_id 9445, genome_scan_id=2362
sub createJSON{
  my ($dbh, $outfile, $genome_scan_id, $genome_subscan_id,  $genome_build_id, $label, $chr_ref, $scanCount, $startResId, $plot_type)= @_;
  
  my $CHR_LENGTH="select length  from chromosome where genome_build_id=\"$genome_build_id\" and name=?";
  my $TRAIT_LOCI=""; #select mm.bp_position, tl.score from trait_locus tl, marker m1,marker m2, marker_mapping mm1, marker_mapping mm2 where tl.genome_scan_id=\"$genome_scan_id\" and tl.chromosome=? and tl.marker1_id=m1.marker_id and m1.marker_id=mm1.marker_id and tl.marker2_id=m2.marker_id and m2.marker_id=mm2.marker_id and mm2.genome_build_id=\"$genome_build_id\" and mm1.genome_build_id=\"$genome_build_id\""; 
  my $COND_SCAN_CHR="select bp_position, score from condensed_basic where genome_subscan_id=\"$genome_subscan_id\" and chromosome=? order by bp_position";

  my $thrLine; my $trLoci_line; 
  print TMP "Im in createJSON and this is my genome_subscan_id $genome_subscan_id\n";
  $thrLine=getThresholds($dbh,$genome_subscan_id);
  my $maxScore=0; my $pos=0; my $counter=0;my $line; my $chrLine;  my $pos_tl=0;  
  my @chromosomes=@$chr_ref;
  my $chrSize=$#chromosomes+1;
  
  my $chrL=$dbh->prepare($CHR_LENGTH);
  my $trait=$dbh->prepare($TRAIT_LOCI);
  my $cond=$dbh->prepare($COND_SCAN_CHR);
  my $noData=0;
  my $dataForPrevChr=0;
  foreach my $chr (@chromosomes) {
    my $chr_traitLoci;  my $chrLength;
    $cond->execute($chr);
    $chrL->execute($chr);
    my $condArrayRef=$cond->fetchall_arrayref();
    my $chrLengthRef=$chrL->fetchall_arrayref();
    foreach my $ref (@$chrLengthRef) {
      ($chrLength) =  @$ref;
    }
  
    $trait->execute($chr);
    my $traitRef=$trait->fetchall_arrayref();
    my $trLociSize=scalar(@$traitRef);
    if($trLociSize >  0){
      foreach my $ref (@$traitRef) {
        my ($start_pos,$score)=@$ref;
        $start_pos=$start_pos+$pos_tl;
	#$end_pos=$end_pos+$pos_tl;
	#$chr_traitLoci.="[$start_pos, $end_pos, $score],";	
      }
       #$trLoci_line.=$chr_traitLoci;
    }
   $pos_tl+=$chrLength;
    my @condArray=@$condArrayRef;
   print TMP $COND_SCAN_CHR." ".$chr."\n";
    if (scalar(@condArray) > 0 ) {
      my $prevPos2;
      foreach my $ref (@$condArrayRef) {
	my ($pos1, $score)=@$ref;
	my $pos2="";
	$pos1=$pos1+$pos;
	$pos2=$pos2+$pos;
	
	if($pos2 > $prevPos2){ #Temporary solution, and only needed because of an error in the database. The last marker, sometimes has a small number for position 2. Needs to be fixed when markers get inserted.
	  $line.="[$pos1, $score],[$pos2,$score],";
	}
	else{
	  $line.="[$pos1, $score],";
	}
	$prevPos2=$pos2;
	$counter++;
	if ($score > $maxScore) {
	  $maxScore=$score;
	}
      }
    } else {
      $noData++;
      if($noData == scalar(@chromosomes)){
	print TMP "NO RESULTS  for $chr\n";
	return 0; #no condensed data
      }
    }
    $pos+=$chrLength;
    $chrLine.=$pos.",";
  }
  print TMP "Theres no data for $noData chromosomes, Lenght of chromosomes is: ".scalar(@chromosomes)."\n";
  open(OUT, ">$outfile") || die "Couldnt open $outfile for writing \n";
  print OUT "{\n\"label\": \"".$label."\",\n";    
  $line =~ s/\,$/\]}/;
  $chrLine =~ s/\,$/],/;
  if ($trLoci_line) {
    $trLoci_line =~ s/\,$/],/;
    print OUT "\"trait_loci\" : [".$trLoci_line."\n";
  }
  if ($chrSize == 1) {
    print OUT "condensed : \'true\',\n";
  }
 
 if($scanCount){ print OUT "\"scanCount\": \'$scanCount\',\n";};
 if($startResId){ print OUT "\"startResId\": \'$startResId\',\n";};
    
  print OUT $thrLine;
  print OUT "\"maxScore\" : \"".$maxScore."\",\n";
 # print OUT "\"plot_type\" : \"".$plot_type."\",\n";
  print OUT "\"chrLengths\": [".$chrLine."\n";    
  print OUT "\"data\": [";
  print OUT $line."\n";
  close OUT;
  # print "Final count:  $counter \n";
  return 1;
}

sub getThresholds{
  my ($dbh,$genome_subscan_id)=@_;
  my $THRESHOLDS="select thresh, evalue, plot_type,unit from genome_subscan where genome_subscan_id=\"$genome_subscan_id\"";
  my $thr = $dbh->selectall_arrayref($THRESHOLDS);
  my $thrLine;
  # if($#$thr > 0){
  
  foreach my $ref (@$thr) {
    my($t, $e, $plot_type, $unit)=@$ref;
    if ($t){
      $thrLine.= "\"thresh\" : \"".$t."\",\n";}
    if ($e){ 
      $thrLine.= "\"eval\" : \"".$e."\",\n";}
    if ($plot_type){
      $thrLine.= "\"plot_type\" : \"".$plot_type."\",\n";}
    if ($unit){
      $thrLine.= "\"unit\" : \"".$unit."\",\n";}
  }
  return $thrLine;
}

sub delete_condensed_scan {
  my ($dbh, $ssid, $build_id)=@_;
  my $delete1 = "delete from condensed_genome_subscan where genome_subscan_id=\"$ssid\" and genome_build_id=\"$build_id\"";
  my $delete2 = "delete from condensed_genome_subscan_results where genome_subscan_id=\"$ssid\" and genome_build_id=\"$build_id\"";
 
  my $sth_delete1 = $dbh->prepare($delete1);
  my $sth_delete2 = $dbh->prepare($delete2);
 
  $sth_delete1->execute($ssid,$build_id);
  $sth_delete2->execute($ssid,$build_id);
}


sub build_condensed_scan {
  my ( $dbh, $gscan_id, $genome_build_id, $labels,$pheno, $build, $chr) = @_;
  my $genome_subscan_id;
  my $chromosome;
  my $bp1; my $bp2;
  my $binsize; my $info;
  my $start; my $end;
  my $max;my $min;
  my $step=2;
  print TMP "build_condensed_scan ".localtime()."\n";
  print TMP qx{ ps -o rss,vsz $$ }, "\n";
  if ( $dbh ) {
    my ($build_id,$truebuild,$truebuild_id) = true_genome_build( $dbh, $build );
    my $unit; 
    my $select1 = "SELECT b.name, c.name, d.name, a.model, d.genome_build_id FROM genome_scan a, phenotype b, population c, genome_build d WHERE b.phenotype_id = a.phenotype_id AND c.population_id = a.population_id AND d.genome_build_id = a.genome_build_id AND d.name=\"$truebuild\" AND a.genome_scan_id=\"$gscan_id\"";

    my $ar = $dbh->selectall_arrayref($select1);
    
    if ( $ar ) {
      $info = { id=>$ar->[0][0], phenotype=>$ar->[0][0], population=>$ar->[0][1], genome_build=> $ar->[0][2],  model=>$ar->[0][3] };
      
      my $select2 = "SELECT a.genome_subscan_id, a.label, a.plot_type, a.unit, a.thresh1, a.evalue1, a.thresh2, a.evalue2, a.thresh3, a.evalue3 FROM genome_subscan a, genome_scan b  WHERE a.genome_scan_id=b.genome_scan_id AND b.genome_scan_id=\"$gscan_id\" AND a.label=?";

      my $filename = "/tmp/condensed.$$.txt";
      my $upload = "load data local infile \"$filename\" into table condensed_genome_subscan_results(genome_subscan_id,genome_build_id,chromosome,width,start,count,min,max)";
      my $subscans;
      
      open(CONDENSED, ">$filename");
      my $sth2 = $dbh->prepare($select2);
      my $select3_interval;

      $select3_interval = "SELECT DISTINCT e.bp_position, f.bp_position, a.score,  g.name, h.name FROM genome_subscan_results a, marker_mapping e, marker_mapping f, marker g, marker h WHERE a.genome_subscan_id=? AND  e.marker_id = a.marker1_id AND f.marker_id = a.marker2_id  and g.marker_id=a.marker1_id and h.marker_id=a.marker2_id AND f.genome_build_id=\"$build_id\" AND f.chromosome=\"$chr\" AND e.chromosome=\"$chr\" AND e.genome_build_id=\"$build_id\" ORDER BY  e.bp_position";  
      
      # $select3_interval="SELECT * from genome_subscan where genome_subscan_id=?";
    
      my @labels = split( /,/, $labels );
      foreach my $label ( @labels ) {
	$sth2->execute($label);
     
	my $ar2 = $sth2->fetchall_arrayref();

		print TMP "before space ".localtime()."\n";
		print TMP qx{ ps -o rss,vsz $$ }, "\n";
	if ( $ar2 ) {
	  foreach my $item ( @$ar2 ) {
	    my $ssid = $item->[0];
	    my $test = $item->[1];
	    my $plot = $item->[2];
	    $info->{scaninfo}{$test} = {  plot=>$item->[2],  unit=>$item->[3], thresh1=>$item->[4], evalue1=>$item->[5], thresh2=>$item->[6], evalue2=>$item->[7], thresh3=>$item->[8], evalue3=>$item->[9], permutations=>$item->[10], comments=>$item->[11] };
	    $unit->{$item->[3]}++;
	    my $ar3;
	    my ( $max, $min, $start, $end, $scan );
	    my $delta = undef;
	    my $last = undef;
	    my @space;
	    my $meandelta=0;
	    my $ndelta=0;
	    my $r=0;
	    my $count=0;
	    my $sth3_interval = $dbh->prepare($select3_interval);
	    $sth3_interval->execute($ssid);
	    while ( my $ref = $sth3_interval->fetchrow_arrayref() ) {
	      my ( $pos1, $pos2, $score, $marker1, $marker2 ) = @$ref;
	      push @{$scan->{$chr}}, [ $pos1, $pos2, $score ];
	      $max->{$chr} = $score > $max->{$chr} ? $score : $max->{$chr};
	      $min->{$chr} = $score < $min->{$chr} ? $score : $min->{$chr};
	      $start->{$chr} = $pos1 if ( $pos1 < $start->{$chr}  || ! exists($start->{$chr}) );
	      $end ->{$chr}= $pos2 if ( $pos2 > $end->{$chr} || ! exists($end->{$chr})  );
	      $delta = $pos1 - $last + 1 if ( defined($last) );
#	      push @space, $delta if ( defined($delta) );
	      if ( defined($delta) ) {
		$meandelta += $delta;
		$ndelta++;
	      }
	      $last = $pos1;
	      $count++;
	     # print "$count\n" if ( !($count % 100000 ));
	    }
#	    @space = sort @space;
#	    my $minbin = 3*$space[$#space/2];  	#median spacing
	    my $minbin = 3*$meandelta/($ndelta+1);
	    $minbin=1 if ($minbin < 1);
	    my $logminbin = int(log($minbin)/log($step))+1;
	    my $minspacing = int(exp($logminbin*log($step))); # closest number to $step * median spacing
	    my $maxspacing = $minspacing;
	    foreach my $chr ( keys %$max ) {
	      my $d = $end->{$chr}-$start->{$chr}+1;
	      $maxspacing += $d;
	    }
	    $maxspacing /= length(keys %$max);
	    $maxspacing = int(exp((log($maxspacing)/log($step)-1)));
	    $subscans->{$ssid}++;
	    foreach my $chr ( sort keys %$max ) {
	     
	      my @sorted = sort { $a->[0] <=> $b->[0] } @{$scan->{$chr}};
	      my $range = $end->{$chr}-$start->{$chr}+1;
	      if ( $range > 0 ) {
		my $logmaxbin = int(log($range)/log($step))+1;
		my $maxbin = int(exp($logmaxbin*log($step)));
		my $bindata;
 
		my ( $binmax, $binmin, $bincount );
		foreach my $ref ( @sorted ) {
		  my $bin = int($ref->[0]/$minspacing);
		  $binmax->[$bin] = $ref->[2] if ( $binmax->[$bin] < $ref->[2] || ! defined($binmax->[$bin]));
		  $binmin->[$bin] = $ref->[2] if (( defined($ref->[2]) && $binmin->[$bin] > $ref->[2] )|| ! defined($binmin->[$bin])) ;
		  $bincount->[$bin]++ if ( defined($ref->[2]));
		}
		print TMP "BEFORE SLOW BI: ".$#$binmax."\n".localtime()."\n";
		print TMP qx{ ps -o rss,vsz $$ }, "\n";
		for ( my $b=0;$b<=$#$binmax;$b++) {
		  if ( exists( $binmax->[$b] ) ) {
		    $bindata->[$b] = [ $chr, $minspacing, $b*$minspacing, ($b+1)*$minspacing-1, $binmin->[$b], $binmax->[$b], $bincount->[$b] ];
		  } else {
		    $bindata->[$b] = [ $chr, $minspacing, $b*$minspacing, ($b+1)*$minspacing-1, undef, undef, 0 ];
		  }
		}
		print TMP "AFTER SLOW BIT ".localtime()."\n";
		print TMP qx{ ps -o rss,vsz $$ }, "\n";
	      return "NULL";
		my @bindata;
		my @results;

		for ( my $b=0;$b<=$#$bindata;$b++) {
		  $results[$b] = $bindata[$b] = $bindata->[$b];
		}
		while ( $#bindata > 1 ) {
		  my @newbin;
		  for (my $b=0, my $c=0;$b<$#bindata;$b+=$step,$c++) {
		    my @tmp = ($bindata[$b]->[0], $bindata[$b]->[1]*$step, $bindata[$b]->[2], $bindata[$b+$step-1]->[3], undef, undef, 0 );
		    for (my $k=0;$k<$step;$k++) {
		      if ( $bindata[$b+$k]->[6]>0) {
			$tmp[4] = $tmp[4] > $bindata[$b+$k]->[4] || ! defined($tmp[4]) ? $bindata[$b+$k]->[4] : $tmp[4];
			$tmp[5] = $tmp[5] < $bindata[$b+$k]->[5] || ! defined($tmp[5]) ?  $bindata[$b+$k]->[5] : $tmp[5];
			$tmp[6] += $bindata[$b+$k]->[6];
		      }
		    }
		    $newbin[$c] = \@tmp;
		  }
		  unshift @results, @newbin;
		  @bindata = @newbin;
		  @newbin = ();
		}
		for ( my $b=0;$b<=$#results;$b++) {
		  if ( $results[$b]->[6]>0) {
		    #  print  join( "\t", @{$results[$b]} ) . "\n" if ( $results[$b]->[6]>0);
     #getData.cgi pop=HS build=37 pheno=AdrenalMeanWeight scantype=additive condensed=true 
     	#Width too large?? 
	    print CONDENSED join( "\t", $ssid, $build_id, $results[$b]->[0],$results[$b]->[1],$results[$b]->[2],$results[$b]->[6],$results[$b]->[4],$results[$b]->[5]) . "\n" ;
		    $bindata->[$b] = [ $chr, $minspacing, $b*$minspacing, ($b+1)*$minspacing-1, $binmin->[$b], $binmax->[$b], $bincount->[$b] ];
		  }
		}
	      }
	    }
	  }
	}
      }
      close(CONDENSED);
      $dbh->do($upload); 
      unlink($filename);
      foreach my $ssid ( keys %$subscans ) {
	my $select4="select genome_subscan_id, genome_build_id, width, avg(count) from condensed_genome_subscan_results where genome_subscan_id=$ssid and genome_build_id=$build_id group by genome_subscan_id, genome_build_id, width"; 
	my $arr = $dbh->selectall_arrayref($select4);
	my $insert1 = "insert into condensed_genome_subscan( genome_subscan_id, genome_build_id, width, density ) values ( ?, ?, ?, ? )";
	my $sth_insert = $dbh->prepare($insert1);
	foreach my $ref ( @$arr ) {
	  $sth_insert->execute(@$ref); 
#	  print "INSERT $insert1 \n"; 
	 	}
      }
    }
  }
}

sub true_genome_build {  
 
  # get the "true" genome build.  
  # This is only defined for genome builds that are liftovers,  
  # i.e. where all the genome scan data is pinched from data for another "true" build.  
  # Otherwise returns the input value 
 
  my ( $dbh, $build ) = @_; 
  my $truebuild_id=undef;	# for liftover 
  my $build_id = undef; 
  my $truebuild = $build; 
 
  my $getbuild = "SELECT a.genome_build_id, a.liftover, b.name FROM genome_build a, genome_build b WHERE a.name=\"$build\" and b.genome_build_id=a.liftover"; 
 
  my $ar = $dbh->selectall_arrayref($getbuild);  
  if ( $ar->[0] ) { 
    ($build_id,$truebuild_id,$truebuild) = @{$ar->[0]}; 
  } 
  if ( $truebuild_id+0==0) { 
    my $getbuild2 = "SELECT a.genome_build_id  FROM genome_build a WHERE a.name=\"$build\""; 
    my $ar = $dbh->selectall_arrayref($getbuild2); 
    if ( $ar->[0] ) { 
      ($build_id) = @{$ar->[0]}; 
    } 
  } 
 
  if ($truebuild_id+0 == 0 ) { 
    $truebuild_id = $build_id; 
    $truebuild = $build; 
  } 
  return ($build_id,$truebuild,$truebuild_id); 
} 


1;
