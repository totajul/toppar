#!/usr/bin/perl

use strict;
use DBI;

my %config=();

sub getURL{
  my $name=shift;
  &read_config if (keys (%config)<1);  
  my $url=$config{json_url};
  if($url !~ /\/$/){$url.="/";  }  
  return $url.$name;
}

sub getOutfile{
  my $name=shift;
  &read_config if (keys (%config)<1);  
  my $dir=$config{json_dir};
  if($dir !~ /\/$/){$dir.="/";}
  return $dir.$name;
}

sub getOutDir{
   &read_config if (keys (%config)<1);  
  my $dir=$config{json_dir};
  if($dir !~ /\/$/){$dir.="/";}
 return $dir;
}

sub gscandb_connect{
    &read_config if (keys (%config)<1);
    my $database=$config{database}; 
    my $dsn=$config{dsn};
    my $user=$config{user}; 
    my $passwd=$config{password}; 
    return DBI->connect($dsn."=".$database, $user, $passwd);
}


sub read_config{
    open(IN, "../etc/config.txt") or die "Cannot open ../etc/config.txt\n";
    while(<IN>){
	chomp();
	if($_ =~ /(\S+)=(\S+)/){$config{$1}=$2;}
    }close(IN);
}

1;
