var database;
var chr_names;
var chr_lengths;
var chr_ends;
var x_to_gl;
var x_from_gl;
var pop_data;
var menus;
var label2pheno={};

$(document).ready(
     function(){ //do all this once the document is ready
	 $('#noData').hide(); $('#noDataHolder').hide();
	 $('#regionBtns').hide();
	 $("#enableUCSC").attr("checked", false);
	 $("#radio_region").attr("checked",false);
	 $("#radio_genome").attr("checked" , false);
	 $('.tooltip').tooltipster();
	 var browserName=navigator.appName;
	 if (browserName=="Microsoft Internet Explorer") 
	   alert("The Genome Scan Viewer does NOT work in Interet Explorer!! Please use  Chrome, Firefox or Safari instead!");
	 else{
	     emptyTxtBoxes();
	     initGenomeBuildMenu();
	     initPopulationMenu();
	 }    
     });  			


//INITIATE MENUS and Menu functions
$(function(){
	$("select#build").change(function(){
		initPopulationMenu();
	    });
    });
$(function(){
	$("select#population").change(function(){
		initFilterMenus(pop_data);	
		populateMenusOnChange();
	    });
    });

$(function(){
$("select#phenotype").change(function(){
    var phenoInd=$(this).val();
    var f1=[]; var f2=[]; var f3=[]; var labels=[];
    $.each(phenoInd, function(i, phenoI){
	    f1=addData(f1, menus[phenoI].f1s);
	    $.each(menus[phenoI].f1s, function(j, f1_j){
		    f2=addData(f2, f1_j.f2s);
		    $.each(f1_j.f2s, function(k, f2_k){
			    f3=addData(f3, f2_k.f3s);
			    $.each(f2_k.f3s, function (h, labels_h){
				    labels=addData(labels, labels_h.label);
				});
			});
		});
    });
    populateDropDown3($('select#f1'), f1);
    populateDropDown3($('select#f2'), f2);
    populateDropDown3($('select#f3'), f3);
    populateDropDown3($('select#label'), labels);
    });
    });

function getSubMenuf2(){
    var subMenu=[];
    var p_items= $("select#phenotype option:selected").map(function() {
	    return $(this).text();
	}).get();
    var f1_items = $("select#f1 option:selected").map(function() {
	    return $(this).text();
	}).get();
    $.each(menus, function(i, menu){
	    $.each(p_items, function(j, p){
		    if(menu.name === p){
			$.each(menu.f1s, function(k, f1){
				$.each(f1_items, function(h, f1_sel){
					if(f1.name === f1_sel){
					    subMenu.push({name: menu.name, f1s: [{name: f1.name, f2s : f1.f2s}]});
					}
				    });
			    });
		    }
		});
	});
    return subMenu;
}

function getSubMenuf3(){
    var subMenuf2=getSubMenuf2();
    var subMenu=[];
    var f2_items=$("select#f2 option:selected").map(function() {
	    return $(this).text();
	}).get();
    $.each(subMenuf2, function(i, menu){
	    $.each(menu.f1s, function(j, f1){
		    $.each(f1.f2s, function(k, f2){
			    $.each(f2_items, function(h, f2_item){
				    if(f2.name === f2_item){
					subMenu.push({name: menu.name, f1s: [{name: f1.name, f2s : [{name: f2.name, f3s : f2.f3s}]}]});
				    }
				});
			});
		});
     });
    return subMenu;
    
}

function getSubMenuLabel(){
    var subMenuf3=getSubMenuf3();
    var subMenu=[];
    var f3_items=$("select#f3 option:selected").map(function() {
	    return $(this).text();
    }).get();
    $.each(subMenuf3, function(i, menu){
	    
	    $.each(menu.f1s, function(j, f1){
		    $.each(f1.f2s, function(k, f2){
			    $.each(f2.f3s, function(h, f3){
				    $.each(f3_items, function(l, f3_item){
					    //$.each(f3.label, function(o, label){
					    if(f3.name === f3_item){
						subMenu.push({name: menu.name, f1s: [{name: f1.name, f2s : [{name: f2.name, f3s : [{name: f3.name, label: f3.label}]}]}]});
					    }
					    //  });
					});
				});
			});
		});
	});
    return subMenu;
}

function addData(myArray,items){
    for(var i=0; i< items.length; i++){
	myArray.add(items[i].name);
    }
    return myArray;
}

$(function(){
    $("select#f1").change(function(){
	var f2=[]; var f3=[]; var labels=[];
	var subMenu=getSubMenuf2();
        $.each(subMenu, function(i, m){
	    $.each(m.f1s, function(k, f1){
		f2=addData(f2, f1.f2s);
		$.each(f1.f2s, function(k, f2k){
		    f3=addData(f3, f2k.f3s);
		    $.each(f2k.f3s, function (h, labels_h){
			labels=addData(labels, labels_h.label);
		    });
		});
	    });	
	});	 
	populateDropDown3($('select#f2'), f2);
	populateDropDown3($('select#f3'), f3);
	populateDropDown3($('select#label'), labels);
	});
  });

$(function(){
    $("select#f2").change(function(){
	var subMenu=getSubMenuf3();
	var f3=[]; var labels=[];
        $.each(subMenu, function(i, m){
	    $.each(m.f1s, function(k, f1){
		$.each(f1.f2s, function(k, f2k){
		    f3=addData(f3, f2k.f3s);
		    $.each(f2k.f3s, function (h, labels_h){
			labels=addData(labels, labels_h.label);
		    });
		});
	    });	
	});	 
	populateDropDown3($('select#f3'), f3);
	populateDropDown3($('select#label'), labels);
    });
  });

$(function(){
    $("select#f3").change(function(){
	var subMenu=getSubMenuLabel();
	var labels=[];
	$.each(subMenu, function(i, m){
	    $.each(m.f1s, function(k, f1){
		$.each(f1.f2s, function(k, f2k){
		    $.each(f2k.f3s, function (h, labels_h){
			labels=addData(labels, labels_h.label);
		    });
		});
	    });	
	});	 
	populateDropDown3($('select#label'), labels);
	});
  });



Array.prototype.add = function(element){
    var itemExists = false;
    for(var i=0;i<this.length;i++){
        if(this[i]==element){
            itemExists = true;
            break;
        }
    }
    if(itemExists==false)
        return this.push(element);
}




function populateDropDown3(drop,items){
    drop.empty();
    for(var i=0; i< items.length; i++){
	drop.append('<option value=' +i+ '>'+items[i]+ '</option>');
    }
    drop.show();
}


function populateDropDown(drop,items){
    for(var i=0; i< items.length; i++){
	drop.append('<option value=' +i+ '>'+items[i].name+ '</option>');
    }
}




$(function(){ 
     $('#gene_symbol').keypress(function(e) { 
	    if (e.which == 13){ //if enter was pressed 
	        goTo("gene"); 
		$("#snp").val(""); 
		$("#coord").val("");  
	    }
	}); 
    $('#snp').keypress(function(e) { 
	    if (e.which == 13){ //if enter was pressed 
		goTo("snp"); 
		$("#coord").val(""); 
		$("#gene_symbol").val("");  

	    }
	}); 
    $('#coord').keypress(function(e) { 
	    if (e.which == 13){  //if enter was pressed 
		goToCoord(); 
		$("#snp").val(""); 
		$("#gene_symbol").val("");  

	    }
	});
    $('#gwasTerm').keypress(function(e) { 
	    if (e.which == 13){  //if enter was pressed 
		alert("gwasTerm pressed");

	    }
	});
    
   $('#y_max').keypress(function(e){
	    if(e.which==13)
		reset_y_axis();
	});
    }); 


function showDialog(){
    // $("#coordDialog").dialog();
    alert("to be added....");
}

/* 
   populates the population menu on start up 
*/ 


function getSpecObjByBuild(build){
    var obj;
    $.each(species, function(i, specObj){
	    if(specObj.build == build)
		obj=specObj;
	});
    return obj;
    
}

function getSpecObjByDatabase(){
    var obj;
    $.each(species, function(i, specObj){
	    if(specObj.database == database)
		obj=specObj;
	});
    return obj;
}

function initGenomeBuildMenu(){
    var options='';
    $.each(species, function(i, specObj){
	    options+='<option value='+specObj.build+'>'+specObj.name+'</option>';
	});
    $("select#build").html(options);
    $("#build option[value="+defaultBuild+"]").attr('selected','selected');
}



function initPopulationMenu(){ 
    var build=$("#build").val();
    var specObj=getSpecObjByBuild(build);
    if(specObj)
	database=specObj.database;
    try{ 
	var script=getPopulation_cgi+"?database="+database;           
	console.log("SCRIPT "+script);
	$.ajax({  
		type: "GET",  
		    url: script,  
		    success : function(jsonFile){  
			try{           
			    $.getJSON(jsonFile, function(data){ 
				var options = '';
				for (var i = 0; i < data.length; i++) { 
				    options += '<option>' + data[i].name + '</option>'; 
				} 
				$("select#population").html(options);
				initFilterMenus(data);
				populateMenusOnChange(); 
			    }); 
		    } 
		    catch(e){ 
			alert("error when reading jsonFile "+e); 
		    } 
		}      
	    }); 
    } 
    catch(e){ 
	alert("error when running populateMenus.cgi "+e); 
    }
} 

function initFilterMenus(data){
    //get selected population
    pop_data=data;
    var pop=$("#population").val();
    $("#phenotype").empty();
    $("#label").empty();
    if(pop === "haloplex"){
	$("#phenotype_th").html("Cluster");
    }
    else{
	$("#phenotype_th").html("Phenotype");
    }
    var filter_names="";
    var filters_menu="";
    var filters=[];
    var filter_ids=["f1", "f2", "f3"];
    var filter_th_ids=["f1_th", "f2_th", "f3_th"];
    //first hide all and then show the right number of filters
   //empty menuse
    for(var i=0; i< filter_ids.length; i++){
	$("#"+filter_ids[i]).hide();
	$("#"+filter_th_ids[i]).hide();
    }
    for (var i=0; i < data.length; i++){
	var d=data[i];
	if(d.name === pop){
	    for(var j=0; j< d.filters.length; j++){
		var filter=d.filters[j];
		$("#"+filter_th_ids[j]).show();
		$("#"+filter_th_ids[j]).html(filter);
		$("#"+filter_ids[j]).empty();
		$("#"+filter_ids[j]).show();
	   }
	i=data.length;
	}
    }
}


/* 
   populateMenusOnChange gets called whenever there is a change in the selection menus 
*/ 

function populateDropDown2(drop, items){
    //drop.empty();
    for(var i=0; i< items.length; i++){
	drop.append('<option value=' +i+ '>'+items[i]+ '</option>');
    }
    drop.show();
}




function populateMenusOnChange(){ 
    var build=$("#build").val(); 
    $("#region").hide();
    $("#regionPlots").empty();
    $("#genomePlots").empty();
    $("#backToGenome").hide();
    $("#backToRegion").hide();
    $("#message").empty();
    try{ 
	var pop = $("#population").val();
	var script=populateMenus_cgi+"?pop="+pop+"&build="+build+"&database="+database;
	$.ajax({
		type: "GET",
		    url : script, success : function(jsonFile){
		    //    $.get(populateMenus_cgi ,{pop:pop,build:build,database:database}, function(jsonFile) { 
			try{ 
			    console.log("About to try getJSON");
			    $.getJSON(jsonFile, function(data){ 
				data=data.jsonobj;
				menus=data;
				var f1a=[]; var f2a=[]; var f3a=[]; var labels_a=[];
				populateDropDown($('select#phenotype'), data );
				for (var i = 0; i < data.length; i++) {
				    var f1s=data[i].f1s;
				    var pheno=data[i].name;
				    f1a=addData(f1a, f1s);
				    for(var j=0; j< f1s.length; j++){
					var f2s=f1s[j].f2s;
					f2a=addData(f2a, f2s);
					for(var k=0; k < f2s.length; k++){
					    var f3s=f2s[k].f3s;
					    f3a=addData(f3a, f3s);
					    for(var h=0; h < f3s.length; h++){
						var labels=f3s[h].label;
						labels_a=addData(labels_a, labels);
						label2pheno[labels[0].name]=pheno;
					} 
				    }
				}
			    }
                            populateDropDown2($('select#f1'), f1a);
			    populateDropDown2($('select#f2'), f2a);
			    populateDropDown2($('select#f3'), f3a);
			    populateDropDown2($('select#label'), labels_a);
			
}); 
		    } 
		    catch(e){ 
			console.log("ERROR "+e);
		    }
		} 
	    }); 
    }
    catch(err){ 
	console.log("ERROR AJAX "+err);
    } 
    chromosomeMenu(build); 
    var specObj=getSpecObjByBuild(build);
    $("#speciesImage").empty();
    if(specObj){
	if(specObj.image)
	    $("#speciesImage").append(specObj.image);
    }
    $('#noData').empty(); 
    $('#noDataFor').hide();
    $("#regionBtns").hide();
    //$("#genomePlots").hide();
    // $("#regionPlots").hide();
    //$("#backToGenome").hide();
    //$("#backToRegion").hide(); 
    
}


function getScanTypes(){
    var build=$("#build").val();
    var pop = $("#population").val();
    var phenotypes=$("#phenotype").val();
    var labels=$("select#label option:selected").map(function() {
        return $(this).text();
    }).get();
    try{
	var script=populateMenus_cgi+"?pop="+pop+"&build="+build+"&phenotype="+phenotypes+"&database="+database;
	$.ajax({
	    type: "GET", url: script, success: function(jsonfile){
		try{
		    $.getJSON(jsonfile, function(data){
			var options = ''; 
			  for (var i = 0; i < data.label.length; i++) {
			      options += '<option >' + data.label[i] + '</option>';
			  }$("select#label").html(options);
			options=''; 
			if(data.f1 !== undefined){
			    for (var i = 0; i < data.f1.length; i++) {
				options += '<option >' + data.f1[i] + '</option>';
			    }$("select#f1").html(options);
			}
			options='';
			if(data.f2 !== undefined){
			    for (var i = 0; i < data.f2.length; i++) {
				options += '<option >' + data.f2[i] + '</option>';
			    }$("select#f2").html(options);
			    options='';
			  }
			if(data.f3 !== undefined){
			    for (var i = 0; i < data.f3.length; i++) {
				options += '<option >' + data.f3[i] + '</option>';
			    }$("select#f3").html(options);
			}
			
		    });
		}
		catch(err){
		      alert("error "+err);
		}
	    }
	});
    }
    catch(e){
	alert("error "+e);
    }
}


/*
  chromosomeMenu is called upon startup to populate the chromosome menu and create placeholders for multiple graph display 
*/ 

function chromosomeMenu(build){ 
  var options=''; 
  chr_names=[];
  chr_lengths=[];
  $.get(getChr_cgi ,{build:build,database:database}, function(jsonFile) { 
	    try{
	      $.getJSON(jsonFile, function(data){
			  var options = '';
			  var sum=0;
			  $.each(data.chr, function(i, c){
				   chr_names.push(c[0]);
				   chr_lengths.push(c[1]);
				   options+='<option >'+c[0]+'</option>';
				   
				 })
			  $("select#chromosomes").html(options);
			  setChrEnds();
			});
	    }
	    catch(e){
	    }
	});
} 


function showhide(id){ 
  var obj;
  if (document.getElementById){ 
    obj = document.getElementById(id); 
    if (obj.style.display == "none")
      obj.style.display = ""; 
    else 
      obj.style.display = "none"; 
  } 
} 

$(document).ajaxStart(function () {
	$("#ajaxBusy").show();}).ajaxStop(function (){
		$("#ajaxBusy").hide();
});


function emptyTxtBoxes(){ 
  $("#snp").val(""); 
  $("#gene_symbol").val(""); 
  $("#coord").val("");  
} 

/*
  select the first items in the menus if none are selected
*/

function checkSelection(){ 
    var labels=$("select#label option:selected").map(function() {
        return $(this).text();
    }).get();
    if(labels.length ==  0){
	$("#label option")[0]['selected']=true;
    }
    //getScanTypes();
} 
 


function getTraitLociTable(){ 
  var build=$("#build").val(); 
  var pop = $("#population").val(); 
  var  phenotype=$("#phenotypes").val(); 
  var scantypes = $("#scantypes").val(); 
  $("#regionPlots").hide(); 
  $("#genomePlots").hide(); 
  $("#genes").hide(); 
  $("#annotation").hide(); 
  var traitLoci=$("#traitLociTable"); 
  traitLoci.empty();   traitLoci.show();
  
  runRScript(traitLoci);
  /*
   var html="<br><table border=\"0\" width=\"100%\" cellspacing=\"2\" cellpadding=\"2\" align=\"left\" class=\"tableTxt\"><tr><td><b>id</b></td><td><b>\scan</b></td><td><b>scan type</b></td><td><b>chrom</b></td><td><b>from.bp</b></td><td><b>to.bp</b></td><td><b>from.marker</b></td><td><b>to.marker</b>\
</td><td><b>score</b></td><td><b>link</b></td></tr>"; 

   try{     //get all the genes for from the specified build and chromosome      var script;      if(!(phenotype)) 
     script= "http://mus.well.ox.ac.uk/cgi/populateMenus.cgi?build="+build+"&database="+database+"&pop="+pop+"&trait_loci=trait_loci";            
     if(!(phenotype)) 
       script= "http://mus.well.ox.ac.uk/cgi/populateMenus.cgi?build="+build+"&database="+database+"&pop="+pop+"&trait_loci=trait_loci";
     else{ 
       if(scantypes) 
	 script="http://mus.well.ox.ac.uk/cgi/populateMenus.cgi?build="+build+"&database="+database+"&pop="+pop+"&trait_loci=trait_loci&pheno="+phenotype+"&scantype="+scantypes;               
       else
	 script="http://mus.well.ox.ac.uk/cgi/populateMenus.cgi?build="+build+"&database="+database+"&pop="+pop+"&trait_loci=trait_loci&pheno="+phenotype;     
     }
     $.ajax({  
       type: "GET",                url: script,                success : function(jsonfile){      
	   try{               
	     $.getJSON(jsonfile, function(d){ 
			 for (var i = 0; i < d.trait_loci.length; i++) { 
			   var trait=d.trait_loci[i]; 
			   // console.log(d.trait_loci[i]); 
			  var line=""; 
			  for(var j=0; j < trait.length; j++){ 
			    line+=trait[j]+","; 
			  } 
			  var a=line.split(","); 
			  var functionCall="viewRegion()";//"viewRegion("+a[1]+","+a[2]+","+a[3]+","+a[4]+","+a[5]+")"; 
			  html+='<tr><td>'+a[0]+'</td><td>'+a[1]+'</td><td>'+a[2]+'</td><td>'+a[3]+'</td><td>'+a[4]+'</td><td>'+a[5]+'</td><td>'+ a[6]+'</td><td>'+a[7]+'</td><td>'+a[8]+'</td><td><a href=# onclick=\"viewRegion(\''+a[1]+'\',\''+a[2]+'\',\''+a[3]+'\',\''+a[4]+'\',\''+a[5]+'\')\">view</a></td></tr>'; //<a href=\"\">view</a> 
			 } 
			 html+="</table>"; 
			 traitLoci.append(html); }); }             
	   catch(e){ 
	     alert("error when reading jsonFile "+e); 
	   } 
	 } 
       }); 
   } 
  catch(err){   ("ERROR "+err);}           
  */
} 


function rangeOk(maxRange){ 
  if(typeof(x_from_gl) != "undefined"){ 
    if(parseInt(x_to_gl)-parseInt(x_from_gl) < maxRange){ 
      return true; 
    } 
  } 
  return false; 
} 

// Array Remove - By John Resig (MIT Licensed)
function remove(array, from, to) {
  var rest = array.slice((to || from) + 1 || array.length);
  array.length = from < 0 ? array.length + from : from;
  return array.push.apply(array, rest);
};
 
function runRScript(traitLoci){ 
  var  phenotype=$("#phenotypes").val();  
  var counter=0; 
  var limit=5; 
  var maxRange=6000000; 
  var chr=$("#chromosomes").val(); 
  if(!chr) 
    chr="1"; 
  if(typeof(x_from_gl) != "undefined"){ 
    if(rangeOk(maxRange)){ 
      $.each(phenotype, function(i, pheno){ 
               if(counter < limit){
		  pheno=pheno.replace("_new2", "");
		 pheno=pheno.replace("_new","");
		 
		
		 //splitting and putting together again, why? Check this
		  var phenoArray=pheno.split("_");
		  pheno="";
		 for(var i=0; i< phenoArray.length; i++){
		   if(i == phenoArray.length-1){
		     pheno+=phenoArray[i];
		  }
		 else{
		    pheno+=phenoArray[i]+"_";
		  }
		 }
		 //

		 var ajaxDiv='<div id="ajaxBusy'+counter+'" style="display:none"><img src="images/ajax-loader.gif"></div>'; 
                 var divid="link"+counter; 
                 var linkd='<div id="'+divid+'"></div>'; 
                 var html='<table><tr><td>'+linkd+'</td><td>'+ajaxDiv+'</td></tr></table>'; 
                 traitLoci.append(html); 
                 var linkDiv=$("#link"+counter); 
                 var ajaxBusy=$("#ajaxBusy"+counter); 
                 ajaxBusy.show(); 
                 linkDiv.addClass('graphTxt'); 
                 linkDiv.append("Getting data for "+pheno+"....."+chr+":"+x_from_gl+"-"+x_to_gl); 
                 var script="http://mus.well.ox.ac.uk/cgi/traitLoci_R.cgi?pheno="+pheno+"&chr="+chr+"&from="+x_from_gl+"&to="+x_to_gl; 
                 try{ 
                   $.ajax({ 
                     type: "GET", 
			 url: script, 
                         success: function(data){ 
                         var link; 
                         if(data.substring(2,0).toLowerCase() == "no"){ 
                           link="No trait loci data for "+pheno+" at chr "+chr+":"+x_from_gl+"-"+x_to_gl; 
                         } 
                         else{ 
			   var data2=data.split("/");
			   var fileName=data2[data2.length-1];
			   link="<a href="+data+">"+fileName+"</a>"; 
			   //                           linkDiv.removeClass('graphTxt'); 
			 } 
                         linkDiv.empty(); 
                         ajaxBusy.hide(); 
                         linkDiv.append(link); 
                       } 
                     }); 
                 } 
                 catch(e){ 
                   ("ERROR "+e); 
                 } 
               } 
             }); 
   
      if(phenotype.length > limit){ 
        var linkd2='<br><div id="max_count_msg"></div>'; 
        traitLoci.append(linkd2); 
        var linkDiv2=$("#max_count_msg"); 
        linkDiv2.addClass('graphTxt'); 
        linkDiv2.append("A MAXIMUM of "+limit+" files can be uploaded at the time!"); 
      } 
    } 
    else{ 
      //invalid range 
      traitLoci.append(inv_range); 
      var currentRange=parseInt(x_to_gl)-parseInt(x_from_gl); 
      $("#inv_range").addClass('graphTxt'); 
      $("#inv_range").append("The selected interval ["+currentRange+"] is too large! MAX interval is "+maxRange); 
    } 
  } 
  else{ 
    var inv_range='<br><div id="inv_range"></div>'; 
    traitLoci.append(inv_range); 
    $("#inv_range").addClass('graphTxt'); 
    $("#inv_range").append("Ranges are undefined. Make sure that zoom in on the graph before selecting trait loci table!!");   
  } 
} 







function viewRegion(pheno, type, chr, from, to){
  alert("to be implemented....");
  /*  to=parseInt(to)+500000; 
  from=parseInt(from)-500000; 
  $("#phenotypes").val(pheno); 
  $("#scantypes").val(type); 
  $("#tooltip").remove();
  getRegion(chr, from, to);
  */
}


function addLabelToTxtBox(){ 
  var txtBox=$("#coord"); 
  $('input[title]').each(function() { 
			   if(txtBox.val() === ''){
			     txtBox.val(txtBox.attr('title')); 
			     //adds the title to the text box
			   } 
			   txtBox.focus(function() { 
					  // alert("focus title--"+txtBox.attr('title')+"---val--"+txtBox.val()); 
					  // txtBox.val(''); 
					  if(txtBox.val().substring(0,2) === 'eg'){ // txtBox.attr('title')){ 
					    txtBox.val('').addClass('focused'); //removes title text on click 
					  } 
					}); 
			   txtBox.blur(function(){ 
					 if(txtBox.val() === ''){ 
					   txtBox.val(txtBox.attr('title')).removeClass('focused'); 
					 } 
				       }); 
			 });  
} 




 
function goTo(type){ 
  var orig_name;
  var name;
  var script;
 
  if(type == "snp"){
    orig_name=$("#snp").val(); 
    script=getSnp_cgi; 
  }
  else if (type == "gene"){
    orig_name=$("#gene_symbol").val();
    script=getGene_cgi;
  }    
  var name=orig_name.toLowerCase(); 
  var build=$("#build").val();
  var currentChr=$("#chromosomes").val();
  if ($("#genome:visible").length > 0 ) 
      currentChr=0; //in genome view, no chromosome is selected
  try{ 
      $.ajax({  
	      type: "GET",  
		  url: script+"?name="+name+"&database="+database+"&build="+build,  
		  success : function(response){   
		  if(response != ""){ 
		      var row=response.split(","); 
		      var name=row[0]; 
		      var chr=row[1].replace(/ /g,""); 
		      var bp_pos=row[2].replace(/ /g, ""); 
		      var from; var to;
		      
		      if(type == "snp"){
			  from=parseInt(bp_pos)-500; 
			  to=parseInt(bp_pos)+500;
		      }
		      else{
			  from=parseInt(bp_pos)-1000;
			  to=parseInt(row[3].replace(/ /g,""))+1000;
		      }
		      if(chr == currentChr){
			  zoomToRange({ xaxis : {from : from, to: to}, yaxis: {}}); 
		      }
		      else{		
			  $("#chromosomes").val(chr);
			  geneExonMarkings=[];
			  genesSeen=[];
			  getRegion(chr, from, to); 
		      }
		  } 
		  else 
		      alert(orig_name +" not found"); 
	      } 
	  }); 
  } 
  catch(e){ 
      alert("error when running "+script+" "+e); 
  } 
} 

function goToCoord(){ 
  var coord=$("#coord").val(); 
  coord=coord.replace(/ /g,""); //remove all white spaces 
  var chr; 
  var values=[]; 
  values=coord.split("\.\."); 
  var val2=[];
  val2=values[0].split(":");
  var from;
  if(val2.length > 1){
    //chromosome defined;
    chr=val2[0];
    // $("#chromosomes").val(chr);
    values[0]=val2[1];
  }
  var to=0; 
  if(values.length == 2){ 
    from=getValueInCorrectFormat(values[0]); 
    to=getValueInCorrectFormat(values[1]); 
  } 
  else 
    to=getValueInCorrectFormat(values[0]); 
  if(!from)
      alert("incorrect format!");
  if(to > from) 
    zoomToRange({ xaxis : {from : parseInt(from), to: parseInt(to)}, yaxis: {}}); 
} 
 
function getValueInCorrectFormat(val){ 
  var tmpVal=val.split("."); 
  if(tmpVal.length==2){ 
    tmpVal[0]+=addZeros(tmpVal[1]); 
    return tmpVal[0]; 
  }  
  return val; //use value as it is 
} 
 
function addZeros(tail){ 
  while(tail.length < 6){ 
    tail+="0"; 
  } 
  return tail; 
} 
 

function help_coord(){
  var wina = (screen.width - 400) / 2;
  var winb = (screen.height - 200) / 2;
  var tess = window.open('','blank','top='+winb+',left='+wina+',width=300,height=200');
  tess.resizeTo(300,300);
  // tess.moveTo(winb,wina);
  tess.status=1;
  tess.focus();
var page=""+
"<html>"+
"<head>"+
"<title>Go to coord  help</title>"+
"</head>"+
"<body>"+
"<table><tr><td><font face=Verdana size=2><br> Enter integers for <b>bp</b>, decimals for <b>Mbp</b>. <br><br> Example:<br><br>  10000000..12000000<br>or<br>10.0..12.2 <br><br></font> </td></tr></table>"+
"</body>"+
"</html>"
tess.document.open();
tess.document.write(page);
} 

//"+
