#!/usr/bin/perl

use strict;
use Cwd;
require "shared_func.pl";

require "get_genes.pl"; 
require "get_exons.pl";
require "get_gwasCat_data.pl";
require "get_disease_assoc.pl";

sub upload_genes_exons_disease{
    my ($opt_ref, $conf_ref, $Bin, $update)=@_;
    %Opt=%{$opt_ref};
    my %config=%{$conf_ref};
    my $genome_build_id=&getset_genome_build_id($conf_ref, $Opt{build});
    my ($genes_ref, $exons_ref, $disease_assoc_ref, $gwas_cat_ref, $chr_lengths);    
    #Get and upload the  files
    if((!$update)|| ($update && $Opt{all})) { #upload all the data
	
	$genes_ref=&get_genes($opt_ref, $conf_ref, $Bin);
	$disease_assoc_ref=&get_disease_assoc($opt_ref,$conf_ref, $Bin);	
	&upload_genes_disease($conf_ref, $genome_build_id, $genes_ref, $disease_assoc_ref);
	&get_and_upload_exons($opt_ref, $conf_ref,$Bin,  $genome_build_id, $genes_ref);
	
	my $chr_lengths=&get_and_insert_chr_lengths($opt_ref, $conf_ref, $Bin, $genome_build_id);
	print "\nGetting GWAS catalog data... \n";
	&get_gwasCat_data($opt_ref, $conf_ref, $Bin, $chr_lengths);
	print "\nDone!\n\n";
    }
    else{
        #dont update all, only those requested
	if($Opt{genes} && $Opt{dis_assoc} && $Opt{exons}){
	    $genes_ref=get_genes($opt_ref, $conf_ref, $Bin);
	    $disease_assoc_ref=get_disease_assoc($opt_ref, $conf_ref, $Bin);
	    &upload_genes_disease($conf_ref, $genome_build_id, $genes_ref, $disease_assoc_ref);
	    &get_and_upload_exons($opt_ref, $conf_ref, $genome_build_id, $genes_ref);
	}
	if($Opt{chr_lengths}){
	    $chr_lengths=&get_and_insert_chr_lengths($opt_ref,$conf_ref, $Bin, $genome_build_id);
	}
	if($Opt{gwascat}){
	    &get_gwascat_data($opt_ref, $conf_ref, $Bin, $chr_lengths);
	}
    }
}

sub get_and_insert_chr_lengths(){
    my ($opt_ref, $conf_ref, $Bin, $genome_build_id)=@_;
    my %Opt=%{$opt_ref};
    my %config=%{$conf_ref};
    my $genes_file;
    print "*** Inserting CHROMOSOME lenghts *** \n";
    my %chr_lengths=();
    my $mysql_connect="mysql -u $config{user} -p$config{password} $config{database}";
    my $resource_dir=&get_resource_dir($conf_ref, $Bin);
    my $chr_lengths_file="chr.lengths.$Opt{build}.tsv";
    my $file=$resource_dir."/".$Opt{build}."/".$chr_lengths_file;    
    if(! -e $file){
	print "Cannot find the [$chr_lengths_file] in the directory [$resource_dir], so getting it:\n";
	&get_resource_bundle($opt_ref, $conf_ref, $Bin);
    }
    open(IN, $file) or die "Cant open file $file\n";
    my $dupl_entries=0;
    while(<IN>){
	if($_ !~ /^#/){
	    my ($chr, $chrLength, @rest)=split("\t", $_);
	    $chrLength =~ s/,//g;
	    $chr_lengths{$chr}=$chrLength;
	    my $sql="INSERT INTO chromosome (name, genome_build_id, length) values (\"$chr\",$genome_build_id,\"$chrLength\");";
	    my $cmd="echo '$sql' | $mysql_connect "; 
	    my @out=qx($cmd 2>&1);
	    if( $out[0] =~ /Using a password on the command line interface can be insecure/){
		if($out[1] =~ /Duplicate entry/){
		    if(! $dupl_entries){
			print "Duplicate entry. Chromosome length has already been inserted for chr $chr";
			$dupl_entries=1;
		    }
		    else{ print ",$chr";
		    }
		    }
		elsif ($out[1] =~ /\S+/){ # report the message:
		    print "The cmd:\n$cmd\n gives the following error: \n$out[1]; \n\n";exit;
		}
	    }
	}
    }
    print "\n";
    if(! $dupl_entries){
	print "Success. Chromosome lengths were inserted.\n";
    }
    close(IN);
    return \%chr_lengths;
}
