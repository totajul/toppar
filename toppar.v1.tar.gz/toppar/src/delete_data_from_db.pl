#!/usr/bin/perl 

use strict;

require "shared_func.pl";
my %config=();

sub delete_data{
    my ($opt_ref, $conf_ref, $Bin)=@_;
    my %Opt=%{$opt_ref};
    %config=%{$conf_ref};
    my ($sql, @output);
    my $sql_bind=" AND gs.genome_scan_id=gss.genome_scan_id and gs.population_id=(select population_id from population where name=\"$Opt{pop}\") and gs.genome_build_id=(SELECT genome_build_id from genome_build where name=\"$Opt{build}\")";
    if($Opt{label}){
	#Get the genome_subscan_id for the label
	$sql="SELECT gss.genome_subscan_id, gs.genome_scan_id FROM genome_subscan gss, genome_scan gs WHERE gss.label=\"$Opt{label}\"".$sql_bind;
	@output=@{&submit_cmd($sql)};
	my ($gsubscan_id, $gscan_id)=split("\t", $output[2]);$gscan_id=~ s/\n//;    
	&clean_up($gsubscan_id, $gscan_id);
    }
    elsif( $Opt{f1} || $Opt{f2} || $Opt{f3} ){
	my $filter="gss.f1=\"$Opt{f1}\" ";
	if($Opt{f2}){ $filter="gss.f2=\"$Opt{f2}\" ";}
	if($Opt{f3}){ $filter="gss.f3=\"$Opt{f3}\" ";}
	$sql="SELECT gss.genome_subscan_id, gs.genome_scan_id FROM genome_subscan gss, genome_scan gs WHERE ".$filter.$sql_bind;
	@output=@{&submit_cmd($sql)};
	for(my $i=2; $i<$#output+1; $i++){
	    my ($gsubscan_id, $gscan_id)=split("\t", $output[$i]); $gscan_id=~ s/\n//;
	    &clean_up($gsubscan_id, $gscan_id);
	}
    }
    elsif($Opt{pheno}){
	$sql="SELECT gss.genome_subscan_id, gs.genome_scan_id FROM genome_subscan gss, genome_scan gs WHERE gs.phenotype_id=(SELECT phenotype_id from phenotype where name=\"$Opt{pheno}\")".$sql_bind;
	@output=@{&submit_cmd($sql)};
	for(my $i=2; $i<$#output+1; $i++){
	    my ($gsubscan_id, $gscan_id)=split("\t", $output[$i]); $gscan_id=~ s/\n//;
	    &clean_up($gsubscan_id, $gscan_id);
	}	
    }
    elsif($Opt{pop}){
	$sql="SELECT gss.genome_subscan_id, gs.genome_scan_id FROM genome_subscan gss, genome_scan gs WHERE gs.population_id=(SELECT population_id from population where name=\"$Opt{pop}\")".$sql_bind;
	@output=@{&submit_cmd($sql)};
	for(my $i=2; $i<$#output+1; $i++){
	    my ($gsubscan_id, $gscan_id)=split("\t", $output[$i]); $gscan_id=~ s/\n//;
	    &clean_up($gsubscan_id, $gscan_id);
	}
    }
}

sub clean_up{
    my ($gsubscan_id, $gscan_id)=@_; 
    my ($sql, @output);
    if($gsubscan_id =~ /\d+/){
	#delete the genome subscan_results
	$sql="delete from genome_subscan_results where genome_subscan_id=$gsubscan_id\n"; &delete_cmd($sql);
	#delete from genome_subscan
	$sql="delete from genome_subscan where genome_subscan_id=$gsubscan_id";	&delete_cmd($sql);
    }
    if($gscan_id =~ /\d+/){
	#delete the genome_scan, if there are no other genome_subscans with the genome_scan_id
	$sql="select genome_scan_id from genome_subscan_where genome_scan_id=$gscan_id";
	@output=@{&submit_cmd($sql)};
	if($output[1] =~ /Empty set/){
	    #first get the phenotype and population ids since they may have to be deleted too
	    $sql="SELECT phenotype_id, population_id from genome_scan where genome_scan_id=$gscan_id";
	    @output=@{&submit_cmd($sql)};
	    my ($phenotype_id, $pop_id)=split("\t", $output[2]);
	    #delete the genome_scan
	    $sql="delete from genome_scan where genome_scan_id=$gscan_id";
	    $sql="select genome_scan_id from genome_scan where phenotype_id=$phenotype_id";
	    @output=@{&submit_cmd($sql)};
	    if($output[1] =~ /Empty set/){
		$sql="delete FROM phenotype where phenotype_id=$phenotype_id";
		&delete_cmd($sql);
	    }
	    $sql="select genome_scan_id from genome_scan where population_id=$pop_id";
	    @output=@{&submit_cmd($sql)};
	    if($output[1] =~ /Empty set/){
		$sql="delete FROM population where population_id=$pop_id";
		&delete_cmd($sql);
	    }
	}
	else{#there is other  data, dont delete 
	}
    }
}

sub submit_cmd{
    my $sql=shift;
    my $mysql_connect="mysql -u $config{user} -p$config{password} $config{database}";
    my $cmd="echo '$sql;' | $mysql_connect"; 
    my @output=qx($cmd 2>&1);
    print "$cmd \n";
    return \@output;
}

sub delete_cmd{
    my $sql=shift;
    my $mysql_connect="mysql -u $config{user} -p$config{password} $config{database}";
    my $cmd="echo '$sql;' | $mysql_connect"; 
    my $success=qx($cmd 2>&1);
    print "$cmd\n$success\n";
}

1;
