#!/bin/sh

echo "*** Configure and create the toppar_01 database ***";echo;
perl toppar_db config
perl toppar_db create_db

echo "*** Getting external gene,exon, chr and disease association data ****"; echo;
perl toppar_db get_ext_data --build=GRCh37

echo "*** Getting external data ****"; echo;
wget https://github.com/totajul/toppar/raw/master/resources/giant_reduced.tar.gz .
tar -zxvf giant_reduced.tar.gz

echo "*** Initiating the GIANT population  ****"; echo;
perl toppar_db init_pop --pop=GIANT --build=GRCh37 --filters=ethnicity,sex,test

echo "*** Making the markers file ****"; echo;
perl toppar_db mk_markers --indir=giant_reduced/  --sfx=txt --outfile=giant_markers.tsv

echo "*** Uploading the markers to the database  ****"; echo;
perl toppar_db upload_markers --infile=toppar_out/giant_markers.tsv --build=GRCh37 --pop=GIANT

echo "*** Uploading association test results ****"; echo;
perl toppar_db single --indir=giant_reduced/ --pop=GIANT --build=GRCh37 --sfx=txt --desc=A1,A2,FreqA1.Hapmap,b,se,N